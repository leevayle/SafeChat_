import { useEffect, useMemo, useState, useRef } from 'react'
import { motion } from 'framer-motion'
import { Search, Plus, Pencil, Phone, MessageCircle, X, UserPlus, Trash2, Star , Loader2, Check } from 'lucide-react'
import { Avatar } from '../components/Avatar'
import { ScreenHeader } from '../components/ui'
import { useStore } from '../store'
import { PillButton } from '../components/PillButton'
import { ConfirmDialog } from '../components/ConfirmDialog'
import { api, type ApiContact } from '../api'

type Props = {
  onClose: () => void
  onChat: (id: string) => void
  onCall: (id: string, kind: 'audio' | 'video') => void
}

function isPhoneSearchInput(value: string) {
  const trimmed = value.trim()
  return !!trimmed && /^[+()\d\s-]+$/.test(trimmed)
}

function normalizeKenyanPhone(value: string) {
  const digits = value.replace(/\D/g, '')
  if (digits.startsWith('254')) return `+${digits}`
  if (/^0[17]\d{8}$/.test(digits)) return `+254${digits.slice(1)}`
  if (/^[17]\d{8}$/.test(digits)) return `+254${digits}`
  return value.trim()
}

function isFullKenyanPhone(value: string) {
  const digits = value.replace(/\D/g, '')
  return /^(?:254[17]\d{8}|0[17]\d{8}|[17]\d{8})$/.test(digits)
}

export function Contacts({ onClose, onChat, onCall }: Props) {
  const { contacts, refreshContacts, showToast } = useStore()
  const [contactsLoading, setContactsLoading] = useState(!contacts.length)
  const [q, setQ] = useState('')
  const [edit, setEdit] = useState<ApiContact | null>(null)
  const [draft, setDraft] = useState({ savedName: '', note: '', phone: '' })
  const [adding, setAdding] = useState(false)
  const [addForm, setAddForm] = useState({ username: '', phone: '', savedName: '', sharePhone: true })
  const [addMode, setAddMode] = useState<'username' | 'phone'>('username')
  const [searchHits, setSearchHits] = useState<any[]>([])
  const [searching, setSearching] = useState(false)
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const searchGen = useRef(0)
  const searchAbort = useRef<AbortController | null>(null)
  const searchCache = useRef<Map<string, any[]>>(new Map())
  const lastSearchQ = useRef('')
  /** idle | loading | sent | saved */
  const [requestState, setRequestState] = useState<Record<string, 'loading' | 'sent' | 'saved'>>({})

  const [busy, setBusy] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [notFoundPhone, setNotFoundPhone] = useState<string | null>(null)
  const [identity, setIdentity] = useState('')

  useEffect(() => {
    let active = true
    void refreshContacts().finally(() => {
      if (active) setContactsLoading(false)
    })
    return () => {
      active = false
    }
  }, [refreshContacts])

  const list = useMemo(() => {
    const qq = q.trim().toLowerCase()
    const base = [...contacts].sort(
      (a, b) => Number(!!b.pinned) - Number(!!a.pinned) || a.name.localeCompare(b.name),
    )
    if (!qq) return base
    return base.filter(
      (c) =>
        c.name.toLowerCase().includes(qq) ||
        c.username?.toLowerCase().includes(qq) ||
        c.phone.includes(qq) ||
        c.note?.toLowerCase().includes(qq),
    )
  }, [contacts, q])

  const openEdit = (c: ApiContact) => {
    setEdit(c)
    setDraft({ savedName: c.savedName || c.name, note: c.note || '', phone: c.phone })
  }

  const contactKey = (c: ApiContact) => c.peerId || c.id

  const saveEdit = async () => {
    if (!edit) return
    setBusy(true)
    try {
      await api.updateContact(contactKey(edit), {
        savedName: draft.savedName,
        note: draft.note,
        phone: draft.phone,
      })
      await refreshContacts()
      showToast('Contact updated')
      setEdit(null)
    } catch (e: any) {
      showToast(e?.message || 'Could not update')
    } finally {
      setBusy(false)
    }
  }

  const doDelete = async () => {
    if (!deleteId) return
    setBusy(true)
    try {
      await api.deleteContact(deleteId)
      await refreshContacts()
      showToast('Contact deleted')
      setDeleteId(null)
    } catch (e: any) {
      showToast(e?.message || 'Could not delete')
    } finally {
      setBusy(false)
    }
  }

  const toggleFav = async (c: ApiContact) => {
    try {
      await api.updateContact(contactKey(c), { favourite: !c.favourite })
      await refreshContacts()
      showToast(c.favourite ? 'Removed from favourites' : 'Added to favourites')
    } catch {
      showToast('Could not update favourite')
    }
  }

  const runSearch = (value: string) => {
    setIdentity(value)
    const gen = ++searchGen.current
    const trimmed = value.trim()
    const phoneMode = isPhoneSearchInput(trimmed)
    setAddMode(phoneMode ? 'phone' : 'username')
    setAddForm((f) => ({
      ...f,
      username: phoneMode ? '' : trimmed.replace(/^@/, ''),
      phone: phoneMode ? trimmed : '',
    }))
    const searchValue = phoneMode ? trimmed.replace(/\D/g, '') : trimmed.replace(/^@/, '')
    if (searchValue.length < 2) {
      if (searchTimer.current) clearTimeout(searchTimer.current)
      searchAbort.current?.abort()
      setSearchHits([])
      setSearching(false)
      lastSearchQ.current = ''
      return
    }
    const cacheKey = `${phoneMode ? 'p' : 'u'}:${searchValue.toLowerCase()}`
    // Instant cache hit - no spinner
    const cached = searchCache.current.get(cacheKey)
    if (cached) {
      setSearchHits(cached)
      setSearching(false)
    }
    if (searchTimer.current) clearTimeout(searchTimer.current)
    // Skip duplicate in-flight query
    if (lastSearchQ.current === cacheKey && !cached) {
      setSearching(true)
      return
    }
    if (!cached) setSearching(true)
    const q = trimmed
    // Debounce network; local contacts list already filters instantly via `list`
    searchTimer.current = setTimeout(async () => {
      if (gen !== searchGen.current) return
      lastSearchQ.current = cacheKey
      searchAbort.current?.abort()
      const ac = new AbortController()
      searchAbort.current = ac
      try {
        const { users } = await api.searchUsers(q)
        if (gen !== searchGen.current || ac.signal.aborted) return
        const next = users || []
        searchCache.current.set(cacheKey, next)
        // Cap cache size
        if (searchCache.current.size > 40) {
          const first = searchCache.current.keys().next().value
          if (first) searchCache.current.delete(first)
        }
        setSearchHits(next)
      } catch {
        if (gen !== searchGen.current || ac.signal.aborted) return
        if (!cached) setSearchHits([])
      } finally {
        if (gen === searchGen.current) setSearching(false)
      }
    }, 420)
  }

  const addContact = async (peer?: { id: string; username: string; phone: string; name: string }) => {
    setBusy(true)
    setNotFoundPhone(null)
    const key = peer?.id || peer?.username || identity
    if (key) setRequestState((m) => ({ ...m, [key]: 'loading' }))
    try {
      let username = (peer?.username || addForm.username || '').replace(/^@/, '').trim()
      const rawPhone = (peer?.phone || addForm.phone || identity || '').trim()
      let phoneFull = addMode === 'phone' ? normalizeKenyanPhone(rawPhone) : rawPhone
      if (!peer && addMode === 'phone') {
        if (!isFullKenyanPhone(rawPhone)) {
          showToast('Choose a matching account from the phone search results.')
          setBusy(false)
          return
        }
        try {
          const { users } = await api.searchUsers(phoneFull)
          const hit = (users || []).find((u) => u.phoneMatch)
          if (!hit) {
            setNotFoundPhone(phoneFull)
            setBusy(false)
            return
          }
          peer = hit
          username = hit.username
        } catch {
          setNotFoundPhone(phoneFull)
          setBusy(false)
          return
        }
      }
      if (!peer && !username) {
        showToast('Enter a username or phone number')
        setBusy(false)
        return
      }
      const res = await api.addContact({
        peerId: peer?.id,
        username: username || undefined,
        phone: phoneFull.startsWith('+') ? phoneFull : undefined,
        savedName: addForm.savedName || peer?.name || username || phoneFull,
        sharePhone: addForm.sharePhone,
      })
      showToast(res.pending ? 'Save request sent' : 'Contact saved')
      if (key) setRequestState((m) => ({ ...m, [key]: res.pending ? 'sent' : 'saved' }))
      if (!res.pending) setAdding(false)
      void refreshContacts()
      setIdentity('')
      setAddForm({ username: '', phone: '', savedName: '', sharePhone: true })
      setSearchHits([])
    } catch (e: any) {
      showToast(e?.message || 'Could not add contact')
      if (key) setRequestState((m) => {
        const n = { ...m }
        delete n[key]
        return n
      })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="relative flex h-full flex-col bg-white">
      <ScreenHeader
        title="Contacts"
        onBack={onClose}
        right={
          <button
            type="button"
            aria-label="Add contact"
            onClick={() => setAdding(true)}
            className="flex h-10 w-10 items-center justify-center rounded-full text-brand-purple hover:bg-gray-100"
          >
            <UserPlus size={22} />
          </button>
        }
      />

      <div className="px-4 pb-3 pt-3">
        <div className="flex items-center gap-2 rounded-2xl bg-gray-100 px-3 py-2.5">
          <Search size={18} className="text-gray-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search your contacts"
            className="w-full bg-transparent text-sm font-semibold outline-none"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-2 pb-8">
        {list.length === 0 && contactsLoading && (
          <div className="space-y-2 px-3 py-3" aria-label="Loading contacts">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-3 rounded-2xl px-3 py-2.5">
                <div className="sk-shimmer h-12 w-12 shrink-0 rounded-full" />
                <div className="flex-1 space-y-2">
                  <div className="sk-shimmer h-3 w-2/5 rounded" />
                  <div className="sk-shimmer h-2.5 w-1/3 rounded" />
                </div>
              </div>
            ))}
          </div>
        )}
        {list.length === 0 && !contactsLoading && (
          <p className="px-4 py-10 text-center text-sm font-bold text-gray-400">
            No contacts yet. Tap + to add someone by username or phone.
          </p>
        )}
        {list.map((c, i) => (
          <motion.div
            key={c.entryId}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: Math.min(i * 0.03, 0.3) }}
            className="flex items-center gap-3 rounded-2xl px-3 py-2.5 hover:bg-gray-50"
          >
            <button type="button" onClick={() => onChat(c.id)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
              <Avatar contact={c} size={48} />
              <div className="min-w-0">
                <p className="truncate font-extrabold">
                  {c.name}
                  {c.favourite && <Star size={12} className="ml-1 inline text-brand-orange" fill="currentColor" />}
                </p>
                <p className="truncate text-xs font-semibold text-gray-500">
                  @{c.username || '-'} · {c.phone || 'no number'}
                </p>
              </div>
            </button>
            <button type="button" onClick={() => toggleFav(c)} className="rounded-full p-2 text-gray-400 hover:bg-gray-100" aria-label="Favourite">
              <Star size={18} className={c.favourite ? 'text-brand-orange' : ''} fill={c.favourite ? 'currentColor' : 'none'} />
            </button>
            <button type="button" onClick={() => onCall(c.id, 'audio')} className="rounded-full p-2 text-brand-purple hover:bg-gray-100" aria-label="Call">
              <Phone size={18} />
            </button>
            <button type="button" onClick={() => onChat(c.id)} className="rounded-full p-2 text-brand-purple hover:bg-gray-100" aria-label="Chat">
              <MessageCircle size={18} />
            </button>
            <button type="button" onClick={() => openEdit(c)} className="rounded-full p-2 text-gray-500 hover:bg-gray-100" aria-label="Edit">
              <Pencil size={16} />
            </button>
            <button
              type="button"
              onClick={() => setDeleteId(c.peerId || c.id)}
              className="rounded-full p-2 text-brand-red hover:bg-red-50"
              aria-label="Delete"
            >
              <Trash2 size={16} />
            </button>
          </motion.div>
        ))}
      </div>

      {/* Add contact sheet */}
      {adding && (
        <div className="absolute inset-0 z-[90] flex flex-col bg-white">
          <ScreenHeader
            title="Add contact"
            onBack={() => {
              setAdding(false)
              setNotFoundPhone(null)
              setIdentity('')
              setSearchHits([])
            }}
            right={
              <span className="rounded-full bg-brand-purple/10 px-2.5 py-1 text-[11px] font-extrabold text-brand-purple">
                {addMode === 'phone' ? 'Phone' : 'Username'}
              </span>
            }
          />
          <div className="space-y-3 px-5 pt-2">
            <label className="block text-xs font-extrabold text-gray-500">
              Username or phone
            </label>
            <input
              value={identity}
              onChange={(e) => runSearch(e.target.value)}
              placeholder="@username, +2547… or 07…"
              className="w-full rounded-2xl border border-gray-200 px-4 py-3 font-semibold outline-none focus:border-brand-purple"
              inputMode={addMode === 'phone' ? 'tel' : 'text'}
            />
            <p className="text-[11px] font-semibold text-gray-400">
              {addMode === 'phone'
                ? 'Search by Kenyan phone prefix; choose the matching account from the results.'
                : 'Type a username to search, or enter a phone number starting with +254 or 0.'}
            </p>
            {(searching || searchHits.length > 0) && (
              <ul className="rounded-2xl border border-gray-100">
                {searching &&
                  [0, 1, 2].map((i) => (
                    <li key={`sk-${i}`} className="flex items-center gap-3 px-3 py-2.5">
                      <div className="sk-shimmer h-10 w-10 shrink-0 rounded-full" />
                      <div className="min-w-0 flex-1 space-y-2">
                        <div className="sk-shimmer h-3 w-2/5 rounded" />
                        <div className="sk-shimmer h-2.5 w-1/3 rounded" />
                      </div>
                    </li>
                  ))}
                {!searching &&
                  searchHits.map((u) => {
                    const st = requestState[u.id] || requestState[u.username]
                    const inContacts = contacts.some(
                      (c) => c.id === u.id || c.username === u.username,
                    )
                    return (
                      <li key={u.id}>
                        <button
                          type="button"
                          disabled={st === 'loading' || st === 'sent' || inContacts || st === 'saved'}
                          onClick={() => addContact(u)}
                          className="flex w-full items-center gap-3 px-3 py-2.5 text-left hover:bg-gray-50 disabled:opacity-80"
                        >
                          <Avatar contact={u} size={40} />
                          <div className="min-w-0 flex-1">
                            <p className="font-extrabold">{u.name}</p>
                            <p className="text-xs font-semibold text-gray-500">@{u.username}</p>
                          </div>
                          {st === 'loading' ? (
                            <Loader2 size={18} className="ml-auto animate-spin text-brand-purple" />
                          ) : inContacts || st === 'saved' ? (
                            <Check size={18} className="ml-auto text-emerald-500" />
                          ) : st === 'sent' ? (
                            <Check size={18} className="ml-auto text-brand-blue" />
                          ) : (
                            <Plus size={18} className="ml-auto text-brand-purple" />
                          )}
                        </button>
                      </li>
                    )
                  })}

              </ul>
            )}
            <label className="block text-xs font-extrabold text-gray-500">Save as (only you see this)</label>
            <input
              value={addForm.savedName}
              onChange={(e) => setAddForm((f) => ({ ...f, savedName: e.target.value }))}
              placeholder="How you want to see them"
              className="w-full rounded-2xl border border-gray-200 px-4 py-3 font-semibold outline-none focus:border-brand-purple"
            />
            <button
              type="button"
              onClick={() => setAddForm((f) => ({ ...f, sharePhone: !f.sharePhone }))}
              className="flex w-full items-center justify-between rounded-2xl border border-gray-200 px-4 py-3 text-left"
            >
              <div>
                <p className="text-sm font-extrabold text-ink">Share my phone number</p>
                <p className="text-xs font-semibold text-gray-500">
                  {addForm.sharePhone
                    ? 'They will see your number after accepting'
                    : 'Only your username is shared'}
                </p>
              </div>
              <span
                className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${
                  addForm.sharePhone ? 'bg-brand-purple' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all ${
                    addForm.sharePhone ? 'right-0.5' : 'left-0.5'
                  }`}
                />
              </span>
            </button>
            <PillButton
              onClick={() => addContact()}
              disabled={busy || !identity.trim()}
            >
              {busy ? 'Sending…' : 'Send save request'}
            </PillButton>
          </div>

          {notFoundPhone && (
            <div className="fixed inset-0 z-[95] flex items-end justify-center bg-black/40 p-4 sm:items-center">
              <div className="w-full max-w-sm rounded-3xl bg-white p-5 shadow-xl">
                <p className="text-lg font-black text-ink">Not on SafeChat yet</p>
                <p className="mt-2 text-sm font-semibold text-gray-500">
                  <span className="font-extrabold text-ink">{notFoundPhone}</span> has not joined SafeChat.
                  Invite them with an SMS so you can chat securely.
                </p>
                <div className="mt-5 flex gap-2">
                  <button
                    type="button"
                    className="flex-1 rounded-full bg-gray-100 py-3 text-sm font-extrabold text-gray-600"
                    onClick={() => setNotFoundPhone(null)}
                  >
                    Not now
                  </button>
                  <a
                    href={`sms:${notFoundPhone}?body=${encodeURIComponent(
                      'Join me on SafeChat - private chats, calls and statuses. Get the app and save my number!',
                    )}`}
                    className="flex flex-1 items-center justify-center rounded-full bg-brand-purple py-3 text-sm font-extrabold text-white"
                    onClick={() => setNotFoundPhone(null)}
                  >
                    Send SMS invite
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Edit sheet */}
      {edit && (
        <div className="absolute inset-0 z-[90] flex flex-col bg-white">
          <ScreenHeader title="Edit contact" onBack={() => setEdit(null)} />
          <div className="space-y-3 px-5 pt-2">
            <p className="text-xs font-bold text-gray-400">@{edit.username || 'not on SafeChat'}</p>
            <label className="block text-xs font-extrabold text-gray-500">Name on your phone (only you see this)</label>
            <input
              value={draft.savedName}
              onChange={(e) => setDraft((d) => ({ ...d, savedName: e.target.value }))}
              className="w-full rounded-2xl border border-gray-200 px-4 py-3 font-semibold outline-none focus:border-brand-purple"
            />
            <label className="block text-xs font-extrabold text-gray-500">Note</label>
            <input
              value={draft.note}
              onChange={(e) => setDraft((d) => ({ ...d, note: e.target.value }))}
              className="w-full rounded-2xl border border-gray-200 px-4 py-3 font-semibold outline-none focus:border-brand-purple"
            />
            <label className="block text-xs font-extrabold text-gray-500">Phone</label>
            <input
              value={draft.phone}
              onChange={(e) => setDraft((d) => ({ ...d, phone: e.target.value }))}
              className="w-full rounded-2xl border border-gray-200 px-4 py-3 font-semibold outline-none focus:border-brand-purple"
            />
            <PillButton onClick={saveEdit} disabled={busy}>
              {busy ? 'Saving…' : 'Save changes'}
            </PillButton>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={!!deleteId}
        title="Delete contact?"
        message="They will be removed from your contact list only. Chat history stays."
        confirmLabel="Delete"
        danger
        onConfirm={doDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  )
}
