import { useCallback, useEffect, useRef, useState, memo, type ChangeEvent, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowLeft, Phone, Video, PhoneMissed, PhoneIncoming, PhoneOutgoing, Smile, Send, Check, CheckCheck, ImagePlus, X, Clock, RotateCcw, MoreVertical, BellOff, Bell, Volume2, Mic, Ban, Lock, Unlock, Download, Gamepad2, Reply, Trash2 } from 'lucide-react'
import { Avatar, VerifiedCheck } from '../components/Avatar'
import { NotesBoard } from '../components/NotesBoard'
import { ChatImageCropper } from '../components/ChatImageCropper'
import { TicTacToe } from '../components/TicTacToe'
import { fileToDataUrl } from '../lib/imageProcess'
import { EmptyState } from '../components/EmptyState'
import { Toggle } from '../components/ui'
import { api, hasAccessToken, type ApiMsg } from '../api'
import { utcNowIso, formatLocalTime, formatLastSeen, parseUtc, formatDayLabel, localDayKey } from '../time'
import { isRealtimeOpen, wsSendMessage, wsReceipt, wsLiveTyping, wsTyping } from '../realtime'
import { FONT_SIZES, resolveWallpaper, useStore } from '../store'
import { playInboxLandingChime } from '../lib/sounds'
import { compressForWeb } from '../lib/imageProcess'
import {
  getCachedMessages,
  mergeCachedMessages,
  mergeMessageLists,
  hydrateThreadFromDisk,
} from '../lib/messageCache'
import {
  subscribeThread,
  applyThreadMessages,
  setThreadCursor,
  getThreadCursor,
  isLoadingOlder,
  markLoadingOlder,
  prependOlderMessages,
  hydrateThread,
} from '../lib/messageStore'
import { warmPhoto } from '../lib/photoCache'
import { putOutbox, removeOutbox } from '../lib/appCache'
import { API_ORIGIN } from '../config'
import { linkifyText } from '../lib/linkify'
import { copyText } from '../lib/clipboard'
import { encodeStatusReply, parseStatusReply } from '../lib/statusReply'

import { kvGet, kvSet, kvRemove, kvGetJson, kvSetJson, hydrateKv } from '../lib/kv'
type Props = { contactId: string; onBack: () => void; onCall: (kind: 'audio' | 'video') => void; onOpenCalls?: () => void; onOpenStatus?: (userId: string, statusId?: string) => void }

const REACT_EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '🙏'] as const
const EMOJIS = [
  '😀','😁','😂','🤣','😃','😄','😅','😆','😉','😊','😋','😎','😍','😘','🥰','😗','😙','😚',
  '🙂','🤗','🤩','🤔','🤨','😐','😑','😶','🙄','😏','😣','😥','😮','🤐','😯','😪','😫','🥱',
  '😴','😌','😛','😜','😝','🤤','😒','😓','😔','😕','🙃','🤑','😲','☹️','🙁','😖','😞','😟',
  '😤','😢','😭','😦','😧','😨','😩','🤯','😬','😰','😱','🥵','🥶','😳','🤪','😵','😡','😠',
  '🤬','😷','🤒','🤕','🤢','🤮','sneezing','😇','🥳','🥺','🤠','🤡','🤥','🤫','🤭','🧐','🤓','😈',
  '👋','🤚','🖐️','✋','🖖','👌','🤌','🤏','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','👇','👍',
  '👎','✊','👊','🤛','🤜','👏','🙌','👐','🤲','🤝','🙏','💪',
  '❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗','💖','💘','💝',
  '🔥','⭐','✨','🌟','💫','💥','🎉','🎊','🎈','🎁','🏆','🥇','🎯','💯','✅',
  '☕','🍕','🍔','🍟','🌮','🍣','🍦','🍰','🍺','🍻','🎂','🍪','🍩','🍿',
].filter((e) => e !== 'sneezing')

function mediaUrl(path?: string | null) {
  if (!path) return ''
  if (path.startsWith('http') || path.startsWith('data:')) return path
  return `${API_ORIGIN}${path}`
}

const STATE_RANK: Record<string, number> = {
  pending: 0,
  failed: 0,
  sent: 1,
  delivered: 2,
  read: 3,
}

function rankState(s?: string) {
  return STATE_RANK[s || ''] ?? 0
}

/** Never downgrade delivery state (pending → sent → delivered → read). */
function pickState(a?: string, b?: string): ApiMsg['state'] | undefined {
  if (!a && !b) return undefined
  if (!a) return b as ApiMsg['state']
  if (!b) return a as ApiMsg['state']
  return rankState(a) >= rankState(b) ? (a as ApiMsg['state']) : (b as ApiMsg['state'])
}

function newClientMessageKey() {
  const randomId =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2)}`
  return `local-${randomId}`
}

function sameMsgList(a: ApiMsg[], b: ApiMsg[]) {
  if (a.length !== b.length) return false
  for (let i = 0; i < a.length; i++) {
    const x = a[i]
    const y = b[i]
    if (
      x.id !== y.id ||
      x.clientKey !== y.clientKey ||
      x.state !== y.state ||
      x.text !== y.text ||
      x.image !== y.image ||
      x.mine !== y.mine
    )
      return false
  }
  return true
}

/** Receipt ticks only - isolated so state changes never re-animate the bubble */
const ReceiptTicks = memo(function ReceiptTicks({
  state,
  readReceipts,
  mine,
}: {
  state?: ApiMsg['state']
  readReceipts: boolean
  mine: boolean
}) {
  if (!mine) return null
  // pending → clock | sent → ✓ | delivered → ✓✓ gray | read → ✓✓ blue
  if (state === 'pending' || !state) {
    return <Clock size={13} strokeWidth={2.5} className="opacity-80" aria-label="Sending" />
  }
  if (state === 'failed') {
    return (
      <RotateCcw
        size={13}
        strokeWidth={2.5}
        className="text-red-200"
        aria-label="Failed - tap to retry"
      />
    )
  }
  if (state === 'sent') {
    return <Check size={14} strokeWidth={2.5} aria-label="Sent" />
  }
  if (state === 'delivered') {
    return <CheckCheck size={14} strokeWidth={2.5} className="opacity-90" aria-label="Delivered" />
  }
  if (state === 'read') {
    return (
      <CheckCheck
        size={14}
        strokeWidth={2.5}
        className={readReceipts ? 'text-sky-300' : 'text-sky-400'}
        aria-label="Read"
      />
    )
  }
  // Unknown → single tick (never look "read" by accident)
  return <Check size={14} strokeWidth={2.5} aria-label="Sent" />
})

type BubbleProps = {
  m: ApiMsg
  mine: boolean
  readReceipts: boolean
  animateIn: boolean
  onRetry: (m: ApiMsg) => void
  onReply?: (m: ApiMsg) => void
  onOpenCalls?: () => void
  onJumpTo?: (id: string) => void
  highlight?: boolean
  onOpenAction?: () => void
  onOpenStatusReply?: (sr: { preview: string; time?: string; statusId?: string }) => void
  onOpenImage?: (url: string) => void
  onReactEmoji?: (m: ApiMsg, emoji: string) => void
  onDeleteMsg?: (m: ApiMsg) => void
}

/** One mount animation only; later receipt updates re-render ticks in place */
const MessageBubble = memo(function MessageBubble({
  m,
  mine,
  readReceipts,
  animateIn,
  onRetry,
  onReply,
  onOpenCalls,
  onJumpTo,
  highlight,
  onOpenAction,
  onOpenStatusReply,
  onOpenImage,
  onReactEmoji,
  onDeleteMsg,
}: BubbleProps) {
  const startX = useRef(0)
  const startY = useRef(0)
  const [dx, setDx] = useState(0)
  const [hoverReact, setHoverReact] = useState(false)

  // Always surface quoted status card even if cache still has the raw envelope
  if (!m.statusReply && m.text) {
    const parsed = parseStatusReply(String(m.text))
    if (parsed.statusReply) {
      m = { ...m, text: parsed.text, statusReply: parsed.statusReply }
    }
  }

  if (m.callLog) {
    const missed = m.callLog.status === 'missed' || m.callLog.direction === 'missed'
    const label = missed
      ? 'Missed call'
      : m.callLog.direction === 'in'
        ? 'Incoming'
        : 'Outgoing'
    const CallIcon = missed
      ? PhoneMissed
      : m.callLog.kind === 'video'
        ? Video
        : m.callLog.direction === 'in'
          ? PhoneIncoming
          : PhoneOutgoing
    const detail = [m.callLog.duration, m.timeLabel].filter(Boolean).join(' · ')
    return (
      <div className="flex justify-center py-1.5">
        <button
          type="button"
          onClick={() => onOpenCalls?.()}
          className={`flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[12px] font-bold ring-1 ${
            missed
              ? 'bg-red-50 text-brand-red ring-red-100'
              : 'bg-gray-100 text-gray-600 ring-gray-200/80'
          }`}
        >
          <CallIcon size={14} strokeWidth={2.4} />
          <span>
            {label} · {m.callLog.kind === 'video' ? 'Video' : 'Voice'}
            {detail ? ` · ${detail}` : ''}
          </span>
        </button>
      </div>
    )
  }

  const reactionsList = Array.isArray(m.reactions) ? m.reactions : []
  const hasReactions = reactionsList.length > 0

  return (
    <motion.div
      initial={animateIn ? { opacity: 0, y: 16, scale: 0.92 } : false}
      animate={{ opacity: 1, y: 0, scale: 1, x: dx }}
      transition={animateIn ? { type: 'spring', stiffness: 380, damping: 30 } : { duration: 0 }}
      style={{ touchAction: 'pan-y' }}
      onTouchStart={(e) => {
        startX.current = e.touches[0].clientX
        startY.current = e.touches[0].clientY
      }}
      onTouchMove={(e) => {
        const d = e.touches[0].clientX - startX.current
        const dy = Math.abs(e.touches[0].clientY - startY.current)
        if (d > 8 && d > dy * 1.2) {
          // horizontal reply gesture - don't fight vertical scroll
          setDx(Math.min(56, d * 0.4))
        }
      }}
      onContextMenu={(e) => { e.preventDefault(); onOpenAction?.() }}
      onDoubleClick={() => onOpenAction?.()}
      onTouchEnd={() => {
        if (dx > 28) onReply?.(m)
        setDx(0)
      }}
      className={`group/bubble flex w-full ${mine ? 'justify-end' : 'justify-start'} ${highlight ? 'z-10' : ''} ${hasReactions ? 'mb-3' : ''}`}
    >
      <div className="relative max-w-[min(78%,22rem)]">
      {/* Desktop: hover actions */}
      {!m.deleted && (
        <div
          className={`pointer-events-none absolute top-1/2 z-20 hidden -translate-y-1/2 items-center gap-0.5 rounded-full border border-black/5 bg-white px-0.5 py-0.5 shadow-md dark:border-white/10 dark:bg-[#1a222d] md:pointer-events-auto md:group-hover/bubble:flex ${
            mine ? 'right-full mr-1' : 'left-full ml-1'
          }`}
          onMouseLeave={() => setHoverReact(false)}
        >
          <button
            type="button"
            title="Reply"
            className="flex h-8 w-8 items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/10"
            onClick={(e) => {
              e.stopPropagation()
              onReply?.(m)
            }}
          >
            <Reply size={16} strokeWidth={2.2} />
          </button>
          <div className="relative">
            <button
              type="button"
              title="React"
              className="flex h-8 w-8 items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/10"
              onClick={(e) => {
                e.stopPropagation()
                setHoverReact((v) => !v)
              }}
            >
              <Smile size={16} strokeWidth={2.2} />
            </button>
            {hoverReact && (
              <div className="absolute bottom-full left-1/2 z-30 mb-1 flex -translate-x-1/2 gap-0.5 rounded-full border border-black/5 bg-white p-1 shadow-lg dark:border-white/10 dark:bg-[#1a222d]">
                {REACT_EMOJIS.map((em) => (
                  <button
                    key={em}
                    type="button"
                    className="flex h-8 w-8 items-center justify-center rounded-full text-base hover:bg-gray-100 dark:hover:bg-white/10"
                    onClick={(e) => {
                      e.stopPropagation()
                      setHoverReact(false)
                      onReactEmoji?.(m, em)
                    }}
                  >
                    {em}
                  </button>
                ))}
              </div>
            )}
          </div>
          {mine && (
            <button
              type="button"
              title="Delete"
              className="flex h-8 w-8 items-center justify-center rounded-full text-brand-red hover:bg-red-50 dark:hover:bg-red-500/10"
              onClick={(e) => {
                e.stopPropagation()
                onDeleteMsg?.(m)
              }}
            >
              <Trash2 size={15} strokeWidth={2.2} />
            </button>
          )}
          <button
            type="button"
            title="More"
            className="flex h-8 w-8 items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/10"
            onClick={(e) => {
              e.stopPropagation()
              onOpenAction?.()
            }}
          >
            <MoreVertical size={15} strokeWidth={2.2} />
          </button>
        </div>
      )}
      <div
        role={mine && m.state === 'failed' ? 'button' : undefined}
        tabIndex={mine && m.state === 'failed' ? 0 : undefined}
        onClick={() => {
          if (mine && m.state === 'failed') onRetry(m)
        }}
        className={`relative ${
          (() => {
            const letters = String(m.text || '').replace(/[^A-Za-z]/g, '').length
            const shortText = !m.image && !m.statusReply && letters > 0 && letters < 5
            // Short letter-only bubbles share one width so time + ticks never cram
            return shortText ? 'min-w-[8.25rem]' : 'min-w-[5.75rem]'
          })()
        } ${
          mine
            ? 'bubble-mine rounded-2xl rounded-br-sm text-white shadow-[0_4px_18px_-6px_rgba(0,0,0,0.28)]'
            : 'rounded-2xl rounded-bl-sm bg-white text-ink shadow-[0_4px_16px_-8px_rgba(15,23,42,0.18)] ring-1 ring-black/[0.04]'
        } ${mine && m.state === 'failed' ? 'ring-2 ring-red-300/80' : ''} ${
          highlight ? 'ring-2 ring-brand-purple shadow-[0_0_0_6px_rgba(var(--brand-shadow-rgb),0.22)] transition-shadow duration-700' : 'transition-shadow duration-700'
        }`}
      >
        {m.statusReply && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation()
              onOpenStatusReply?.(m.statusReply!)
            }}
            className={`mx-2 mt-2 w-[calc(100%-1rem)] overflow-hidden rounded-lg border-l-4 px-2.5 py-1.5 text-left text-[12px] font-semibold ${
              mine
                ? 'border-white/80 bg-white/15 text-white/95'
                : 'border-brand-purple bg-brand-purple/8 text-gray-700'
            }`}
          >
            <span className={`block text-[10px] font-black uppercase tracking-wide ${mine ? 'text-white/80' : 'text-brand-purple'}`}>
              Status
            </span>
            <span className="line-clamp-2">{m.statusReply.preview}</span>
            {m.statusReply.time ? (
              <span className={`mt-0.5 block text-[10px] ${mine ? 'text-white/55' : 'text-gray-400'}`}>{m.statusReply.time}</span>
            ) : null}
          </button>
        )}
        {(m.replyToId || m.replyToText) && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation()
              if (m.replyToId) onJumpTo?.(m.replyToId)
            }}
            className={`mx-2.5 mt-2 flex w-[calc(100%-1.25rem)] gap-2 border-l-[3px] px-2.5 py-1.5 text-left text-[12px] font-semibold ${
              mine
                ? 'border-white/80 bg-white/12 text-white/90'
                : 'border-brand-purple bg-gray-50/90 text-gray-600'
            }`}
          >
            <span className="line-clamp-2">{m.replyToText || 'Original message'}</span>
          </button>
        )}
        {m.image && (
          <button
            type="button"
            className={`block w-full overflow-hidden ${mine ? 'rounded-2xl rounded-br-sm' : 'rounded-2xl rounded-bl-sm'}`}
            onClick={(e) => {
              e.stopPropagation()
              onOpenImage?.(mediaUrl(m.image))
            }}
          >
            <img
              src={mediaUrl(m.image)}
              alt=""
              className={`sc-msg-image max-h-60 w-full bg-transparent object-contain ${mine ? 'rounded-2xl rounded-br-sm' : 'rounded-2xl rounded-bl-sm'}`}
              loading="lazy"
            />
          </button>
        )}

        {m.text && /^🎤 Voice note/.test(m.text) && (
          <div className={`flex items-center gap-3 px-3 py-2.5 ${mine ? '' : ''}`}>
            <button
              type="button"
              className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full ${
                mine ? 'bg-white/25 text-white' : 'bg-brand-purple/15 text-brand-purple'
              }`}
              aria-label="Play voice note"
              onClick={(e) => {
                e.stopPropagation()
                // placeholder: real audio src when media attached
              }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
            </button>
            <div className="min-w-0 flex-1">
              <div className={`flex h-8 items-center gap-0.5 ${mine ? 'opacity-90' : 'opacity-70'}`}>
                {Array.from({ length: 28 }).map((_, i) => (
                  <span
                    key={i}
                    className={`w-[3px] rounded-full ${mine ? 'bg-white' : 'bg-brand-purple'}`}
                    style={{ height: `${6 + ((i * 7) % 18)}px` }}
                  />
                ))}
              </div>
              <p className={`mt-0.5 text-[11px] font-bold ${mine ? 'text-white/75' : 'text-gray-500'}`}>
                {m.text.replace(/^🎤\s*/, '') || 'Voice note'}
              </p>
            </div>
          </div>
        )}

        {m.text && String(m.text) !== '📷 Photo' && !/^🎤 Voice note/.test(String(m.text)) && (
          <p className="whitespace-pre-wrap break-words px-3.5 pt-2.5 text-[15px] font-semibold leading-[1.35] tracking-[-0.01em]">
            {linkifyText(String(m.text || ''), { mine })}
          </p>
        )}

        <p
          className={`flex items-center justify-end gap-1 whitespace-nowrap px-3.5 pb-1.5 pt-0.5 text-[10px] font-bold tabular-nums tracking-wide ${
            mine ? 'text-white/70' : 'text-gray-400'
          }`}
        >
          {(m as any).editing ? <span className="mr-0.5 opacity-80">editing…</span> : (m as any).edited ? <span className="mr-0.5 opacity-80">edited</span> : null}
          {m.timeLabel || formatLocalTime(m.time)}
          <ReceiptTicks state={m.state} readReceipts={readReceipts} mine={mine} />
        </p>
      </div>
      {/* Reactions: sit on the bottom edge of the bubble (both sides) */}
      {hasReactions && (
        <div
          className={`pointer-events-none absolute z-[5] flex translate-y-[58%] flex-wrap gap-0.5 ${
            mine ? 'bottom-0 right-2' : 'bottom-0 left-2'
          }`}
        >
          {Object.entries(
            reactionsList.reduce((acc: Record<string, number>, r: any) => {
              const e = typeof r === 'string' ? r : r?.emoji
              if (!e) return acc
              acc[e] = (acc[e] || 0) + 1
              return acc
            }, {} as Record<string, number>),
          ).map(([emoji, count]) => (
            <span
              key={emoji}
              className="pointer-events-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-white px-1 text-[11px] shadow-sm ring-1 ring-black/10 dark:bg-[#1a222d] dark:ring-white/15"
            >
              {emoji}
              {(count as number) > 1 ? (
                <span className="ml-0.5 text-[9px] font-black text-gray-500">{count as number}</span>
              ) : null}
            </span>
          ))}
        </div>
      )}
      </div>
    </motion.div>
  )
})

function ChatWindowInner({ contactId, onBack, onCall, onOpenCalls, onOpenStatus }: Props) {
  const sendingKeysRef = useRef<Set<string>>(new Set())
  const { settings, contacts, chats, me, showToast, upsertChatPreview, statusList, setActiveConversationId, busyMap, presenceMap, typingPeers, refreshContacts } = useStore()
  // Resolve peer from contacts, or from an existing chat preview (notifications may pass contactId)
  const chatPreview =
    chats.find(
      (ch) =>
        ch.contactId === contactId ||
        ch.conversationId === contactId,
    ) || null
  const peerId = chatPreview?.contactId || contactId
  const isSelfChat = !!(me?.id && (peerId === me.id || contactId === me.id))
  const contactHit = contacts.find((x) => x.id === peerId || x.peerId === peerId)
  // Prefer contact book photo, fall back to chat-list photo (never force null)
  const c = contactHit
    ? {
        ...contactHit,
        photo: contactHit.photo || chatPreview?.photo || null,
        name: contactHit.name || chatPreview?.name || peerId,
        phone:
          contactHit.phone ||
          (contactHit as any).phone_number ||
          (chatPreview as any)?.phone ||
          '',
        hue:
          contactHit.hue ||
          (chatPreview?.hue as [string, string]) ||
          (['#7B2CBF', '#6389EB'] as [string, string]),
      }
    : chatPreview
      ? {
          id: peerId,
          name: chatPreview.name || peerId,
          username: (chatPreview as any).username || '',
          phone: (chatPreview as any).phone || (chatPreview as any).phone_number || '',
          bio: '',
          photo: chatPreview.photo ?? null,
          online: false,
          hue: (chatPreview.hue as [string, string]) || (['#7B2CBF', '#6389EB'] as [string, string]),
        }
      : {
          id: peerId,
          name: peerId,
          username: '',
          phone: '',
          bio: '',
          photo: null,
          online: false,
          hue: ['#7B2CBF', '#6389EB'] as [string, string],
        }
  const knownConv =
    chatPreview?.conversationId ||
    chats.find((ch) => ch.contactId === peerId || ch.contactId === (c as any).peerId)
      ?.conversationId ||
    null
  // Ensure avatar photo is warmed whenever we open this chat
  useEffect(() => {
    if (c?.photo) warmPhoto(String(c.id || peerId), c.photo, API_ORIGIN)
  }, [peerId, c?.photo, c?.id])

  useEffect(() => {
    let active = true
    setPeerBlocked(null)
    if (isSelfChat) {
      setPeerBlocked(false)
      return
    }
    void api
      .blockedContacts()
      .then(({ blocked }) => {
        if (active) setPeerBlocked(blocked.some((contact) => contact.id === peerId))
      })
      .catch(() => {
        if (active) setPeerBlocked(false)
      })
    return () => {
      active = false
    }
  }, [isSelfChat, peerId])

  const [conversationId, setConversationId] = useState<string | null>(knownConv)
  const [msgs, setMsgs] = useState<ApiMsg[]>([])
  const [text, setText] = useState(() => {
    try {
      const map = JSON.parse(kvGet('sc_composer_drafts') || '{}')
      return typeof map[contactId] === 'string' ? map[contactId] : ''
    } catch { return '' }
  })
  const [typing, setTyping] = useState(false)
  const [peerRecording, setPeerRecording] = useState(false)
  const [liveDraft, setLiveDraft] = useState<string | null>(null)
  const [subtitleTick, setSubtitleTick] = useState(0)
  useEffect(() => {
    const id = window.setInterval(() => setSubtitleTick((n) => n + 1), 3200)
    return () => clearInterval(id)
  }, [contactId])
  const [actionMsg, setActionMsg] = useState<ApiMsg | null>(null)
  const [highlightId, setHighlightId] = useState<string | null>(null)
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null)
  const [blockOpen, setBlockOpen] = useState(false)
  const [peerBlocked, setPeerBlocked] = useState<boolean | null>(null)
  const [lockPrompt, setLockPrompt] = useState(false)
  const [lockPinDraft, setLockPinDraft] = useState('')
  const [lockPinError, setLockPinError] = useState('')
  const [chatLocked, setChatLocked] = useState(() => {
    try {
      const map = JSON.parse(kvGet('sc_chat_locks') || '{}')
      return !!(map[contactId])
    } catch { return false }
  })
  const [unlockedThisSession, setUnlockedThisSession] = useState(false)
  const [cropSrc, setCropSrc] = useState<string | null>(null)
  const [selfNotesOpen, setSelfNotesOpen] = useState(false)
  const [lastSeenPhase, setLastSeenPhase] = useState<'label' | 'time'>('time')
  const [selfSettingsOpen, setSelfSettingsOpen] = useState(false)
  const [showSelfNotes, setShowSelfNotes] = useState(true)
  const [showSelfChecklists, setShowSelfChecklists] = useState(true)
  const [showSelfReminders, setShowSelfReminders] = useState(true)
  const [showSelfMsgs, setShowSelfMsgs] = useState(true)
  const [showSelfGames, setShowSelfGames] = useState(true)
  const [selfGameOpen, setSelfGameOpen] = useState(false)
  const [selfGameId, setSelfGameId] = useState<string | null>(null)
  const [selfActiveTab, setSelfActiveTab] = useState<'note' | 'checklist' | 'reminder' | 'game' | null>(null)
  const [selfSwitchWarn, setSelfSwitchWarn] = useState<null | { next: 'note' | 'checklist' | 'reminder' | 'game' }>(null)
  const [selfNoteItems, setSelfNoteItems] = useState<any[]>([])
  const [selfEditor, setSelfEditor] = useState<any | null>(null)
  const [msgAction, setMsgAction] = useState<{ id: string; clientKey?: string } | null>(null)
  const [editDraft, setEditDraft] = useState('')
  const longMsgTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const longMsgMoved = useRef(false)
  const [blocking, setBlocking] = useState(false)
  const [recording, setRecording] = useState(false)
  const [recordSecs, setRecordSecs] = useState(0)
  const mediaRecRef = useRef<MediaRecorder | null>(null)
  const recordChunks = useRef<Blob[]>([])
  const recordTimer = useRef<ReturnType<typeof setInterval> | null>(null)
  const [editText, setEditText] = useState('')
  const [editing, setEditing] = useState(false)
  const [forwardOpen, setForwardOpen] = useState(false)

  const [emoji, setEmoji] = useState(false)
  const [loading, setLoading] = useState(true)
  const [loadingOlder, setLoadingOlder] = useState(false)
  const [hasMoreOlder, setHasMoreOlder] = useState(true)
  const [pendingImage, setPendingImage] = useState<string | null>(null)
  const [replyTo, setReplyTo] = useState<ApiMsg | null>(null)
  const [profileOpen, setProfileOpen] = useState(false)
  // ESC → back to chats home
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault()
        if (profileOpen) setProfileOpen(false)
        else if (actionMsg) { setActionMsg(null); setEditing(false) }
        else onBack()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onBack, profileOpen, actionMsg])

  const [peerOnline, setPeerOnline] = useState(false)
  const [peerBusy, setPeerBusy] = useState<{ message?: string; until?: string | null } | null>(null)
  const [peerLastSeen, setPeerLastSeen] = useState<string | null>(null)
  const [chatMenu, setChatMenu] = useState(false)
  const [chatMuted, setChatMuted] = useState(() => {
    try {
      const map = JSON.parse(kvGet('sc_chat_muted') || '{}')
      return !!map[contactId]
    } catch {
      return false
    }
  })
  const [statusReply, setStatusReply] = useState<{ preview: string; time?: string; statusId?: string } | null>(null)
  const prevMsgCountRef = useRef(0)
  const inputRef = useRef<HTMLTextAreaElement | HTMLInputElement>(null)

  // Auto-focus composer when starting a reply (message swipe or status)
  useEffect(() => {
    if (replyTo || statusReply) {
      // Next frame so the reply bar is mounted
      requestAnimationFrame(() => {
        inputRef.current?.focus()
      })
    }
  }, [replyTo, statusReply])
  const msgRefs = useRef<Record<string, HTMLDivElement | null>>({})
  const end = useRef<HTMLDivElement>(null)
  const msgsScrollRef = useRef<HTMLDivElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const convRef = useRef<string | null>(knownConv)
  const ensurePromise = useRef<Promise<string | null> | null>(null)
  const animatedKeys = useRef<Set<string>>(new Set())
  convRef.current = conversationId

  const ensureConversation = async (): Promise<string | null> => {
    if (convRef.current) return convRef.current
    if (ensurePromise.current) return ensurePromise.current

    // Prefer existing conversation from chat list (works even without username)
    const fromList =
      chats.find(
        (ch) =>
          ch.contactId === peerId ||
          ch.contactId === (c as any).peerId ||
          ch.conversationId === contactId,
      )?.conversationId || null
    if (fromList) {
      setConversationId(fromList)
      convRef.current = fromList
      return fromList
    }

    const peer = peerId || contactId
    const isSelf = !!me?.id && peer === me.id
    let username = ((c as any).username || '').replace(/^@/, '').trim()
    if (!username && isSelf) username = (me?.username || '').replace(/^@/, '').trim()
    if (!username && !peer) {
      showToast('Could not open chat - contact is missing')
      return null
    }
    ensurePromise.current = (async () => {
      try {
        const preview = await api.openPrivateChat(
          username ? { username, userId: peer } : { userId: peer },
        )
        const cid = preview.conversationId || null
        if (cid) {
          setConversationId(cid)
          convRef.current = cid
          upsertChatPreview({
            contactId: peerId,
            conversationId: cid,
            name: preview.name || (c as any).name,
            last: preview.last,
            iso: preview.iso,
            unread: 0,
          })
        }
        return cid
      } catch (e: any) {
        showToast(e?.message || 'Could not open chat')
        return null
      } finally {
        ensurePromise.current = null
      }
    })()
    return ensurePromise.current
  }

  const load = async (silent = false) => {
    try {
      const cid = await ensureConversation()
      if (!cid) return
      // Paint disk/memory cache immediately (no blank thread)
      const cached = getCachedMessages(cid)
      if (cached?.length) {
        setMsgs((prev) => (prev.length ? prev : cached))
        if (!silent) setLoading(false)
      }
      const { messages, nextCursor } = await api.messages(cid, { limit: 50 })
      setThreadCursor(cid, nextCursor || (messages.length ? messages[0]?.id : null))
      setHasMoreOlder(!!nextCursor || messages.length >= 50)
      // Incoming messages we just pulled: ack delivered before/while painting (no await)
      for (const m of messages) {
        const mine = m.mine ?? m.from === me?.id
        if (!mine && m.id && !String(m.id).startsWith('local-')) {
          void api.markDelivered(m.id).catch(() => {})
        }
      }
      setMsgs((prev) => {
        // Merge server history into UI - NEVER drop a bubble already on screen
        // (server lag / partial pages used to wipe messages for a few seconds)
        const prevById = new Map(prev.map((m) => [m.id, m]))
        const claimedKeys = new Set<string>()
        const claimedIds = new Set<string>()
        const mapped = messages.map((sm: any) => {
          const prior = prevById.get(sm.id)
          if (prior) {
            if (prior.clientKey) claimedKeys.add(prior.clientKey)
            claimedIds.add(prior.id)
            claimedIds.add(sm.id)
            return {
              ...sm,
              clientKey: prior.clientKey || sm.clientKey || sm.id,
              mine: prior.mine ?? sm.mine,
              state: pickState(sm.state, prior.state),
              edited: !!(prior as any).edited || !!(sm as any).edited,
              text: sm.text || prior.text,
              image: sm.image ?? prior.image,
              timeLabel: sm.timeLabel || prior.timeLabel,
              replyToId: sm.replyToId || prior.replyToId,
              replyToText: sm.replyToText || prior.replyToText,
            }
          }
          // Match optimistic local by clientKey or same body + direction
          const byCk =
            (sm as any).clientKey &&
            prev.find(
              (p) =>
                p.clientKey === (sm as any).clientKey &&
                !claimedKeys.has(p.clientKey as string),
            )
          const match =
            byCk ||
            prev.find(
              (p) =>
                String(p.id).startsWith('local-') &&
                p.clientKey &&
                !claimedKeys.has(p.clientKey) &&
                (p.mine ?? true) &&
                (p.text === sm.text ||
                  (!!p.image && !!sm.image && p.image === sm.image)) &&
                (!!p.image === !!sm.image) &&
                Math.abs((Date.parse(p.time) || 0) - (Date.parse(sm.time) || 0)) < 120000,
            )
          if (match) {
            if (match.clientKey) claimedKeys.add(match.clientKey)
            claimedIds.add(match.id)
            claimedIds.add(sm.id)
            return {
              ...sm,
              clientKey: match.clientKey || sm.id,
              mine: match.mine ?? true,
              state: pickState(sm.state, match.state),
              text: sm.text || match.text,
              image: sm.image ?? match.image,
              timeLabel: sm.timeLabel || match.timeLabel,
              replyToId: sm.replyToId || match.replyToId,
              replyToText: sm.replyToText || match.replyToText,
            }
          }
          claimedIds.add(sm.id)
          return { ...sm, clientKey: (sm as any).clientKey || sm.id }
        })
        // Keep every on-screen row the server did not claim (local OR real ids)
        const keepPrev = prev.filter((m) => {
          if (claimedIds.has(m.id)) return false
          if (m.clientKey && claimedKeys.has(m.clientKey)) return false
          return true
        })
        const merged = [...mapped, ...keepPrev].sort((a, b) => {
          const ta = Date.parse(a.time) || 0
          const tb = Date.parse(b.time) || 0
          return ta - tb
        })
        // Dedupe by clientKey preferring server ids over local-
        const byKey = new Map<string, (typeof merged)[0]>()
        for (const m of merged) {
          const k = m.clientKey || m.id
          const existing = byKey.get(k)
          if (!existing) {
            byKey.set(k, m)
            continue
          }
          // Prefer non-local id and higher receipt state
          const prefer =
            (!String(m.id).startsWith('local-') && String(existing.id).startsWith('local-')) ||
            rankState(m.state) > rankState(existing.state)
          byKey.set(k, prefer ? { ...existing, ...m, clientKey: k, state: pickState(m.state, existing.state) } : {
            ...m,
            ...existing,
            clientKey: k,
            state: pickState(existing.state, m.state),
          })
        }
        const stable = Array.from(byKey.values()).sort(
          (a, b) => (Date.parse(a.time) || 0) - (Date.parse(b.time) || 0),
        )
        if (sameMsgList(prev, stable)) return prev
        if (!stable.length && prev.length) return prev
        void applyThreadMessages(cid, stable, 'merge')
        return stable
      })
      api.markRead(cid).catch(() => {})
    } catch (e: any) {
      if (!silent) showToast(e?.message || 'Could not load messages')
    } finally {
      if (!silent) setLoading(false)
    }
  }

  const loadOlder = useCallback(async () => {
    const cid = convRef.current || conversationId
    if (!cid || !hasMoreOlder || loadingOlder || isLoadingOlder(cid)) return
    const oldest = msgs.find((m) => m.id && !String(m.id).startsWith('local-'))
    const beforeId = getThreadCursor(cid) || oldest?.id
    if (!beforeId) {
      setHasMoreOlder(false)
      return
    }
    const scroller = msgsScrollRef.current
    const prevHeight = scroller?.scrollHeight || 0
    setLoadingOlder(true)
    markLoadingOlder(cid, true)
    try {
      const { messages, nextCursor } = await api.messages(cid, { limit: 40, beforeId: String(beforeId) })
      if (!messages.length) {
        setHasMoreOlder(false)
        setThreadCursor(cid, null)
        return
      }
      await prependOlderMessages(cid, messages, nextCursor)
      setMsgs((prev) => mergeMessageLists(prev, messages))
      setHasMoreOlder(!!nextCursor)
      setThreadCursor(cid, nextCursor)
      requestAnimationFrame(() => {
        if (!scroller) return
        const delta = scroller.scrollHeight - prevHeight
        if (delta > 0) scroller.scrollTop += delta
      })
    } catch {
      /* keep hasMore; user can scroll again */
    } finally {
      markLoadingOlder(cid, false)
      setLoadingOlder(false)
    }
  }, [conversationId, hasMoreOlder, loadingOlder, msgs])

  // Subscribe to central message store for this thread
  useEffect(() => {
    const cid = conversationId || knownConv
    if (!cid) return
    return subscribeThread(cid, (list) => {
      setMsgs((prev) => {
        if (sameMsgList(prev, list)) return prev
        // Prefer in-flight optimistic edits already on screen (avoid snap-back to old body)
        if (!prev.length) return list
        const byId = new Map(prev.map((m) => [m.id, m]))
        const byCk = new Map(prev.filter((m) => m.clientKey).map((m) => [m.clientKey!, m]))
        return list.map((incoming) => {
          const local = byId.get(incoming.id) || (incoming.clientKey ? byCk.get(incoming.clientKey) : undefined)
          if (!local) return incoming
          // Local marked edited with different text wins until store catches up
          if ((local as any).edited && local.text && local.text !== incoming.text) {
            return { ...incoming, text: local.text, edited: true }
          }
          if ((local as any).editing) {
            return { ...incoming, text: local.text, editing: true }
          }
          return incoming
        })
      })
    })
  }, [conversationId, knownConv])

  // When home list later provides conversationId, adopt it (fixes empty inbox)
  useEffect(() => {
    if (conversationId) return
    const found =
      chats.find(
        (ch) =>
          ch.contactId === peerId ||
          ch.contactId === contactId ||
          ch.conversationId === contactId,
      )?.conversationId || null
    if (found) {
      setConversationId(found)
      convRef.current = found
      void load(true)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chats, contactId, peerId, conversationId])

  useEffect(() => {
    setLoading(true)
    // Fresh open: do NOT animate history - only new/outgoing later
    animatedKeys.current = new Set()
    setConversationId(knownConv)
    convRef.current = knownConv
    const seedKeys = (list: ApiMsg[]) => {
      for (const m of list) {
        const k = m.clientKey || m.id
        if (k) animatedKeys.current.add(k)
      }
    }
    // Instant paint from memory/disk cache for this thread
    if (knownConv) {
      const mem = getCachedMessages(knownConv)
      if (mem?.length) {
        seedKeys(mem)
        setMsgs(mem)
        setLoading(false)
        // Jump to latest without animation
        requestAnimationFrame(() => {
          end.current?.scrollIntoView({ behavior: 'auto', block: 'end' })
        })
      } else {
        setMsgs([])
        void hydrateThread(knownConv).then((disk) => {
          if (disk?.length && convRef.current === knownConv) {
            seedKeys(disk)
            setMsgs((prev) => {
              const merged = mergeMessageLists(disk, prev)
              void applyThreadMessages(knownConv, merged, 'merge')
              return merged
            })
            setLoading(false)
            requestAnimationFrame(() => {
              end.current?.scrollIntoView({ behavior: 'auto', block: 'end' })
            })
          }
        })
      }
    } else {
      setMsgs([])
    }
    // Instant blue ticks for the sender: as soon as this chat surface is open,
    // mark read - do not wait for message history to finish loading.
    if (knownConv && hasAccessToken()) {
      void api.markRead(knownConv).catch(() => {})
      wsReceipt({ conversationId: knownConv, messageId: 'all', state: 'read' })
      // Clear unread badge on home immediately
      upsertChatPreview({
        contactId: peerId,
        conversationId: knownConv,
        unread: 0,
      })
    }
    if (!hasAccessToken()) {
      setLoading(false)
      return
    }
    load(false)
    const t = setInterval(() => {
      if (hasAccessToken() && document.visibilityState === 'visible') load(true)
    }, 20000)
    return () => clearInterval(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contactId])

  // Live message + receipt packets for the open conversation
  useEffect(() => {
    const onMsg = (ev: Event) => {
      const detail = (ev as CustomEvent).detail as {
        cid: string
        m: {
          id: string
          from: string
          text?: string
          time?: string
          image?: string | null
          state?: string
          reply_to_message_id?: string | null
          reply_to_text?: string | null
        }
        mine?: boolean
      }
      if (!detail?.cid || !detail?.m?.id) return
      const openCid = convRef.current
      if (!openCid || detail.cid !== openCid) return
      const mine = detail.mine ?? detail.m.from === me?.id
      let text = String(
        detail.m.text ?? (detail.m as any).content ?? '',
      ).trim()
      if (!text && detail.m.image) text = '📷 Photo'
      if (!text) text = 'Message'
      let statusReply: { preview: string; time?: string; statusId?: string } | null = null
      {
        const parsed = parseStatusReply(text)
        if (parsed.statusReply) {
          statusReply = parsed.statusReply
          text = parsed.text || 'Status reply'
        }
      }
      const ck = (detail.m as any).client_key || (detail.m as any).clientKey || detail.m.id
      const incoming = {
        id: detail.m.id,
        clientKey: ck,
        from: detail.m.from,
        to: contactId,
        text,
        image: detail.m.image || null,
        time: detail.m.time || new Date().toISOString(),
        timeLabel: formatLocalTime(detail.m.time || Date.now()),
        state: (detail.m.state as any) || (mine ? 'sent' : undefined),
        mine,
        replyToId: detail.m.reply_to_message_id || null,
        replyToText: detail.m.reply_to_text || null,
        statusReply,
      }
      // Delivered was already fired in the store handler before this event.
      setMsgs((prev) => {
        // Already have this server id or clientKey, never append a second bubble
        const exists = prev.some(
          (x) =>
            x.id === incoming.id ||
            x.clientKey === incoming.id ||
            (incoming.clientKey && (x.clientKey === incoming.clientKey || x.id === incoming.clientKey)),
        )
        if (exists) {
          return prev.map((x) =>
            x.id === incoming.id ||
            x.clientKey === incoming.id ||
            (incoming.clientKey && (x.clientKey === incoming.clientKey || x.id === incoming.clientKey))
              ? {
                  ...x,
                  id: incoming.id,
                  clientKey: x.clientKey || incoming.clientKey,
                  state: rankState(incoming.state) >= rankState(x.state) ? (incoming.state as any) : x.state,
                }
              : x,
          )
        }
        // A distinct server id is a distinct message, even when text is identical.
        return [...prev, incoming as any].sort(
          (a, b) => (Date.parse(a.time) || 0) - (Date.parse(b.time) || 0),
        )
      })
      if (!mine && openCid) {
        void api.markRead(openCid).catch(() => {})
      }
    }
    const onRcpt = (ev: Event) => {
      const detail = (ev as CustomEvent).detail as { cid: string; id: string; s: string }
      if (!detail?.id) return
      const openCid = convRef.current
      if (detail.cid && openCid && detail.cid !== openCid) return
      const nextState = detail.s as any
      setMsgs((prev) => {
        let changed = false
        const next = prev.map((x) => {
          // Match server id or clientKey (acks/receipts may use either)
          if (x.id !== detail.id && x.clientKey !== detail.id) return x
          const rank: Record<string, number> = {
            pending: 0,
            failed: 0,
            sent: 1,
            delivered: 2,
            read: 3,
          }
          if ((rank[nextState || ''] ?? 0) <= (rank[x.state || ''] ?? 0)) return x
          changed = true
          return { ...x, state: nextState }
        })
        if (changed && openCid) {
          void applyThreadMessages(openCid, next.filter((x) => x.id === detail.id || x.clientKey === detail.id), 'merge')
        }
        return changed ? next : prev
      })
    }
    const onAck = (ev: Event) => {
      const detail = (ev as CustomEvent).detail as {
        ck?: string
        ok: boolean
        id?: string
        s?: string
        ts?: string
      }
      if (!detail?.ck) return
      if (!detail.ok) {
        const openCid = convRef.current
        const cached = getCachedMessages(openCid)?.find(
          (message) => message.id === detail.ck || message.clientKey === detail.ck,
        )
        if (cached && openCid) {
          void mergeCachedMessages(openCid, [{ ...cached, state: 'failed' }])
        }
        setMsgs((prev) =>
          prev.map((x) =>
            x.clientKey === detail.ck || x.id === detail.ck ? { ...x, state: 'failed' } : x,
          ),
        )
        return
      }
      const openCid = convRef.current
      const cached = getCachedMessages(openCid)?.find(
        (message) => message.id === detail.ck || message.clientKey === detail.ck,
      )
      if (cached && openCid) {
        void mergeCachedMessages(openCid, [
          {
            ...cached,
            id: detail.id || cached.id,
            state: pickState((detail.s as any) || 'sent', cached.state),
            time: detail.ts || cached.time,
            timeLabel: detail.ts ? formatLocalTime(detail.ts) : cached.timeLabel,
          },
        ])
      }
      setMsgs((prev) =>
        prev.map((x) =>
          x.clientKey === detail.ck || x.id === detail.ck
            ? {
                ...x,
                id: detail.id || x.id,
                clientKey: x.clientKey || detail.ck,
                state: pickState((detail.s as any) || 'sent', x.state),
                time: detail.ts || x.time,
                timeLabel: detail.ts ? formatLocalTime(detail.ts) : x.timeLabel,
              }
            : x,
        ),
      )
      if (detail.ck) void removeOutbox(detail.ck)
      upsertChatPreview({
        contactId: peerId,
        conversationId: convRef.current || undefined,
        state: (detail.s as any) || 'sent',
        mine: true,
      })
    }
    window.addEventListener('sc:rt-msg', onMsg)
    window.addEventListener('sc:rt-rcpt', onRcpt)
    const onEdit = (ev: Event) => {
      const d = (ev as CustomEvent).detail as { cid: string; id: string; text: string }
      if (!d?.id) return
      const openCid = convRef.current
      if (d.cid && openCid && d.cid !== openCid) return
      const nextText = String(d.text || '')
      setMsgs((prev) => {
        let changed = false
        const next = prev.map((x) => {
          if (x.id !== d.id && x.clientKey !== d.id) return x
          if (x.text === nextText && (x as any).edited) return x
          changed = true
          return { ...x, text: nextText, edited: true, editing: false }
        })
        if (changed && openCid) {
          const patched = next.filter((x) => x.id === d.id || x.clientKey === d.id)
          if (patched.length) void applyThreadMessages(openCid, patched, 'merge')
        }
        return changed ? next : prev
      })
    }
    const onReact = (ev: Event) => {
      const d = (ev as CustomEvent).detail as {
        cid: string
        id: string
        emoji: string
        userId: string
        removed: boolean
      }
      if (!d?.id || !d.emoji) return
      const openCid = convRef.current
      if (d.cid && openCid && d.cid !== openCid) return
      setMsgs((prev) =>
        prev.map((x) => {
          if (x.id !== d.id && x.clientKey !== d.id) return x
          let reactions = [...(x.reactions || [])]
          // one reaction per user
          reactions = reactions.filter((r: any) => r.user_id !== d.userId)
          if (!d.removed) {
            reactions.push({ emoji: d.emoji, user_id: d.userId })
          }
          return { ...x, reactions }
        }),
      )
    }
    window.addEventListener('sc:rt-edit', onEdit)
    window.addEventListener('sc:rt-react', onReact)

    window.addEventListener('sc:rt-ack', onAck)
    return () => {
      window.removeEventListener('sc:rt-msg', onMsg)
      window.removeEventListener('sc:rt-rcpt', onRcpt)
      window.removeEventListener('sc:rt-edit', onEdit)
      window.removeEventListener('sc:rt-react', onReact)
      window.removeEventListener('sc:rt-ack', onAck)
    }
  }, [contactId, me?.id, peerId, upsertChatPreview])

  // Live typing stream — keep packets flowing while the composer has text so
  // the peer never loses "typing…" / live draft during short pauses.
  const liveSendRef = useRef<{ last: string; at: number }>({ last: '', at: 0 })
  const liveClearTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const liveHeartbeatRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const liveDraftSeenAt = useRef(0)

  const emitLiveOrTyping = useCallback(
    (draft: string, force = false) => {
      const to = peerId || contactId
      if (!to || !hasAccessToken()) return
      if (settings.typingIndicator === false) return

      const hideMine =
        !!(settings as any).hideLiveTyping &&
        (settings as any).subscriptionPlan === 'premium'
      const typingNow = draft.length > 0
      const now = Date.now()
      // Skip identical empty clears; allow force heartbeat for non-empty draft
      if (!force && draft === liveSendRef.current.last && draft === '') return
      if (!force && draft === liveSendRef.current.last && now - liveSendRef.current.at < 400) return
      liveSendRef.current = { last: draft, at: now }

      try {
        if (isRealtimeOpen()) {
          if (hideMine) {
            wsTyping(to, typingNow)
          } else {
            wsLiveTyping(to, draft)
          }
        } else if (typingNow) {
          void api.setTyping(to).catch(() => {})
        }
      } catch {
        /* */
      }
    },
    [peerId, contactId, settings],
  )

  const pushLiveDraft = useCallback(
    (draft: string) => {
      emitLiveOrTyping(draft, false)
      // Heartbeat while local composer still has text
      if (liveHeartbeatRef.current) {
        clearInterval(liveHeartbeatRef.current)
        liveHeartbeatRef.current = null
      }
      if (draft.length > 0) {
        liveHeartbeatRef.current = setInterval(() => {
          const last = liveSendRef.current.last
          if (!last) {
            if (liveHeartbeatRef.current) {
              clearInterval(liveHeartbeatRef.current)
              liveHeartbeatRef.current = null
            }
            return
          }
          emitLiveOrTyping(last, true)
        }, 2500)
      }
    },
    [emitLiveOrTyping],
  )

  useEffect(() => {
    return () => {
      if (liveClearTimer.current) clearTimeout(liveClearTimer.current)
      if (liveHeartbeatRef.current) clearInterval(liveHeartbeatRef.current)
      // Clear peer's live preview when leaving the chat
      const to = peerId || contactId
      if (to && isRealtimeOpen()) {
        try {
          wsLiveTyping(to, '')
          wsTyping(to, false)
        } catch {
          /* */
        }
      }
    }
  }, [peerId, contactId])

  const openedOnce = useRef(false)

  const openSelfTab = (tab: 'note' | 'checklist' | 'reminder' | 'game') => {
    const busy =
      (selfEditor && (selfEditor.title || selfEditor.body || (selfEditor.items || []).some((x: any) => x.text))) ||
      (selfGameOpen && (selfActiveTab === 'game'))
    // Warn if leaving editor with content or leaving active game
    if (selfEditor && tab !== (selfEditor.kind === 'checklist' ? 'checklist' : selfEditor.kind === 'reminder' ? 'reminder' : 'note')) {
      if (selfEditor.title || selfEditor.body || (selfEditor.items || []).some((x: any) => (x.text || '').trim())) {
        setSelfSwitchWarn({ next: tab })
        return
      }
    }
    if (selfGameOpen && tab !== 'game') {
      setSelfSwitchWarn({ next: tab })
      return
    }
    applySelfTab(tab)
  }
  const applySelfTab = (tab: 'note' | 'checklist' | 'reminder' | 'game') => {
    setSelfSwitchWarn(null)
    setSelfActiveTab(tab)
    if (tab === 'game') {
      setSelfEditor(null)
      setSelfGameId(null)
      setSelfGameOpen(true)
      return
    }
    setSelfGameOpen(false)
    setSelfGameId(null)
    const now = new Date().toISOString()
    const kind = tab
    setSelfEditor({
      id: `${kind}_${Date.now()}`,
      kind,
      title: '',
      body: '',
      items: kind === 'checklist' ? [{ id: `i_${Date.now()}`, text: '', done: false }] : undefined,
      remindAt: kind === 'reminder' ? now : undefined,
      createdAt: now,
      updatedAt: now,
      _isNew: true,
    })
  }

  const pinToBottom = (smooth = false) => {
    const el = msgsScrollRef.current
    if (el) {
      if (smooth) {
        el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' })
      } else {
        el.scrollTop = el.scrollHeight
      }
      return
    }
    end.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto', block: 'end' })
  }
  useEffect(() => {
    // Always land on last message instantly (no smooth scroll)
    const pin = () => pinToBottom(false)
    pin()
    requestAnimationFrame(() => {
      pin()
      requestAnimationFrame(pin)
    })
    // Layout can settle late (images / fonts) — a few hard pins
    const t1 = window.setTimeout(pin, 50)
    const t2 = window.setTimeout(pin, 150)
    const t3 = window.setTimeout(pin, 320)
    openedOnce.current = true
    return () => {
      window.clearTimeout(t1)
      window.clearTimeout(t2)
      window.clearTimeout(t3)
    }
  }, [msgs.length, pendingImage, liveDraft, typing, loading, selfNoteItems.length, conversationId, contactId])
  // Always reveal typing / live bubble at the bottom
  useEffect(() => {
    if (!typing && !(liveDraft && liveDraft.length)) return
    requestAnimationFrame(() => {
      pinToBottom(true)
      requestAnimationFrame(() => pinToBottom(true))
    })
  }, [typing, liveDraft])
  // Register open conversation so inbound WS marks read (no home unread bump)
  useEffect(() => {
    const cid = conversationId
    if (cid) setActiveConversationId(cid)
    return () => {
      setActiveConversationId(null)
    }
  }, [conversationId, setActiveConversationId])

  useEffect(() => {
    openedOnce.current = false
  }, [contactId])

  // Chime only when a NEW peer message is printed (never on history load / receipt merge)
  const knownMsgIdsRef = useRef<Set<string>>(new Set())
  useEffect(() => {
    // Seed on first non-empty paint without sound
    if (knownMsgIdsRef.current.size === 0 && msgs.length) {
      for (const m of msgs) knownMsgIdsRef.current.add(m.clientKey || m.id)
      return
    }
    if (chatMuted) {
      for (const m of msgs) knownMsgIdsRef.current.add(m.clientKey || m.id)
      return
    }
    let played = false
    for (const m of msgs) {
      const k = m.clientKey || m.id
      if (knownMsgIdsRef.current.has(k)) continue
      knownMsgIdsRef.current.add(k)
      const mine = m.mine ?? m.from === me?.id
      if (!mine && !played) {
        playInboxLandingChime()
        played = true
      }
    }
  }, [msgs, chatMuted, me?.id])
  useEffect(() => {
    knownMsgIdsRef.current = new Set()
  }, [contactId])

  const deliverMessage = async (
    localId: string,
    body: string,
    img: string | null,
    opts?: {
      replyToId?: string
      statusReply?: { preview: string; time?: string; statusId?: string }
    },
    optimistic?: ApiMsg,
  ) => {
    if (sendingKeysRef.current.has(localId)) return
    sendingKeysRef.current.add(localId)
    try {
      const cid = await ensureConversation()
      if (!cid) {
        setMsgs((m) => m.map((x) => (x.id === localId ? { ...x, state: 'failed' } : x)))
        upsertChatPreview({
          contactId: (c as any).peerId || contactId,
          conversationId: conversationId || undefined,
          last: body || (img ? '📷 Photo' : ''),
          state: 'failed',
          mine: true,
          name: c.name,
          photo: c.photo,
          hue: c.hue,
        })
        showToast('Could not open chat - tap message to retry')
        return
      }
      if (cid && cid !== conversationId) {
        setConversationId(cid)
        convRef.current = cid
      }
      if (optimistic) {
        await applyThreadMessages(cid, [{ ...optimistic, conversationId: cid }], 'merge')
      }
      // Prefer persistent WebSocket (no new HTTP handshake)
      let wsText = body || ''
      if (opts?.statusReply) {
        wsText = encodeStatusReply(wsText, {
          preview: opts.statusReply.preview || '',
          time: opts.statusReply.time,
          statusId: opts.statusReply.statusId,
        })
      }
      const usedWs = isRealtimeOpen() && wsSendMessage({
        conversationId: cid,
        text: wsText,
        clientKey: localId,
        image: img,
        replyToId: opts?.replyToId || undefined,
      })
      if (usedWs) {
        // Socket accepted the frame → treat as sent until ack upgrades id/state
        setMsgs((m) =>
          m.map((x) =>
            x.id === localId || x.clientKey === localId
              ? { ...x, state: pickState('sent', x.state) }
              : x,
          ),
        )
        upsertChatPreview({
          contactId: (c as any).peerId || contactId,
          conversationId: cid,
          state: 'sent',
          mine: true,
        })
        void removeOutbox(localId)
        sendingKeysRef.current.delete(localId)
        // sc:rt-ack still maps server id + may bump delivered/read
        return
      }
      const { message } = await api.send(cid, body || (img ? '📷 Photo' : ''), img, {
        clientKey: localId,
        ...opts,
      })
      const confirmed = {
        ...message,
        clientKey: message.clientKey || localId,
        conversationId: cid,
      }
      await applyThreadMessages(cid, [confirmed], 'merge')
      // In-place receipt update only - never replace/remove the printed bubble
      setMsgs((m) =>
        m.map((x) =>
          x.id === localId || x.clientKey === localId
            ? {
                ...x,
                id: message.id || x.id,
                clientKey: x.clientKey || localId,
                mine: true,
                state: pickState(message.state || 'sent', x.state),
                timeLabel: x.timeLabel || message.timeLabel,
                time: x.time || message.time,
                text: x.text || message.text,
                image: x.image ?? message.image,
                replyToId: x.replyToId || message.replyToId || null,
                replyToText: x.replyToText || message.replyToText || null,
                statusReply: x.statusReply || message.statusReply || null,
              }
            : x,
        ),
      )
      void removeOutbox(localId)
      sendingKeysRef.current.delete(localId)
      upsertChatPreview({
        contactId: (c as any).peerId || contactId,
        conversationId: cid,
        last: message.text || body || (img ? '📷 Photo' : ''),
        state: (message.state as any) || 'sent',
        mine: true,
        name: c.name,
        photo: c.photo,
        hue: c.hue,
        iso: message.time || utcNowIso(),
        time: message.timeLabel,
      })
    } catch (e: any) {
      sendingKeysRef.current.delete(localId)
      const failedCid = convRef.current || conversationId || knownConv
      const cached = getCachedMessages(failedCid)?.find(
        (message) => message.id === localId || message.clientKey === localId,
      )
      if (cached && failedCid) {
        void mergeCachedMessages(failedCid, [{ ...cached, state: 'failed' }])
      }
      setMsgs((m) => m.map((x) => (x.id === localId ? { ...x, state: 'failed' } : x)))
      upsertChatPreview({
        contactId: (c as any).peerId || contactId,
        conversationId: conversationId || undefined,
        last: body || (img ? '📷 Photo' : ''),
        state: 'failed',
        mine: true,
        name: c.name,
        photo: c.photo,
        hue: c.hue,
      })
      showToast(e?.message || 'Message failed - tap to retry')
    }
  }

  const send = async () => {
    const t = text.trim()
    if (!t && !pendingImage) return
    const body = t
    const img = pendingImage
    const replySnap = replyTo
    const statusSnap = statusReply
    setText('')
    setPendingImage(null)
    setEmoji(false)
    setReplyTo(null)
    setStatusReply(null)
    // Stop live preview on peer as soon as we send
    pushLiveDraft('')
    try {
      const map = JSON.parse(kvGet('sc_composer_drafts') || '{}')
      delete map[contactId]
      kvSet('sc_composer_drafts', JSON.stringify(map))
    } catch { /* */ }

    const localId = newClientMessageKey()
    const nowIso = utcNowIso()
    const timeLabel = formatLocalTime(nowIso)
    const previewText = statusSnap
      ? (body ? `Status reply: ${body}` : 'Status reply')
      : body || (img ? '📷 Photo' : '')
    const optimistic: ApiMsg = {
      id: localId,
      clientKey: localId,
      from: me?.id || '',
      to: contactId,
      text: previewText,
      image: img,
      time: nowIso,
      timeLabel,
      state: 'pending',
      mine: true,
      replyToId: replySnap?.id,
      replyToText: replySnap?.text || (replySnap?.image ? '📷 Photo' : undefined),
      statusReply: statusSnap,
    }
    // UI first - message window + chats home at the same time
    setMsgs((m) => [...m, optimistic])
    upsertChatPreview({
      contactId: (c as any).peerId || contactId,
      conversationId: conversationId || knownConv || undefined,
      last: previewText,
      time: timeLabel,
      iso: nowIso,
      unread: 0,
      mine: true,
      state: 'pending',
      name: c.name,
      photo: c.photo,
      hue: c.hue,
    })
    // Persist unsent until server ack (survives refresh)
    void putOutbox({
      id: localId,
      conversationId: conversationId || knownConv || '',
      contactId: (c as any).peerId || contactId,
      text: body,
      image: img,
      createdAt: nowIso,
      status: 'queued',
      attempts: 0,
      nextAttemptAt: 0,
      replyToId: replySnap?.id,
    })
    // Backend later
    void deliverMessage(localId, body, img, {
      replyToId: replySnap?.id,
      statusReply: statusSnap || undefined,
    }, optimistic)
  }

  const retryFailed = (m: ApiMsg) => {
    if (m.state !== 'failed') return
    const key = m.clientKey || m.id
    setMsgs((list) =>
      list.map((x) => (x.id === m.id || x.clientKey === key ? { ...x, state: 'pending' } : x)),
    )
    showToast('Retrying…')
    void deliverMessage(
      key,
      m.text === '📷 Photo' ? '' : m.text,
      m.image || null,
      undefined,
      { ...m, state: 'pending' },
    )
  }

  const onPickImage = async (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f || !f.type.startsWith('image/')) return
    if (f.size > 25 * 1024 * 1024) {
      showToast('Image is too large')
      return
    }
    try {
      const data = await fileToDataUrl(f)
      setCropSrc(data)
    } catch {
      showToast('Could not process image')
    }
  }



  // Presence seed from REST once; live updates come from presenceMap / WS.
  // Avoid aggressive polling that overwrites sticky online/busy/typing state.
  useEffect(() => {
    let alive = true
    const load = async () => {
      try {
        const p = await api.presence(peerId || contactId)
        if (!alive) return
        // Only promote to online from REST; offline is handled by debounced WS path
        if (p.online) setPeerOnline(true)
        if (p.lastSeen) setPeerLastSeen(p.lastSeen || null)
        const busy = !!(p as any).busy
        const msg = (p as any).busyMessage || (p as any).busy_message || ''
        const until = (p as any).busyUntil || (p as any).busy_until || null
        if (busy && msg) setPeerBusy({ message: msg, until })
        else if (!busy) setPeerBusy(null)
      } catch {
        /* */
      }
    }
    load()
    // Light refresh only — WS is source of truth while connected
    const id = setInterval(load, 90000)
    return () => {
      alive = false
      clearInterval(id)
    }
  }, [contactId, peerId])

  // Mirror global presenceMap so online stays steady with the home-list dots
  useEffect(() => {
    const keys = [peerId, contactId, (c as any)?.peerId, (c as any)?.id].filter(Boolean).map(String)
    const mapped = keys.some((k) => presenceMap?.[k] === true)
    if (mapped) setPeerOnline(true)
    else if (keys.some((k) => presenceMap?.[k] === false)) setPeerOnline(false)
  }, [presenceMap, peerId, contactId, c])

  // Keep header Online in sync with global presenceMap (WS → store)
  useEffect(() => {
    const keys = [peerId, contactId, (c as any)?.peerId, (c as any)?.id].filter(Boolean).map(String)
    for (const k of keys) {
      if (presenceMap?.[k] != null) {
        setPeerOnline(!!presenceMap[k])
        break
      }
    }
    let foundBusy: { message: string; until?: string | null } | null | undefined
    for (const k of keys) {
      const b = busyMap?.[k]
      if (b === undefined) continue
      if (b && b.message && String(b.message).trim()) {
        foundBusy = { message: b.message, until: b.until || null }
        break
      }
      // Explicit empty entry means busy was cleared for this peer
      foundBusy = null
    }
    if (foundBusy !== undefined) {
      setPeerBusy(foundBusy)
    }
  }, [presenceMap, busyMap, peerId, contactId, c])

  // Store typingPeers → header (home + open chat share the same map)
  // Do NOT clear liveDraft here — only explicit stop / idle timer may clear it.
  useEffect(() => {
    const keys = [peerId, contactId, (c as any)?.peerId, (c as any)?.id].filter(Boolean).map(String)
    const on = keys.some((k) => !!typingPeers?.[k])
    if (on) setTyping(true)
    else if (Date.now() - liveDraftSeenAt.current > 12000) {
      setTyping(false)
    }
  }, [typingPeers, peerId, contactId, c])

  // Live typing + presence from WS window events (match contactId or resolved peerId)
  useEffect(() => {
    const isPeer = (id?: string) => {
      if (!id) return false
      const keys = new Set(
        [contactId, peerId, (c as any)?.peerId, (c as any)?.id].filter(Boolean).map(String),
      )
      return keys.has(String(id))
    }

    const onTyping = (ev: Event) => {
      const d = (ev as CustomEvent).detail as { peerId?: string; typing?: boolean }
      if (!isPeer(d?.peerId)) return
      if (d.typing) {
        liveDraftSeenAt.current = Date.now()
        setTyping(true)
        if (liveClearTimer.current) clearTimeout(liveClearTimer.current)
        liveClearTimer.current = setTimeout(() => {
          // Only clear if no live packets refreshed recently
          if (Date.now() - liveDraftSeenAt.current >= 14000) {
            setLiveDraft(null)
            setTyping(false)
          }
        }, 15000)
      } else {
        // Explicit stop — clear only after a short grace so heartbeat lag is ok
        if (liveClearTimer.current) clearTimeout(liveClearTimer.current)
        liveClearTimer.current = setTimeout(() => {
          if (Date.now() - liveDraftSeenAt.current >= 3000) {
            setLiveDraft(null)
            setTyping(false)
          }
        }, 3500)
      }
    }
    const onPresence = (ev: Event) => {
      const d = (ev as CustomEvent).detail as {
        peerId?: string
        online?: boolean
        lastSeen?: string | null
        busy?: boolean
        busyMessage?: string
        busyUntil?: string | null
      }
      if (!isPeer(d?.peerId)) return
      if (d.online === true) setPeerOnline(true)
      else if (d.online === false) {
        // Soft: presenceMap debounce handles global; keep local sticky briefly
        setTimeout(() => {
          // only go offline if still not online in map
        }, 0)
        setPeerOnline(false)
      }
      if (d.lastSeen) setPeerLastSeen(d.lastSeen)
      if (d.busy && (d.busyMessage || d.busyMessage === '')) {
        setPeerBusy({ message: d.busyMessage || 'busy', until: d.busyUntil || null })
      } else if (d.busy === false) {
        setPeerBusy(null)
      }
    }
    const onRec = (ev: Event) => {
      const d = (ev as CustomEvent).detail as { peerId?: string; recording?: boolean }
      if (isPeer(d?.peerId)) setPeerRecording(!!d.recording)
    }
    const onLive = (ev: Event) => {
      const d = (ev as CustomEvent).detail as { peerId?: string; draft?: string }
      if (!isPeer(d?.peerId)) return
      const draft = typeof d.draft === 'string' ? d.draft : ''
      liveDraftSeenAt.current = Date.now()
      // One-way: only Premium (live typing on, default true) sees real characters
      const canSeeLive =
        (settings as any).subscriptionPlan === 'premium' &&
        (settings as any).liveTyping !== false
      if (canSeeLive) {
        setLiveDraft(draft.length > 0 ? draft : null)
      }
      // Non-premium still sees typing indicator from live packets
      setTyping(draft.length > 0)
      if (liveClearTimer.current) clearTimeout(liveClearTimer.current)
      if (draft.length > 0) {
        liveClearTimer.current = setTimeout(() => {
          if (Date.now() - liveDraftSeenAt.current >= 14000) {
            setLiveDraft(null)
            setTyping(false)
          }
        }, 15000)
      } else {
        // Explicit empty draft = stopped typing
        setLiveDraft(null)
        setTyping(false)
      }
    }
    window.addEventListener('sc:rt-typing', onTyping)
    window.addEventListener('sc:rt-presence', onPresence)
    window.addEventListener('sc:rt-recording', onRec)
    window.addEventListener('sc:rt-live-typing', onLive)
    return () => {
      window.removeEventListener('sc:rt-typing', onTyping)
      window.removeEventListener('sc:rt-presence', onPresence)
      window.removeEventListener('sc:rt-recording', onRec)
      window.removeEventListener('sc:rt-live-typing', onLive)
      if (liveClearTimer.current) clearTimeout(liveClearTimer.current)
    }
  }, [contactId, peerId, settings, c])


  const applyEdit = async () => {
    if (!actionMsg || !editText.trim()) return
    const id = actionMsg.id
    const clientKey = actionMsg.clientKey
    const prevText = actionMsg.text
    const prevEdited = !!(actionMsg as any).edited
    const text = editText.trim()
    if (text === String(prevText || '').trim()) {
      setEditing(false)
      setActionMsg(null)
      return
    }
    // Single optimistic paint: new text + edited. No intermediate "editing…" state.
    const patched = {
      ...actionMsg,
      text,
      edited: true,
      editing: false,
    } as ApiMsg
    setMsgs((list) =>
      list.map((m) =>
        m.id === id || (clientKey && m.clientKey === clientKey) ? { ...m, text, edited: true, editing: false } : m,
      ),
    )
    setEditing(false)
    setActionMsg(null)
    const cid = convRef.current
    if (cid) {
      // Keep central store in sync so subscribeThread cannot re-emit the old body
      void applyThreadMessages(cid, [patched], 'merge')
    }
    try {
      await api.editMessage(id, text)
      // Success: already showing final UI — do not re-render
    } catch {
      // Only rollback on failure
      setMsgs((list) =>
        list.map((m) =>
          m.id === id || (clientKey && m.clientKey === clientKey)
            ? { ...m, text: prevText, editing: false, edited: prevEdited }
            : m,
        ),
      )
      if (cid) {
        void applyThreadMessages(
          cid,
          [{ ...actionMsg, text: prevText, edited: prevEdited, editing: false } as ApiMsg],
          'merge',
        )
      }
      showToast('Could not edit message')
    }
  }

  const applyDelete = async () => {
    if (!actionMsg) return
    const id = actionMsg.id
    setMsgs((list) =>
      list.map((m) =>
        m.id === id ? { ...m, deleted: true, text: '', image: null } : m,
      ),
    )
    setActionMsg(null)
    try {
      await api.deleteMessage(id)
    } catch {
      showToast('Could not delete')
    }
  }

  const applyReact = async (emoji: string) => {
    if (!actionMsg) return
    const id = actionMsg.id
    if (!id || String(id).startsWith('local-')) {
      showToast('Wait for the message to send')
      return
    }
    const meId = me?.id
    const minePrev = (actionMsg.reactions || []).find((r: any) => !r.user_id || (meId && r.user_id === meId))
    const same = minePrev && minePrev.emoji === emoji
    setMsgs((list) =>
      list.map((m) => {
        if (m.id !== id) return m
        const others = (m.reactions || []).filter((r: any) => r.user_id && meId && r.user_id !== meId)
        const reactions = same ? others : [...others, { emoji, user_id: meId }]
        return { ...m, reactions }
      }),
    )
    setActionMsg(null)
    try {
      if (same) await api.removeReaction(id, emoji)
      else await api.reactMessage(id, emoji)
    } catch {
      showToast('Could not update reaction')
    }
  }

  const applyForward = async (conversationId: string) => {
    if (!actionMsg) return
    try {
      await api.forwardMessage(actionMsg.id, conversationId)
      showToast('Forwarded')
    } catch {
      showToast('Could not forward')
    }
    setForwardOpen(false)
    setActionMsg(null)
  }

  // Status reply handoff (sessionStorage + live event) — desktop / foldable / mobile
  useEffect(() => {
    const apply = (data: { peerId?: string; preview?: string; time?: string; statusId?: string }) => {
      if (!data?.peerId) return
      if (data.peerId !== contactId && data.peerId !== peerId) return
      setStatusReply({
        preview: data.preview || 'Status',
        time: data.time,
        statusId: data.statusId,
      })
      requestAnimationFrame(() => inputRef.current?.focus())
    }
    try {
      const raw = sessionStorage.getItem('sc_status_reply')
      if (raw) {
        const data = JSON.parse(raw)
        sessionStorage.removeItem('sc_status_reply')
        apply(data)
      }
    } catch {
      /* */
    }
    const onEv = (ev: Event) => {
      try {
        apply((ev as CustomEvent).detail || {})
      } catch {
        /* */
      }
    }
    window.addEventListener('sc:status-reply', onEv)
    return () => window.removeEventListener('sc:status-reply', onEv)
  }, [contactId, peerId])

  // Merge call history for this peer into the timeline
  useEffect(() => {
    let alive = true
    ;(async () => {
      try {
        const { calls } = await api.calls()
        if (!alive) return
        const peerCalls = (calls || []).filter((c: any) => c.contactId === contactId)
        if (!peerCalls.length) return
        setMsgs((prev) => {
          const existing = new Set(prev.filter((m) => m.callLog).map((m) => m.id))
          const extra: ApiMsg[] = peerCalls
            .filter((c: any) => !existing.has(`call-${c.id}`))
            .map((c: any) => {
              const iso = c.ago || c.created_at || c.time || ''
              return {
                id: `call-${c.id}`,
                clientKey: `call-${c.id}`,
                from: '',
                to: contactId,
                text: '',
                time: iso,
                timeLabel: c.time || '',
                mine: c.direction === 'out',
                callLog: {
                  kind: c.kind === 'video' ? 'video' : 'audio',
                  direction: c.direction || 'out',
                  status: c.status || 'completed',
                  duration: c.duration,
                },
              }
            })
          if (!extra.length) return prev
          const merged = [...prev, ...extra].sort((a, b) => {
            const ta = Date.parse(a.time) || 0
            const tb = Date.parse(b.time) || 0
            return ta - tb
          })
          return merged
        })
      } catch {
        /* */
      }
    })()
    return () => {
      alive = false
    }
  }, [contactId])


  useEffect(() => {
    let cancelled = false
    let timer: ReturnType<typeof setTimeout> | null = null
    const loop = (phase: 'label' | 'time') => {
      if (cancelled) return
      setLastSeenPhase(phase)
      // Time stays longer than the words "last seen"
      const ms = phase === 'time' ? 4500 : 1600
      timer = setTimeout(() => loop(phase === 'time' ? 'label' : 'time'), ms)
    }
    loop('time')
    return () => {
      cancelled = true
      if (timer) clearTimeout(timer)
    }
  }, [contactId])

  // Load self notes into timeline when self chat (local cache + server sync)
  useEffect(() => {
    if (!isSelfChat || !me?.id) return
    try {
      const raw = kvGet(`sc_notes_${me.id}`)
      setSelfNoteItems(raw ? JSON.parse(raw) : [])
    } catch {
      setSelfNoteItems([])
    }
    let cancelled = false
    void (async () => {
      try {
        const localRaw = kvGet(`sc_notes_${me.id}`)
        const local = localRaw ? JSON.parse(localRaw) : []
        const localOnly = (local as any[]).filter(
          (n) => !n?.id || !/^[a-f0-9]{24}$/i.test(String(n.id)),
        )
        const remote = localOnly.length
          ? await api.syncNotes(
              localOnly.map((n: any) => ({
                id: n.id,
                kind: n.kind,
                title: n.title,
                body: n.body,
                items: n.items || [],
                remind_at: n.remindAt || null,
                pinned: !!n.pinned,
              })),
            )
          : await api.listNotes()
        if (cancelled) return
        const mapped = remote.map((n) => ({
          id: n.id,
          kind: n.kind,
          title: n.title,
          body: n.body,
          items: n.items,
          remindAt: n.remindAt,
          pinned: n.pinned,
          createdAt: n.createdAt,
          updatedAt: n.updatedAt,
        }))
        kvSet(`sc_notes_${me.id}`, JSON.stringify(mapped))
        setSelfNoteItems(mapped)
      } catch {
        /* keep local */
      }
    })()
    const onStorage = () => {
      try {
        const raw = kvGet(`sc_notes_${me.id}`)
        setSelfNoteItems(raw ? JSON.parse(raw) : [])
      } catch { /* */ }
    }
    window.addEventListener('sc_notes_preview', onStorage)
    return () => {
      cancelled = true
      window.removeEventListener('sc_notes_preview', onStorage)
    }
  }, [isSelfChat, me?.id])

  useEffect(() => {
    const open = (ev: Event) => {
      const id = (ev as CustomEvent).detail?.gameId
      if (!isSelfChat) return
      setSelfGameId(id ? String(id) : null)
      setSelfActiveTab('game')
      setSelfGameOpen(true)
    }
    window.addEventListener('sc:open-tictactoe', open)
    if (isSelfChat) {
      try {
        const pending = sessionStorage.getItem('sc_open_tictactoe')
        if (pending) {
          sessionStorage.removeItem('sc_open_tictactoe')
          setSelfGameId(pending)
          setSelfActiveTab('game')
          setSelfGameOpen(true)
        }
      } catch { /* */ }
    }
    return () => window.removeEventListener('sc:open-tictactoe', open)
  }, [isSelfChat])

  if (chatLocked && !unlockedThisSession && !isSelfChat) {
    return (
      <div className="flex h-full flex-col items-center justify-center bg-white px-6">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-brand-purple/10 text-brand-purple">
          <Lock size={28} />
        </div>
        <p className="text-lg font-black text-ink">Chat locked</p>
        <p className="mt-1 text-center text-sm font-semibold text-gray-400">Enter your PIN to open this chat</p>
        <input
          type="password"
          inputMode="numeric"
          maxLength={8}
          value={lockPinDraft}
          onChange={(e) => {
            setLockPinDraft(e.target.value.replace(/\D/g, '').slice(0, 8))
            setLockPinError('')
          }}
          onKeyDown={(e) => {
            if (e.key !== 'Enter') return
            try {
              const pin = kvGet('sc_chat_lock_pin') || ''
              if (pin && lockPinDraft === pin) {
                setUnlockedThisSession(true)
                setLockPinDraft('')
                setLockPinError('')
              } else setLockPinError('Wrong PIN')
            } catch {
              setLockPinError('Wrong PIN')
            }
          }}
          className="mt-5 w-full max-w-xs rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-center text-lg font-black tracking-[0.35em] outline-none focus:border-brand-purple"
          placeholder="••••"
          autoFocus
        />
        {lockPinError ? <p className="mt-2 text-sm font-bold text-brand-red">{lockPinError}</p> : null}
        <button
          type="button"
          className="mt-4 w-full max-w-xs rounded-full bg-brand-purple py-3.5 text-sm font-extrabold text-white"
          onClick={() => {
            try {
              const pin = kvGet('sc_chat_lock_pin') || ''
              if (pin && lockPinDraft === pin) {
                setUnlockedThisSession(true)
                setLockPinDraft('')
                setLockPinError('')
              } else setLockPinError('Wrong PIN')
            } catch {
              setLockPinError('Wrong PIN')
            }
          }}
        >
          Unlock
        </button>
        <button type="button" className="mt-2 text-sm font-bold text-gray-500" onClick={onBack}>
          Back
        </button>
      </div>
    )
  }

    // Self-chat uses the normal chat surface (notes as rectangular items in the timeline)


return (
    <div className="flex h-full flex-col" style={{ background: resolveWallpaper(settings.wallpaper, settings.colorMode) }}>
      <header className="z-10 flex shrink-0 items-center gap-1 border-b border-white/40 bg-white/80 backdrop-blur-md px-2 pb-3.5 pt-[max(1.5rem,calc(env(safe-area-inset-top)+0.75rem))] shadow-sm">
        <button
          type="button"
          aria-label="Back"
          onClick={onBack}
          className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-gray-100 md:hidden"
        >
          <ArrowLeft size={22} />
        </button>
        <button
          type="button"
          onClick={() => {
            // Pull latest shared phone / contact fields when opening profile
            void refreshContacts?.()
            // Desktop: toggle contact info drawer; mobile: existing profile sheet
            if (typeof window !== 'undefined' && window.matchMedia('(min-width: 900px)').matches) {
              window.dispatchEvent(new CustomEvent('sc:toggle-info-drawer'))
            } else {
              setProfileOpen(true)
            }
          }}
          className="flex min-w-0 flex-1 items-center gap-2 text-left"
        >
          <Avatar contact={{ ...c, online: peerOnline || c.online }} size={44} />
          <div className="min-w-0 flex-1">
            <p className="flex min-w-0 items-center gap-1 font-extrabold leading-tight">
              <span className="truncate">
                {isSelfChat ? `Me (${me?.name || (c as any).publicName || c.name || 'You'})` : c.name}
              </span>
              {!!(c as any).verifiedBadge && !isSelfChat && (
                <VerifiedCheck size={15} />
              )}
            </p>
            <p
              className={`text-xs font-bold ${
                isSelfChat
                  ? 'text-gray-400'
                  : peerRecording || liveDraft || typing || peerOnline || c.online
                    ? 'text-brand-blue'
                    : 'text-gray-400'
              } max-w-[11rem] overflow-hidden`}
            >
              {(() => {
                if (isSelfChat) {
                  const u = (me?.username || c.username || '').replace(/^@/, '')
                  return u ? `@${u}` : 'Notes'
                }
                if (peerRecording) return 'recording…'
                if ((c as any).onCall) return 'on a call'
                if (liveDraft || typing) return 'typing…'
                const peer = peerId || contactId
                const busyInfo =
                  peerBusy ||
                  busyMap?.[peer] ||
                  busyMap?.[peerId] ||
                  busyMap?.[contactId] ||
                  ((c as any).busyMessage
                    ? {
                        message: (c as any).busyMessage,
                        until: (c as any).busyUntil || null,
                      }
                    : null)
                const busyActive = !!(
                  busyInfo &&
                  busyInfo.message &&
                  String(busyInfo.message).trim() &&
                  (!busyInfo.until || Date.parse(String(busyInfo.until)) > Date.now())
                )
                const online = !!(
                  presenceMap?.[peer] ||
                  presenceMap?.[peerId] ||
                  presenceMap?.[contactId] ||
                  peerOnline ||
                  c.online
                )
                const last = peerLastSeen || (c as any).lastSeen
                // Custom status replaces Online while the peer is online (or message still active)
                if (busyActive && (online || (c as any).busy)) return busyInfo!.message || 'busy'
                if (online) return 'Online'
                if (last) {
                  const timeBit = formatLastSeen(last).replace(/^last seen\s*/i, '')
                  // Time stays longer: phase 'time' for ~2.8s of 4s cycle via CSS not needed;
                  // interval toggles; prefer showing time more often
                  if (lastSeenPhase === 'label') return 'last seen'
                  return timeBit || formatLastSeen(last)
                }
                return c.username ? `@${c.username}` : ''
              })()}
            </p>
          </div>
        </button>
        {isSelfChat && (
          <div className="relative">
            <button
              type="button"
              onClick={() => setSelfSettingsOpen((v) => !v)}
              className="flex h-10 w-10 items-center justify-center rounded-full text-brand-purple hover:bg-brand-purple/10"
              aria-label="Self chat settings"
            >
              <MoreVertical size={20} />
            </button>
            {selfSettingsOpen && (
              <>
                <button type="button" className="fixed inset-0 z-40" aria-label="Close" onClick={() => setSelfSettingsOpen(false)} />
                <div className="absolute right-0 top-11 z-50 w-56 overflow-hidden rounded-2xl bg-white py-2 shadow-xl ring-1 ring-black/5">
                  {[
                    { label: 'Notes', on: showSelfNotes, set: setShowSelfNotes },
                    { label: 'Checklists', on: showSelfChecklists, set: setShowSelfChecklists },
                    { label: 'Reminders', on: showSelfReminders, set: setShowSelfReminders },
                    { label: 'Messages', on: showSelfMsgs, set: setShowSelfMsgs },
                    { label: 'Games', on: showSelfGames, set: setShowSelfGames },
                  ].map((row) => (
                    <div key={row.label} className="flex items-center justify-between gap-3 px-4 py-2.5">
                      <span className="text-sm font-extrabold text-ink">{row.label}</span>
                      <Toggle on={row.on} onChange={(v) => row.set(v)} label={row.label} />
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
        {!isSelfChat && (
          <>
        <button
          type="button"
          aria-label="Voice call"
          onClick={() => onCall('audio')}
          className="flex h-10 w-10 items-center justify-center rounded-full text-brand-purple hover:bg-brand-purple/10"
        >
          <Phone size={21} />
        </button>
        <button
          type="button"
          aria-label="Video call"
          onClick={() => onCall('video')}
          className="flex h-10 w-10 items-center justify-center rounded-full text-brand-purple hover:bg-brand-purple/10"
        >
          <Video size={22} />
        </button>
        <div className="relative md:hidden">
          <button
            type="button"
            aria-label="Chat options"
            onClick={() => setChatMenu((m) => !m)}
            className="flex h-10 w-10 items-center justify-center rounded-full text-brand-purple hover:bg-brand-purple/10"
          >
            <MoreVertical size={20} />
          </button>
          {chatMenu && (
            <>
              <button
                type="button"
                className="fixed inset-0 z-40"
                aria-label="Close menu"
                onClick={() => setChatMenu(false)}
              />
              <div className="absolute right-0 top-11 z-50 w-52 overflow-hidden rounded-2xl bg-white py-1.5 text-ink shadow-xl ring-1 ring-black/5">
                <button
                  type="button"
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm font-bold hover:bg-gray-50"
                  onClick={() => {
                    setChatMuted((m) => {
                      const next = !m
                      try {
                        const map = JSON.parse(kvGet('sc_chat_muted') || '{}')
                        map[contactId] = next
                        kvSet('sc_chat_muted', JSON.stringify(map))
                      } catch { /* ignore */ }
                      return next
                    })
                    setChatMenu(false)
                    showToast?.(chatMuted ? 'Chat unmuted' : 'Chat muted')
                  }}
                >
                  {chatMuted ? <Bell size={18} className="text-brand-purple" /> : <BellOff size={18} className="text-brand-purple" />}
                  {chatMuted ? 'Unmute notifications' : 'Mute notifications'}
                </button>
                <button
                  type="button"
                  disabled
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm font-bold text-gray-300"
                >
                  <Gamepad2 size={18} className="text-gray-300" />
                  Play tic tac toe
                </button>
                <button
                  type="button"
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm font-bold hover:bg-gray-50"
                  onClick={() => {
                    setChatMenu(false)
                    showToast?.('Custom ringtones coming soon')
                  }}
                >
                  <Volume2 size={18} className="text-brand-purple" />
                  Custom ringtone
                </button>
                <button
                  type="button"
                  disabled={peerBlocked === null}
                  className={`flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm font-bold disabled:opacity-50 ${
                    peerBlocked ? 'text-brand-purple hover:bg-brand-purple/5' : 'text-brand-red hover:bg-red-50'
                  }`}
                  onClick={() => {
                    setChatMenu(false)
                    setBlockOpen(true)
                  }}
                >
                  {peerBlocked ? (
                    <Unlock size={18} className="text-brand-purple" />
                  ) : (
                    <Ban size={18} />
                  )}
                  {peerBlocked === null ? 'Checking…' : peerBlocked ? 'Unblock' : 'Block'}
                </button>
                <button
                  type="button"
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm font-bold hover:bg-gray-50"
                  onClick={() => {
                    setChatMenu(false)
                    let pin = ''
                    try { pin = kvGet('sc_chat_lock_pin') || '' } catch { /* */ }
                    if (!pin) {
                      showToast?.('Set a chat lock PIN in Settings → Security')
                      try {
                        window.dispatchEvent(new CustomEvent('sc:open-settings-security'))
                      } catch { /* */ }
                      return
                    }
                    setLockPinDraft('')
                    setLockPinError('')
                    setLockPrompt(true)
                  }}
                >
                  <Lock size={18} className="text-brand-purple" />
                  {chatLocked ? 'Unlock chat' : 'Lock chat'}
                </button>
              </div>
            </>
          )}
        </div>
          </>
        )}
      </header>


      {isSelfChat && (showSelfNotes || showSelfChecklists || showSelfReminders || showSelfGames) && (
        <div className="flex shrink-0 gap-2 overflow-x-auto border-b border-black/5 bg-white/90 px-3 py-2 no-scrollbar dark:border-white/10 dark:bg-[#121821]/95">
          {showSelfNotes && (
            <button
              type="button"
              onClick={() => openSelfTab('note')}
              className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-extrabold ${
                selfActiveTab === 'note' || (selfEditor && selfEditor.kind === 'note')
                  ? 'bg-brand-purple text-white'
                  : 'bg-brand-purple/10 text-brand-purple dark:bg-brand-purple/20 dark:text-brand-purple'
              }`}
            >
              Note
            </button>
          )}
          {showSelfChecklists && (
            <button
              type="button"
              onClick={() => openSelfTab('checklist')}
              className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-extrabold ${
                selfActiveTab === 'checklist' || (selfEditor && selfEditor.kind === 'checklist')
                  ? 'bg-brand-purple text-white'
                  : 'bg-brand-purple/10 text-brand-purple dark:bg-brand-purple/20 dark:text-brand-purple'
              }`}
            >
              Checklist
            </button>
          )}
          {showSelfReminders && (
            <button
              type="button"
              onClick={() => openSelfTab('reminder')}
              className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-extrabold ${
                selfActiveTab === 'reminder' || (selfEditor && selfEditor.kind === 'reminder')
                  ? 'bg-brand-purple text-white'
                  : 'bg-brand-purple/10 text-brand-purple dark:bg-brand-purple/20 dark:text-brand-purple'
              }`}
            >
              Reminder
            </button>
          )}
          {showSelfGames && (
            <button
              type="button"
              onClick={() => openSelfTab('game')}
              className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-extrabold ${
                selfActiveTab === 'game' || selfGameOpen
                  ? 'bg-brand-purple text-white'
                  : 'bg-brand-purple/10 text-brand-purple dark:bg-brand-purple/20 dark:text-brand-purple'
              }`}
            >
              Game
            </button>
          )}
        </div>
      )}

      {selfGameOpen ? (
        <div className="min-h-0 flex flex-1 flex-col overflow-hidden bg-white dark:bg-[#121821]">
          <TicTacToe
            initialGameId={selfGameId}
            onClose={() => {
              setSelfGameOpen(false)
              setSelfGameId(null)
              setSelfActiveTab(null)
            }}
          />
        </div>
      ) : selfEditor ? (
        <div className="min-h-0 flex-1 flex flex-col overflow-hidden bg-white">
          <header className="flex shrink-0 items-center gap-2 border-b border-black/5 px-3 py-2">
            <button
              type="button"
              onClick={() => { setSelfEditor(null); setSelfActiveTab(null) }}
              className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-black/5"
            >
              <ArrowLeft size={22} />
            </button>
            <p className="flex-1 text-base font-black text-ink">
              {selfEditor.kind === 'checklist' ? 'Checklist' : selfEditor.kind === 'reminder' ? 'Reminder' : 'Note'}
            </p>
            <button
              type="button"
              className="rounded-full bg-brand-purple px-4 py-2 text-sm font-extrabold text-white"
              onClick={() => {
                if (!me?.id) return
                const now = new Date().toISOString()
                const saved = { ...selfEditor, updatedAt: now, _isNew: undefined }
                try {
                  const key = `sc_notes_${me.id}`
                  const prev = JSON.parse(kvGet(key) || '[]') as any[]
                  const idx = prev.findIndex((x) => x.id === saved.id)
                  let next: any[]
                  if (idx >= 0) next = prev.map((x, i) => (i === idx ? saved : x))
                  else next = [saved, ...prev]
                  next.sort((a, b) => (Date.parse(b.updatedAt) || 0) - (Date.parse(a.updatedAt) || 0))
                  kvSet(key, JSON.stringify(next))
                  setSelfNoteItems(next)
                  window.dispatchEvent(new CustomEvent('sc_notes_preview'))
                } catch { /* */ }
                setSelfEditor(null)
                // Sync to server so notes follow the user across devices
                void (async () => {
                  try {
                    const payload = {
                      id: saved.id,
                      kind: saved.kind,
                      title: saved.title || '',
                      body: saved.body || '',
                      items: saved.items || [],
                      remind_at: saved.remindAt || null,
                      pinned: !!saved.pinned,
                    }
                    const isMongo = /^[a-f0-9]{24}$/i.test(String(saved.id || ''))
                    const remote = isMongo
                      ? await api.updateNote(String(saved.id), payload)
                      : await api.createNote(payload)
                    if (remote?.id && me?.id) {
                      try {
                        const key = `sc_notes_${me.id}`
                        const prev = JSON.parse(kvGet(key) || '[]') as any[]
                        const mapped = {
                          id: remote.id,
                          kind: remote.kind,
                          title: remote.title,
                          body: remote.body,
                          items: remote.items,
                          remindAt: remote.remindAt,
                          pinned: remote.pinned,
                          createdAt: remote.createdAt,
                          updatedAt: remote.updatedAt,
                        }
                        const without = prev.filter((x) => x.id !== saved.id && x.id !== remote.id)
                        const next = [mapped, ...without]
                        kvSet(key, JSON.stringify(next))
                        setSelfNoteItems(next)
                      } catch { /* */ }
                    }
                    showToast?.('Saved · syncs across devices')
                  } catch {
                    showToast?.('Saved on this device')
                  }
                })()
              }}
            >
              Save
            </button>
          </header>
          <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-4">
            <input
              value={selfEditor.title || ''}
              onChange={(e) => setSelfEditor({ ...selfEditor, title: e.target.value })}
              placeholder="Title"
              className="w-full border-0 bg-transparent text-xl font-black outline-none placeholder:text-gray-300"
              autoFocus
            />
            {selfEditor.kind === 'note' && (
              <textarea
                value={selfEditor.body || ''}
                onChange={(e) => setSelfEditor({ ...selfEditor, body: e.target.value })}
                placeholder="Write something…"
                rows={12}
                className="w-full resize-none border-0 bg-transparent text-[15px] font-semibold leading-relaxed outline-none placeholder:text-gray-300"
              />
            )}
            {selfEditor.kind === 'reminder' && (
              <textarea
                value={selfEditor.body || ''}
                onChange={(e) => setSelfEditor({ ...selfEditor, body: e.target.value })}
                placeholder="When or details…"
                rows={4}
                className="w-full resize-none border-0 bg-transparent text-[15px] font-semibold outline-none placeholder:text-gray-300"
              />
            )}
            {selfEditor.kind === 'checklist' && (
              <div className="space-y-2">
                {(selfEditor.items || []).map((it: any, idx: number) => (
                  <div key={it.id || idx} className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={!!it.done}
                      onChange={() => {
                        const items = [...(selfEditor.items || [])]
                        items[idx] = { ...items[idx], done: !items[idx].done }
                        setSelfEditor({ ...selfEditor, items })
                      }}
                    />
                    <input
                      value={it.text || ''}
                      onChange={(e) => {
                        const items = [...(selfEditor.items || [])]
                        items[idx] = { ...items[idx], text: e.target.value }
                        setSelfEditor({ ...selfEditor, items })
                      }}
                      className="flex-1 border-0 bg-transparent text-sm font-semibold outline-none"
                      placeholder="Item"
                    />
                  </div>
                ))}
                <button
                  type="button"
                  className="text-sm font-extrabold text-brand-purple"
                  onClick={() =>
                    setSelfEditor({
                      ...selfEditor,
                      items: [...(selfEditor.items || []), { id: `i_${Date.now()}`, text: '', done: false }],
                    })
                  }
                >
                  Add item
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
      <div
        ref={msgsScrollRef}
        data-msg-list
        className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-4 pb-6 md:px-8"
        style={{ fontSize: FONT_SIZES[settings.fontSize] || '1rem' }}
        onScroll={(e) => {
          const el = e.currentTarget
          if (el.scrollTop < 80) void loadOlder()
        }}
      >
        {(loadingOlder || hasMoreOlder) && (
          <p className="py-2 text-center text-[11px] font-bold text-gray-400">
            {loadingOlder ? 'Loading earlier messages…' : hasMoreOlder ? 'Scroll up for earlier messages' : ''}
          </p>
        )}
        {loading && <p className="py-6 text-center text-sm font-bold text-gray-400">Loading…</p>}
        {!loading && msgs.length === 0 && !selfNoteItems.length && (
          <EmptyState
            title={isSelfChat ? 'Your personal space' : `Say hi to ${c.name.split(' ')[0]}`}
            subtitle={
              isSelfChat
                ? 'Notes, checklists, reminders, and messages to yourself live here.'
                : "This inbox is empty. Send a message when you're ready, it stays between you two."
            }
            className="py-8"
          />
        )}

        <AnimatePresence initial={false}>
          {(() => {
            const feed: { type: 'msg' | 'note'; t: number; id: string; data: any }[] = []
            if (showSelfMsgs || !isSelfChat) {
              for (const m of msgs) {
                feed.push({
                  type: 'msg',
                  t: Date.parse(m.time || (m as any).iso || '') || 0,
                  id: String(m.clientKey || m.id),
                  data: m,
                })
              }
            }
            if (isSelfChat) {
              for (const n of selfNoteItems) {
                if (n.kind === 'note' && !showSelfNotes) continue
                if (n.kind === 'checklist' && !showSelfChecklists) continue
                if (n.kind === 'reminder' && !showSelfReminders) continue
                feed.push({
                  type: 'note',
                  t: Date.parse(n.updatedAt || n.createdAt || '') || 0,
                  id: String(n.id),
                  data: n,
                })
              }
            }
            feed.sort((a, b) => a.t - b.t || (a.id < b.id ? -1 : 1))
            // Day separators: Today, Yesterday, weekday, or short date
            let lastDay = ''
            const nodes: ReactNode[] = []
            for (const item of feed) {
              const day = localDayKey(item.t || null)
              if (day && day !== lastDay) {
                lastDay = day
                const label = formatDayLabel(item.t || null)
                if (label) {
                  nodes.push(
                    <p
                      key={`day-${day}`}
                      className="mx-auto my-2 w-fit rounded-full bg-white px-3 py-1 text-xs font-extrabold text-gray-500 shadow-sm dark:bg-[#1a2332] dark:text-gray-400"
                    >
                      {label}
                    </p>,
                  )
                }
              }
              if (item.type === 'note') {
                const n = item.data
                nodes.push(
                  <button
                    type="button"
                    key={`note-${n.id}`}
                    onClick={() => {
                      setSelfActiveTab(
                        n.kind === 'checklist' ? 'checklist' : n.kind === 'reminder' ? 'reminder' : 'note',
                      )
                      setSelfGameOpen(false)
                      setSelfEditor({ ...n, _isNew: false })
                    }}
                    className="mx-auto block w-full max-w-[85%] rounded-2xl bg-white px-4 py-3 text-left shadow-sm ring-1 ring-black/5"
                  >
                    <p className="text-[10px] font-black uppercase tracking-wide text-brand-purple">
                      {n.kind === 'checklist' ? 'Checklist' : n.kind === 'reminder' ? 'Reminder' : 'Note'}
                    </p>
                    <p className="mt-0.5 font-extrabold text-ink">{n.title || 'Untitled'}</p>
                    {n.kind === 'checklist' ? (
                      <p className="mt-1 text-xs font-semibold text-gray-400">
                        {(n.items || []).filter((x: any) => x.done).length}/{(n.items || []).length} done
                      </p>
                    ) : (
                      <p className="mt-1 line-clamp-3 text-sm font-semibold text-gray-500">{n.body || ''}</p>
                    )}
                    <p className="mt-1 text-[10px] font-bold text-gray-300">
                      {n.updatedAt ? new Date(n.updatedAt).toLocaleString() : ''}
                    </p>
                  </button>,
                )
                continue
              }
              const m = item.data
              const mine = m.mine ?? m.from === me?.id
              const key = m.clientKey || m.id
              const animateIn = !animatedKeys.current.has(key)
              if (animateIn) animatedKeys.current.add(key)
              nodes.push(
              <div
                key={key}
                className="w-full"
                ref={(el) => {
                  msgRefs.current[m.id] = el
                  if (m.clientKey) msgRefs.current[m.clientKey] = el
                }}
              >
                <MessageBubble
                      onOpenAction={() => setActionMsg(m)}
                  m={m}
                  mine={!!mine}
                  readReceipts={settings.readReceipts !== false}
                  animateIn={animateIn}
                  onRetry={retryFailed}
                  onReactEmoji={(msg, emoji) => {
                    void (async () => {
                      const id = msg.id
                      if (!id || String(id).startsWith('local-')) {
                        showToast('Wait for the message to send')
                        return
                      }
                      const meId = me?.id
                      const minePrev = (msg.reactions || []).find((r: any) => !r.user_id || (meId && r.user_id === meId))
                      const same = !!(minePrev && minePrev.emoji === emoji)
                      setMsgs((list) =>
                        list.map((x) => {
                          if (x.id !== id) return x
                          const others = (x.reactions || []).filter((r: any) => r.user_id && meId && r.user_id !== meId)
                          const reactions = same ? others : [...others, { emoji, user_id: meId }]
                          return { ...x, reactions }
                        }),
                      )
                      try {
                        if (same) await api.removeReaction(id, emoji)
                        else await api.reactMessage(id, emoji)
                      } catch {
                        showToast('Could not update reaction')
                      }
                    })()
                  }}
                  onDeleteMsg={(msg) => {
                    setActionMsg(msg)
                    setMsgs((list) =>
                      list.map((x) =>
                        x.id === msg.id ? { ...x, deleted: true, text: '', image: null } : x,
                      ),
                    )
                    void api.deleteMessage(msg.id).catch(() => showToast('Could not delete'))
                  }}
                  onReply={(msg) => {
                    setReplyTo(msg)
                    requestAnimationFrame(() => inputRef.current?.focus())
                  }}
                  onOpenCalls={onOpenCalls}
                  onJumpTo={(id) => {
                    const el = msgRefs.current[id]
                    el?.scrollIntoView({ behavior: 'smooth', block: 'center' })
                    setHighlightId(id)
                    window.setTimeout(() => setHighlightId((h) => (h === id ? null : h)), 1200)
                  }}
                  highlight={highlightId === m.id}
                  onOpenImage={(url) => setLightboxUrl(url)}
                  onOpenStatusReply={(sr) => {
                    if (!sr.statusId) {
                      showToast('This status is no longer available')
                      return
                    }
                    const found = (statusList || []).find((s: any) => s.id === sr.statusId)
                    if (!found) {
                      showToast('This status is no longer available')
                      return
                    }
                    const exp = found.expiresAt ? Date.parse(found.expiresAt) : NaN
                    if (!Number.isNaN(exp) && exp <= Date.now()) {
                      showToast('This status has expired')
                      return
                    }
                    onOpenStatus?.(found.userId || contactId, sr.statusId)
                  }}
                />
              </div>,
              )
            }
            return nodes
          })()}
          {/* Classic three-dot typing bubble (default for everyone; Pro always) */}
          {typing && !(liveDraft != null && liveDraft !== '') && (
            <motion.div
              key="typing-dots"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.12 }}
              className="flex"
            >
              <div className="flex items-center gap-1 rounded-3xl rounded-bl-md bg-white px-4 py-3 shadow-sm ring-1 ring-black/5">
                <span className="h-2 w-2 animate-bounce rounded-full bg-gray-400 [animation-delay:-0.3s]" />
                <span className="h-2 w-2 animate-bounce rounded-full bg-gray-400 [animation-delay:-0.15s]" />
                <span className="h-2 w-2 animate-bounce rounded-full bg-gray-400" />
              </div>
            </motion.div>
          )}
          {/* Live character bubble - Premium viewers only; text uses theme accent (same as caret) */}
          {liveDraft != null && liveDraft !== '' && (
            <motion.div
              key="live-typing"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.12 }}
              className="flex"
            >
              <div className="max-w-[85%] rounded-3xl rounded-bl-md bg-white px-3.5 py-2.5 shadow-sm ring-1 ring-brand-purple/15">
                <p className="whitespace-pre-wrap break-words font-mono text-[14px] font-medium leading-snug tracking-tight text-brand-purple">
                  {liveDraft}
                  <span
                    className="ml-0.5 inline-block h-[1.1em] w-[2px] translate-y-[2px] bg-brand-purple align-middle"
                    style={{ animation: 'sc-caret 1s steps(1) infinite' }}
                  />
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={end} className="h-2 shrink-0 pb-1" />
      </div>
      )}

      {pendingImage && (
        <div className="relative border-t border-gray-100 bg-white px-4 py-2">
          <img src={pendingImage} alt="" className="h-24 rounded-2xl object-cover" />
          <button
            type="button"
            onClick={() => setPendingImage(null)}
            className="absolute right-6 top-4 flex h-7 w-7 items-center justify-center rounded-full bg-black/50 text-white"
          >
            <X size={14} />
          </button>
        </div>
      )}


      
      {actionMsg && !editing && !forwardOpen && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end bg-black/45 md:items-center md:justify-center" onClick={() => setActionMsg(null)}>
          <div className="rounded-t-3xl bg-white px-4 pb-8 pt-3" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-gray-200" />
            <div className="mb-3 flex justify-center gap-2">
              {REACT_EMOJIS.map((e) => (
                <button key={e} type="button" className="flex h-11 w-11 items-center justify-center rounded-full bg-gray-100 text-xl active:scale-90" onClick={() => applyReact(e)}>
                  {e}
                </button>
              ))}
            </div>
            <div className="divide-y divide-gray-100 overflow-hidden rounded-2xl bg-gray-50">
              {actionMsg.mine && !actionMsg.deleted && (
                <button type="button" className="flex w-full px-4 py-3.5 text-left font-bold" onClick={() => { setEditText(actionMsg.text || ''); setEditing(true) }}>Edit</button>
              )}
              <button
                type="button"
                className="flex w-full px-4 py-3.5 text-left font-bold"
                onClick={async () => {
                  const t = actionMsg.text || ''
                  try {
                    await navigator.clipboard.writeText(t)
                    showToast('Copied')
                  } catch {
                    showToast('Could not copy')
                  }
                  setActionMsg(null)
                }}
              >
                Copy
              </button>
              <button type="button" className="flex w-full px-4 py-3.5 text-left font-bold" onClick={() => setForwardOpen(true)}>Forward</button>
              {actionMsg.mine && !actionMsg.deleted && (
                <button type="button" className="flex w-full px-4 py-3.5 text-left font-bold text-brand-red" onClick={() => void applyDelete()}>Delete for everyone</button>
              )}
              <button type="button" className="flex w-full px-4 py-3.5 text-left font-bold text-gray-500" onClick={() => setActionMsg(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {editing && actionMsg && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end bg-black/45 md:items-center md:justify-center">
          <div className="rounded-t-3xl bg-white p-4 pb-8 shadow-[0_-12px_40px_rgba(0,0,0,0.25)] md:w-full md:max-w-md md:rounded-3xl">
            <p className="mb-2 text-sm font-extrabold text-gray-500">Edit message</p>
            <textarea value={editText} onChange={(e) => setEditText(e.target.value)} className="min-h-[80px] w-full rounded-2xl bg-gray-100 p-3 font-semibold outline-none" />
            <div className="mt-3 flex gap-2">
              <button type="button" className="flex-1 rounded-full bg-gray-100 py-3 font-extrabold" onClick={() => { setEditing(false); setActionMsg(null) }}>Cancel</button>
              <button type="button" className="flex-1 rounded-full bg-brand-purple py-3 font-extrabold text-white" onClick={() => void applyEdit()}>Save</button>
            </div>
          </div>
        </div>
      )}

      {forwardOpen && actionMsg && (
        <div className="absolute inset-0 z-50 flex flex-col bg-white">
          <div className="flex items-center gap-2 border-b border-gray-100 px-3 pb-3 pt-[max(1rem,env(safe-area-inset-top))]">
            <button type="button" onClick={() => { setForwardOpen(false); setActionMsg(null) }} className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-gray-100">✕</button>
            <p className="text-lg font-black">Forward to…</p>
          </div>
          <ul className="flex-1 overflow-y-auto px-2 py-2">
            {chats.filter((c) => c.conversationId && c.conversationId !== conversationId).map((c) => (
              <li key={c.conversationId}>
                <button
                  type="button"
                  className="flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left hover:bg-gray-50"
                  onClick={() => void applyForward(c.conversationId!)}
                >
                  <Avatar contact={{ id: c.contactId, name: c.name || 'Chat', hue: ['#7B2CBF', '#6389EB'] }} size={44} />
                  <span className="font-bold">{c.name || 'Chat'}</span>
                </button>
              </li>
            ))}
            {chats.filter((c) => c.conversationId && c.conversationId !== conversationId).length === 0 && (
              <p className="px-4 py-10 text-center font-bold text-gray-400">No other chats yet</p>
            )}
          </ul>
        </div>
      )}

      {profileOpen && (
        <div className="absolute inset-0 z-40 flex flex-col bg-white">
          <div className="flex items-center gap-2 border-b border-gray-100 px-3 pb-3 pt-[max(1.25rem,env(safe-area-inset-top))]">
            <button type="button" onClick={() => setProfileOpen(false)} className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-gray-100" aria-label="Back">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" strokeWidth="2.25" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
            <p className="text-lg font-black">Contact info</p>
          </div>
          <div className="flex flex-1 flex-col items-center overflow-y-auto px-6 pb-10 pt-8">
            <div className="flex w-full items-center justify-center">
              <div className="flex h-[140px] w-[140px] items-center justify-center rounded-full bg-gradient-to-br from-brand-purple/15 to-brand-orange/10">
                <Avatar
                  contact={{
                    ...c,
                    online: peerOnline || c.online,
                  }}
                  size={120}
                />
              </div>
            </div>
            <h2 className="mt-4 flex items-center justify-center gap-1.5 text-2xl font-black text-ink">
              <span>
                {isSelfChat ? `Me (${me?.name || (c as any).publicName || c.name || 'You'})` : c.name}
              </span>
              {!!(c as any).verifiedBadge && !isSelfChat && <VerifiedCheck size={18} />}
            </h2>
            {(c as any).publicName && (c as any).publicName !== c.name ? (
              <p className="mt-1 text-sm font-semibold text-gray-500">
                Public name: {(c as any).publicName}
              </p>
            ) : null}
            {c.username ? <p className="mt-2 font-bold text-brand-purple">@{c.username}</p> : null}
            <p className="mt-1 text-xs font-semibold text-gray-400">
              {(c.phone || (c as any).phone_number) ? 'Contact shared with you' : 'Contact not shared with you'}
            </p>
            {(c.phone || (c as any).phone_number) ? (
              <button
                type="button"
                className="mt-1 touch-manipulation text-sm font-semibold text-gray-500 hover:text-brand-purple active:text-brand-purple"
                onPointerUp={(e) => {
                  e.stopPropagation()
                }}
                onClick={async (e) => {
                  e.stopPropagation()
                  e.preventDefault()
                  const ok = await copyText(String(c.phone || (c as any).phone_number || ''))
                  showToast?.(ok ? 'Copied to clipboard' : 'Could not copy')
                }}
              >
                {c.phone || (c as any).phone_number}
              </button>
            ) : null}
            <p
              className={`mt-2 min-h-[1.25rem] max-w-sm px-4 text-center text-sm font-bold ${
                liveDraft || typing || peerOnline || c.online ? 'text-brand-blue' : 'text-gray-400'
              }`}
            >
              {(() => {
                if ((c as any).onCall) return 'on a call'
                if (liveDraft || typing) return 'typing…'
                const msg =
                  peerBusy?.message ||
                  busyMap?.[peerId || contactId]?.message ||
                  (c as any).busyMessage ||
                  ''
                const until =
                  peerBusy?.until ||
                  busyMap?.[peerId || contactId]?.until ||
                  (c as any).busyUntil
                const busyOn =
                  !!msg &&
                  String(msg).trim() &&
                  (!until || Date.parse(String(until)) > Date.now())
                const onlineNow = !!(
                  peerOnline ||
                  c.online ||
                  presenceMap?.[peerId || contactId]
                )
                if (busyOn && (onlineNow || (c as any).busy)) return msg
                if (onlineNow) return 'Online'
                if (peerLastSeen || (c as any).lastSeen)
                  return formatLastSeen(peerLastSeen || (c as any).lastSeen)
                return c.username ? `@${c.username}` : ''
              })()}
            </p>

            <div className="mt-8 grid w-full max-w-sm grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setProfileOpen(false)}
                className="flex flex-col items-center gap-1.5 rounded-2xl bg-gray-50 py-3.5 transition active:scale-95"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-purple/10 text-brand-purple">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </span>
                <span className="text-xs font-extrabold text-ink">Chat</span>
              </button>
              <button
                type="button"
                onClick={() => { setProfileOpen(false); onCall('audio') }}
                className="flex flex-col items-center gap-1.5 rounded-2xl bg-gray-50 py-3.5 transition active:scale-95"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-purple/10 text-brand-purple">
                  <Phone size={20} />
                </span>
                <span className="text-xs font-extrabold text-ink">Audio</span>
              </button>
              <button
                type="button"
                onClick={() => { setProfileOpen(false); onCall('video') }}
                className="flex flex-col items-center gap-1.5 rounded-2xl bg-gray-50 py-3.5 transition active:scale-95"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-purple/10 text-brand-purple">
                  <Video size={20} />
                </span>
                <span className="text-xs font-extrabold text-ink">Video</span>
              </button>
            </div>

            <div className="mt-8 w-full space-y-3">
              <div className="rounded-2xl bg-gray-50 px-4 py-3">
                <p className="text-[11px] font-black uppercase tracking-wide text-gray-400">Bio</p>
                <p className="mt-1 text-sm font-semibold text-ink">
                  {(c as any).bio || c.bio || contactHit?.bio || 'No bio yet'}
                </p>
              </div>
              {(c.phone || (c as any).phone_number) ? (
                <button
                  type="button"
                  className="w-full touch-manipulation rounded-2xl bg-gray-50 px-4 py-3 text-left transition hover:bg-gray-100 active:bg-gray-100"
                  onClick={async (e) => {
                    e.stopPropagation()
                    e.preventDefault()
                    const ok = await copyText(String(c.phone || (c as any).phone_number || ''))
                    showToast?.(ok ? 'Copied to clipboard' : 'Could not copy')
                  }}
                >
                  <p className="text-[11px] font-black uppercase tracking-wide text-gray-400">Phone</p>
                  <p className="mt-1 text-sm font-semibold text-ink">{c.phone || (c as any).phone_number}</p>
                </button>
              ) : null}
              {c.username ? (
                <div className="rounded-2xl bg-gray-50 px-4 py-3">
                  <p className="text-[11px] font-black uppercase tracking-wide text-gray-400">Username</p>
                  <p className="mt-1 text-sm font-semibold text-brand-purple">@{c.username}</p>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      )}

      {emoji && (
        <div className="max-h-40 overflow-y-auto bg-gray-50 px-3 py-2">
          <div className="grid grid-cols-8 gap-1">
            {EMOJIS.map((e) => (
              <button
                key={e}
                type="button"
                className="flex h-9 w-full items-center justify-center rounded-lg text-xl transition hover:bg-white active:scale-90"
                onClick={() => setText((t) => t + e)}
              >
                {e}
              </button>
            ))}
          </div>
        </div>
      )}

      {(!isSelfChat || showSelfMsgs) && !selfGameOpen && !selfEditor && (
      <div className="shrink-0 safe-pb bg-transparent">
        <div className="bg-transparent pt-1">
        {(replyTo || statusReply) && (
          <div className="mx-2 mb-1 flex items-start gap-2 rounded-2xl bg-white px-3 py-2.5 shadow-sm ring-1 ring-black/5 dark:bg-[#1a222d] dark:ring-white/10">
            <div className="min-w-0 flex-1 border-l-4 border-brand-purple pl-2.5">
              <p className="text-[11px] font-black uppercase tracking-wide text-brand-purple">
                {statusReply ? 'Replying to status' : 'Replying'}
              </p>
              <p className="line-clamp-2 text-xs font-semibold text-gray-700 dark:text-gray-300">
                {statusReply?.preview || replyTo?.text || (replyTo?.image ? '📷 Photo' : '')}
              </p>
              {statusReply?.time ? (
                <p className="mt-0.5 text-[10px] font-bold text-gray-400">{statusReply.time}</p>
              ) : null}
            </div>
            <button
              type="button"
              className="mt-0.5 flex h-7 w-7 items-center justify-center rounded-full text-gray-400 hover:bg-gray-100"
              onClick={() => {
                setReplyTo(null)
                setStatusReply(null)
              }}
              aria-label="Cancel reply"
            >
              ✕
            </button>
          </div>
        )}
        {recording ? (
          <div className="flex items-center gap-3 px-3 py-2.5">
            <button
              type="button"
              className="text-sm font-extrabold text-brand-red"
              onClick={() => {
                try { mediaRecRef.current?.stop() } catch { /* */ }
                mediaRecRef.current = null
                recordChunks.current = []
                if (recordTimer.current) clearInterval(recordTimer.current)
                setRecording(false)
                setRecordSecs(0)
                ;(window as any).__sc_rec?.(false)
              }}
            >
              Cancel
            </button>
            <div className="flex flex-1 items-center gap-2">
              <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-brand-red" />
              <span className="text-sm font-bold tabular-nums text-ink">
                {String(Math.floor(recordSecs / 60)).padStart(2, '0')}:{String(recordSecs % 60).padStart(2, '0')}
              </span>
              <span className="text-xs font-semibold text-gray-400">Recording…</span>
            </div>
            <button
              type="button"
              className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-purple text-white shadow-md"
              onClick={() => {
                try { mediaRecRef.current?.stop() } catch { /* */ }
              }}
              aria-label="Send voice note"
            >
              <Send size={20} />
            </button>
          </div>
        ) : (
          <div className="flex items-end gap-1.5 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1.5">
            <div className="flex min-h-[48px] min-w-0 flex-1 items-end gap-0.5 rounded-[24px] bg-white px-1.5 py-1 ring-1 ring-black/8">
              <button
                type="button"
                onClick={() => setEmoji((e) => !e)}
                className="mb-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-gray-500 hover:bg-black/5"
              >
                <Smile size={22} />
              </button>
              <textarea
                ref={inputRef as any}
                value={text}
                rows={1}
                onChange={(e) => {
                  const val = e.target.value
                  setText(val)
                  const el = e.target
                  el.style.height = '24px'
                  el.style.height = Math.min(120, el.scrollHeight) + 'px'
                  // Live typing for all users - stream each change (type + delete)
                  pushLiveDraft(val)
                  try {
                    const map = JSON.parse(kvGet('sc_composer_drafts') || '{}')
                    if (val) map[contactId] = val
                    else delete map[contactId]
                    kvSet('sc_composer_drafts', JSON.stringify(map))
                  } catch { /* */ }
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey && settings.enterIsSend) {
                    e.preventDefault()
                    send()
                  }
                }}
                placeholder="Message"
                className="max-h-[120px] min-h-[24px] flex-1 resize-none bg-transparent py-2.5 text-[16px] font-medium leading-5 text-ink outline-none placeholder:text-gray-400"
              />
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="mb-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-gray-500 hover:bg-black/5"
                aria-label="Send picture"
              >
                <ImagePlus size={22} />
              </button>
              <input ref={fileRef} type="file" accept="image/*" hidden onChange={onPickImage} />
            </div>
            {(text.trim() || pendingImage) ? (
              <button
                type="button"
                onClick={send}
                className="mb-0.5 flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-brand-purple text-white"
                aria-label="Send"
              >
                <Send size={20} />
              </button>
            ) : (
              <button
                type="button"
                className="mb-0.5 flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-brand-purple text-white active:scale-95"
                aria-label="Record voice note"
                onClick={async () => {
                  try {
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
                    const rec = new MediaRecorder(stream)
                    recordChunks.current = []
                    rec.ondataavailable = (ev) => {
                      if (ev.data.size) recordChunks.current.push(ev.data)
                    }
                    rec.onstop = async () => {
                      stream.getTracks().forEach((t) => t.stop())
                      if (recordTimer.current) clearInterval(recordTimer.current)
                      setRecording(false)
                      ;(window as any).__sc_rec?.(false)
                      const blob = new Blob(recordChunks.current, { type: rec.mimeType || 'audio/webm' })
                      if (blob.size < 400) {
                        setRecordSecs(0)
                        return
                      }
                      // Send as data URL voice note (backend stores as media attachment text for now)
                      const reader = new FileReader()
                      reader.onload = () => {
                        const dataUrl = String(reader.result || '')
                        setText('')
                        void (async () => {
                          showToast('Voice note ready')
                          // Optimistic: show duration as message body with voice prefix
                          const secs = recordSecs
                          setRecordSecs(0)
                          const body = `🎤 Voice note (${secs}s)`
                          // Reuse send path with body only - media upload path may be added later
                          setText(body)
                          setTimeout(() => {
                            send()
                          }, 30)
                        })()
                      }
                      reader.readAsDataURL(blob)
                    }
                    mediaRecRef.current = rec
                    rec.start()
                    setRecording(true)
                    setRecordSecs(0)
                    ;(window as any).__sc_rec?.(true)
                    recordTimer.current = setInterval(() => setRecordSecs((s) => s + 1), 1000)
                  } catch {
                    showToast('Microphone permission needed')
                  }
                }}
              >
                <Mic size={22} />
              </button>
            )}
          </div>
        )}
        </div>
      </div>
      )}

      {selfSwitchWarn && (
        <div className="absolute inset-0 z-[80] flex items-end justify-center bg-black/40 p-4 sm:items-center" onClick={() => setSelfSwitchWarn(null)}>
          <div className="w-full max-w-sm rounded-3xl bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <p className="text-lg font-black text-ink">Leave this section?</p>
            <p className="mt-2 text-sm font-semibold text-gray-500">
              You have something open. Move to {selfSwitchWarn.next === 'game' ? 'Game' : selfSwitchWarn.next} and discard unsaved work?
            </p>
            <button
              type="button"
              className="mt-4 w-full rounded-full bg-brand-purple py-3.5 text-sm font-extrabold text-white"
              onClick={() => {
                const next = selfSwitchWarn.next
                setSelfEditor(null)
                setSelfGameOpen(false)
                applySelfTab(next)
              }}
            >
              Move
            </button>
            <button type="button" className="mt-2 w-full py-3 text-sm font-extrabold text-gray-500" onClick={() => setSelfSwitchWarn(null)}>
              Stay
            </button>
          </div>
        </div>
      )}

      {lightboxUrl && (
        <div
          className="absolute inset-0 z-[60] flex items-center justify-center bg-black/85"
          onClick={() => setLightboxUrl(null)}
        >
          <button
            type="button"
            className="absolute right-4 top-[max(1rem,env(safe-area-inset-top))] z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/15 text-white"
            onClick={() => setLightboxUrl(null)}
            aria-label="Close"
          >
            <X size={22} />
          </button>
          <button
            type="button"
            className="absolute left-4 top-[max(1rem,env(safe-area-inset-top))] z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/15 text-white"
            onClick={(e) => {
              e.stopPropagation()
              try {
                const a = document.createElement('a')
                a.href = lightboxUrl
                a.download = `safechat-${Date.now()}.jpg`
                a.target = '_blank'
                document.body.appendChild(a)
                a.click()
                a.remove()
              } catch { /* */ }
            }}
            aria-label="Download"
          >
            <Download size={22} />
          </button>
          <img
            src={lightboxUrl}
            alt=""
            className="max-h-[92%] max-w-[96%] object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}

      {cropSrc && (
        <ChatImageCropper
          src={cropSrc}
          title="Crop photo"
          onCancel={() => setCropSrc(null)}
          onDone={(dataUrl) => {
            setCropSrc(null)
            setPendingImage(dataUrl)
          }}
        />
      )}

      {lockPrompt && (
        <div className="absolute inset-0 z-[65] flex flex-col items-center justify-center bg-black/40 px-6" onClick={() => setLockPrompt(false)}>
          <div className="w-full max-w-xs rounded-3xl bg-white p-5" onClick={(e) => e.stopPropagation()}>
            <p className="text-center text-lg font-black text-ink">{chatLocked ? 'Unlock chat' : 'Lock chat'}</p>
            <p className="mt-1 text-center text-xs font-semibold text-gray-400">Enter your chat lock PIN</p>
            <input
              type="password"
              inputMode="numeric"
              maxLength={8}
              autoFocus
              value={lockPinDraft}
              onChange={(e) => {
                setLockPinDraft(e.target.value.replace(/\D/g, '').slice(0, 8))
                setLockPinError('')
              }}
              onKeyDown={(e) => {
                if (e.key !== 'Enter') return
                try {
                  const pin = kvGet('sc_chat_lock_pin') || ''
                  if (!pin || lockPinDraft !== pin) {
                    setLockPinError('Wrong PIN')
                    return
                  }
                  const map = JSON.parse(kvGet('sc_chat_locks') || '{}')
                  if (chatLocked) {
                    delete map[contactId]
                    setChatLocked(false)
                    setUnlockedThisSession(true)
                    showToast?.('Chat unlocked')
                  } else {
                    map[contactId] = true
                    setChatLocked(true)
                    setUnlockedThisSession(false)
                    showToast?.('Chat locked')
                  }
                  kvSet('sc_chat_locks', JSON.stringify(map))
                  setLockPrompt(false)
                  setLockPinDraft('')
                } catch {
                  setLockPinError('Could not update lock')
                }
              }}
              className="mt-4 w-full rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-center text-lg font-black tracking-[0.35em] outline-none focus:border-brand-purple"
              placeholder="••••"
            />
            {lockPinError ? <p className="mt-2 text-center text-sm font-bold text-brand-red">{lockPinError}</p> : null}
            <button
              type="button"
              className="mt-4 w-full rounded-full bg-brand-purple py-3 text-sm font-extrabold text-white"
              onClick={() => {
                try {
                  const pin = kvGet('sc_chat_lock_pin') || ''
                  if (!pin || lockPinDraft !== pin) {
                    setLockPinError('Wrong PIN')
                    return
                  }
                  const map = JSON.parse(kvGet('sc_chat_locks') || '{}')
                  if (chatLocked) {
                    delete map[contactId]
                    setChatLocked(false)
                    setUnlockedThisSession(true)
                    showToast?.('Chat unlocked')
                  } else {
                    map[contactId] = true
                    setChatLocked(true)
                    setUnlockedThisSession(false)
                    showToast?.('Chat locked')
                  }
                  kvSet('sc_chat_locks', JSON.stringify(map))
                  setLockPrompt(false)
                  setLockPinDraft('')
                } catch {
                  setLockPinError('Could not update lock')
                }
              }}
            >
              {chatLocked ? 'Unlock' : 'Lock'}
            </button>
            <button type="button" className="mt-2 w-full py-2 text-sm font-bold text-gray-500" onClick={() => setLockPrompt(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}

      
      {blockOpen && (
        <div className="absolute inset-0 z-[55] flex flex-col justify-end bg-black/45 md:items-center md:justify-center" onClick={() => setBlockOpen(false)}>
          <div className="rounded-t-3xl bg-white px-5 pb-8 pt-4 shadow-[0_-12px_40px_rgba(0,0,0,0.25)] md:w-full md:max-w-md md:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-gray-200" />
            <p className="text-lg font-black">{peerBlocked ? 'Unblock' : 'Block'} {c.name.split(' ')[0]}?</p>
            <p className="mt-2 text-sm font-semibold text-gray-500">
              {peerBlocked
                ? 'They will be able to message and call you again.'
                : 'They won’t be able to message or call you. You can unblock them at any time.'}
            </p>
            <button
              type="button"
              disabled={blocking}
              className={`mt-5 w-full rounded-full py-3.5 text-sm font-extrabold text-white disabled:opacity-50 ${
                peerBlocked ? 'bg-brand-purple' : 'bg-brand-red'
              }`}
              onClick={async () => {
                setBlocking(true)
                try {
                  if (peerBlocked) {
                    await api.unblockUser(peerId || contactId)
                    setPeerBlocked(false)
                    showToast('User unblocked')
                  } else {
                    await api.blockUser(peerId || contactId)
                    setPeerBlocked(true)
                    showToast('User blocked')
                  }
                  await refreshContacts()
                  setBlockOpen(false)
                } catch (e: any) {
                  showToast(e?.message || `Could not ${peerBlocked ? 'unblock' : 'block'}`)
                } finally {
                  setBlocking(false)
                }
              }}
            >
              {blocking
                ? peerBlocked
                  ? 'Unblocking…'
                  : 'Blocking…'
                : peerBlocked
                  ? 'Unblock'
                  : 'Block'}
            </button>
            <button
              type="button"
              className="mt-2 w-full rounded-full bg-gray-100 py-3.5 text-sm font-extrabold text-gray-600"
              onClick={() => setBlockOpen(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export const ChatWindow = memo(ChatWindowInner)
