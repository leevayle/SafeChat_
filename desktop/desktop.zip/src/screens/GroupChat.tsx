import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowLeft, Smile, Send, Clock, Check, RotateCcw } from 'lucide-react'
import { Avatar } from '../components/Avatar'
import { api } from '../api'
import { FONT_SIZES, resolveWallpaper, useStore } from '../store'

import { kvGet, kvSet, kvRemove, kvGetJson, kvSetJson, hydrateKv } from '../lib/kv'
import { linkifyText } from '../lib/linkify'
const EMOJIS = [
  '😀','😁','😂','🤣','😃','😄','😅','😆','😉','😊','😋','😎','😍','😘','🥰','😗','😙','😚',
  '🙂','🤗','🤩','🤔','🤨','😐','😑','😶','🙄','😏','😣','😥','😮','🤐','😯','😪','😫','🥱',
  '😴','😌','😛','😜','😝','🤤','😒','😓','😔','😕','🙃','🤑','😲','☹️','🙁','😖','😞','😟',
  '😤','😢','😭','😦','😧','😨','😩','🤯','😬','😰','😱','🥵','🥶','😳','🤪','😵','😡','😠',
  '🤬','😷','🤒','🤕','🤢','🤮','🤧','😇','🥳','🥺','🤠','🤡','🤥','🤫','🤭','🧐','🤓','😈',
  '👋','🤚','🖐️','✋','🖖','👌','🤌','🤏','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','👇','👍',
  '👎','✊','👊','🤛','🤜','👏','🙌','👐','🤲','🤝','🙏','💪','🦾','🦵','🦶','👂','👃',
  '❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗','💖','💘','💝',
  '🔥','⭐','✨','🌟','💫','💥','💢','💦','💨','🎉','🎊','🎈','🎁','🏆','🥇','🎯','💯','✅',
  '☕','🍕','🍔','🍟','🌮','🍣','🍦','🍰','🍺','🍻','🎂','🍪','🍩','🍿','🥗','🍜',
]

export function GroupChat({
  groupId,
  onBack,
  onClosed,
  onCall,
}: {
  groupId: string
  onBack: () => void
  onClosed: () => void
  onCall?: (id: string, kind: 'audio' | 'video') => void
}) {
  const { groups, contacts, me, settings, refreshGroups, showToast } = useStore()
  const g = groups.find((x) => x.id === groupId)
  const [text, setText] = useState('')
  const [emoji, setEmoji] = useState(false)
  const [msgs, setMsgs] = useState<any[]>(g?.messages || [])
  const end = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setMsgs(g?.messages || [])
  }, [g?.messages])

  useEffect(() => {
    end.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [msgs, emoji])

  if (!g) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3">
        <p className="font-bold text-gray-400">Group not found</p>
        <button type="button" onClick={onClosed} className="font-bold text-brand-purple">
          Close
        </button>
      </div>
    )
  }

  const who = (id: string) => contacts.find((c) => c.id === id) || { id, name: id === me?.id ? 'You' : id }

  const deliverGroup = async (localId: string, body: string) => {
    try {
      const { message } = await api.sendGroup(groupId, body)
      setMsgs((m) => m.map((x) => (x.id === localId ? { ...message, state: message.state || 'sent' } : x)))
      refreshGroups().catch(() => {})
    } catch (e: any) {
      setMsgs((m) => m.map((x) => (x.id === localId ? { ...x, state: 'failed' } : x)))
      showToast(e?.message || 'Message failed - tap to retry')
    }
  }

  const send = async () => {
    const t = text.trim()
    if (!t) return
    setText('')
    setEmoji(false)
    const localId = `local-g-${Date.now()}`
    const optimistic = {
      id: localId,
      from: me?.id || '',
      text: t,
      time: new Date().toISOString(),
      timeLabel: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: (kvGet('sc_settings') ? (() => { try { return JSON.parse(kvGet('sc_settings') || '{}')?.timeFormat === '12h' } catch { return false } })() : false) }),
      state: 'pending' as const,
      mine: true,
    }
    setMsgs((m) => [...m, optimistic])
    void deliverGroup(localId, t)
  }

  const retryFailed = (m: any) => {
    if (m.state !== 'failed') return
    setMsgs((list) => list.map((x) => (x.id === m.id ? { ...x, state: 'pending' } : x)))
    showToast('Retrying…')
    void deliverGroup(m.id, m.text)
  }

  return (
    <div className="flex h-full flex-col" style={{ background: resolveWallpaper(settings.wallpaper, settings.colorMode) || '#F3F4F6' }}>
      <header className="z-10 flex shrink-0 items-center gap-2 bg-white px-2 pb-3 pt-5 shadow-sm">
        <button
          type="button"
          onClick={onBack}
          className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-gray-100"
        >
          <ArrowLeft size={22} />
        </button>
        <Avatar contact={{ id: g.id, name: g.name, hue: g.hue }} size={44} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-extrabold">{g.name}</p>
          <p className="truncate text-xs font-bold text-gray-400">
            {g.members?.length || 0} members
          </p>
        </div>
      </header>

      <div
        className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-4"
        style={{ fontSize: FONT_SIZES[settings.fontSize] || '1rem' }}
      >
        <AnimatePresence initial={false}>
          {msgs.map((m) => {
            if (m.system) {
              return (
                <p key={m.id} className="mx-auto w-fit rounded-full bg-white/80 px-3 py-1 text-xs font-bold text-gray-500">
                  {who(m.from).name} {m.text}
                </p>
              )
            }
            const mine = m.from === me?.id || m.mine
            return (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${mine ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  role={mine && m.state === 'failed' ? 'button' : undefined}
                  onClick={() => {
                    if (mine && m.state === 'failed') retryFailed(m)
                  }}
                  className={`max-w-[78%] px-4 py-2.5 shadow-sm ${
                    mine
                      ? 'rounded-3xl rounded-br-md bg-gradient-to-br from-brand-magenta to-brand-purple text-white'
                      : 'rounded-3xl rounded-bl-md bg-white text-ink'
                  } ${mine && m.state === 'failed' ? 'ring-2 ring-red-300/80' : ''}`}
                >
                  {!mine && (
                    <p className="mb-0.5 text-[11px] font-extrabold text-brand-purple">
                      {who(m.from).name}
                    </p>
                  )}
                  <p className="whitespace-pre-wrap break-words font-semibold leading-snug">
                    {linkifyText(m.text, { mine })}
                  </p>
                  {mine && (
                    <p className="mt-1 flex items-center justify-end gap-1 text-[11px] font-bold text-white/75">
                      {m.timeLabel || ''}
                      {m.state === 'pending' ? (
                        <Clock size={13} strokeWidth={2.5} aria-label="Sending" />
                      ) : m.state === 'failed' ? (
                        <RotateCcw size={13} strokeWidth={2.5} className="text-red-200" aria-label="Failed - tap to retry" />
                      ) : (
                        <Check size={13} strokeWidth={2.5} aria-label="Sent" />
                      )}
                    </p>
                  )}
                </div>
              </motion.div>
            )
          })}
        </AnimatePresence>
        <div ref={end} />
      </div>

            {emoji && (
        <div className="max-h-40 overflow-y-auto bg-gray-50 px-3 py-2">
          <div className="grid grid-cols-8 gap-1">
            {EMOJIS.map((e) => (
              <button
                key={e}
                type="button"
                className="flex h-9 w-full items-center justify-center rounded-lg text-xl transition hover:bg-white active:scale-90"
                onClick={() => setText((t) => t + e)}
              >
                {e}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="flex items-center gap-2 bg-white px-3 py-3 safe-pb">
        <button
          type="button"
          onClick={() => setEmoji((e) => !e)}
          className="flex h-10 w-10 items-center justify-center rounded-full text-gray-500 hover:bg-gray-100"
        >
          <Smile size={22} />
        </button>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && settings.enterIsSend) {
              e.preventDefault()
              send()
            }
          }}
          placeholder="Message"
          className="h-11 flex-1 rounded-full bg-gray-100 px-4 text-[15px] font-semibold outline-none"
        />
        <button
          type="button"
          onClick={send}
          disabled={!text.trim()}
          className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-purple text-white disabled:opacity-40"
        >
          <Send size={18} />
        </button>
      </div>
    </div>
  )
}
