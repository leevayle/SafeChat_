import { formatLocalTime } from './time'
import { kvGet, kvSet, kvRemove, kvGetJson, kvSetJson, hydrateKv } from './lib/kv'
import { API_BASE } from './config'
import { encodeStatusReply, parseStatusReply, statusReplyPreviewLabel } from './lib/statusReply'
/**
 * SafeChat API client — talks to FastAPI backend at /api/v1
 * Response shape: { success, message, data }
 */

const BASE = API_BASE

export type ApiUser = {
  id: string
  phone: string
  countryCode?: string
  username: string
  name: string
  bio: string
  photo: string | null
  online: boolean
  lastSeen?: string | null
  hue: [string, string]
  createdAt?: string
  email?: string | null
  phoneMatch?: boolean
  account_role?: string
  subscriptionPlan?: string
  accountStatus?: string
  verifiedBadge?: boolean
  premiumSettings?: Record<string, unknown>
  deactivatedAt?: string | null
  scheduledDeletionAt?: string | null
  /** Appearance — applied via CSS on login (no UI remount) */
  theme?: string
  chatAccent?: string
  colorMode?: string
  liquidGlass?: boolean
}

export type SupportReply = {
  id: string
  authorRole: 'USER' | 'ADMIN' | 'SUPER_ADMIN'
  body: string
  createdAt: string
}

export type SupportTicket = {
  id: string
  subject: string
  body: string
  status: 'open' | 'replied' | 'closed'
  createdAt: string
  updatedAt: string
  replies: SupportReply[]
}

type SupportTicketData = {
  id: string
  subject: string
  body: string
  status: SupportTicket['status']
  created_at: string
  updated_at: string
  replies: { id: string; author_role: SupportReply['authorRole']; body: string; created_at: string }[]
}

function mapSupportTicket(ticket: SupportTicketData): SupportTicket {
  return {
    id: ticket.id,
    subject: ticket.subject,
    body: ticket.body,
    status: ticket.status,
    createdAt: ticket.created_at,
    updatedAt: ticket.updated_at,
    replies: ticket.replies.map((reply) => ({
      id: reply.id,
      authorRole: reply.author_role,
      body: reply.body,
      createdAt: reply.created_at,
    })),
  }
}

export type ApiContact = {
  premium?: boolean
  subscriptionPlan?: string
  verifiedBadge?: boolean

  id: string
  entryId: string
  peerId: string | null
  phone: string
  username: string
  name: string
  savedName: string
  bio: string
  note: string
  photo: string | null
  online: boolean
  lastSeen?: string | null
  hue: [string, string]
  pinned?: boolean
  favourite?: boolean
  blocked?: boolean
  isContact?: boolean
  createdAt?: string
}

export type ApiMsg = {
  id: string
  /** Stable UI key so optimistic → server id swap does not remount/re-animate the bubble */
  clientKey?: string
  from: string
  to: string
  text: string
  image?: string | null
  time: string
  state?: 'pending' | 'sent' | 'delivered' | 'read' | 'failed'
  mine?: boolean
  timeLabel?: string
  conversationId?: string
  messageType?: string
  edited?: boolean
  deleted?: boolean
  forwarded?: boolean
  reactions?: { emoji: string; user_id?: string }[]
  replyToId?: string | null
  replyToText?: string | null
  /** Encoded status reply preview */
  statusReply?: { preview: string; time?: string; statusId?: string } | null
  /** Inline call log row in chat */
  callLog?: {
    kind: 'audio' | 'video'
    direction: string
    status: string
    duration?: string
  } | null
}


export type ApiNote = {
  id: string
  kind: 'note' | 'checklist' | 'reminder'
  title: string
  body: string
  items?: { id: string; text: string; done: boolean }[]
  remindAt?: string | null
  pinned?: boolean
  color?: string | null
  createdAt: string
  updatedAt: string
}

function mapNote(n: any): ApiNote {
  return {
    id: String(n.id || n._id || ''),
    kind: (n.kind || 'note') as ApiNote['kind'],
    title: n.title || '',
    body: n.body || '',
    items: Array.isArray(n.items)
      ? n.items.map((it: any) => ({
          id: String(it.id || ''),
          text: it.text || '',
          done: !!it.done,
        }))
      : [],
    remindAt: n.remind_at || n.remindAt || null,
    pinned: !!n.pinned,
    color: n.color || null,
    createdAt: n.created_at || n.createdAt || new Date().toISOString(),
    updatedAt: n.updated_at || n.updatedAt || new Date().toISOString(),
  }
}

export type ChatPreview = {
  contactId: string
  conversationId?: string
  name?: string
  publicName?: string
  photo?: string | null
  hue?: [string, string]
  last: string
  time: string
  unread: number
  mine?: boolean
  state?: 'pending' | 'sent' | 'delivered' | 'read' | 'failed'
  iso?: string
}

const HUE_PALETTE: [string, string][] = [
  ['#7B2CBF', '#9C31A1'],
  ['#6389EB', '#7B2CBF'],
  ['#E3404C', '#FF8C00'],
  ['#F97316', '#E3404C'],
  ['#0EA5E9', '#6366F1'],
  ['#10B981', '#059669'],
]

function hueFor(id: string): [string, string] {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h + id.charCodeAt(i) * (i + 1)) % HUE_PALETTE.length
  return HUE_PALETTE[h]
}

let memoryAccess = ''
let memoryRefresh = ''

function accessToken() {
  if (memoryAccess) return memoryAccess
  // Legacy IDB only during migration; prefer memory
  const fromKv = kvGet('sc_access') || kvGet('sc_token') || ''
  if (fromKv) memoryAccess = fromKv
  return memoryAccess
}

function refreshToken() {
  // Prefer memory, then durable kv. Cookie is still sent with credentials:include
  // when the browser allows it; body token is the cross-origin fallback.
  if (memoryRefresh) return memoryRefresh
  const fromKv = kvGet('sc_refresh') || ''
  if (fromKv) memoryRefresh = fromKv
  return memoryRefresh
}

/** JWT exp (seconds) or 0 if unreadable — does not verify signature. */
function tokenExpiresAt(token?: string): number {
  const t = token || accessToken()
  if (!t || t.split('.').length < 2) return 0
  try {
    const payload = JSON.parse(atob(t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')))
    return typeof payload.exp === 'number' ? payload.exp : 0
  } catch {
    return 0
  }
}

/** Refresh if access token missing or expiring within 90s. */
async function ensureFreshAccess(): Promise<boolean> {
  if (sessionDead) return false
  const access = accessToken()
  const refresh = refreshToken()
  // Cookie may still allow refresh when both memory values are empty
  if (!access && !refresh) return tryRefresh()
  if (!access && refresh) return tryRefresh()
  const exp = tokenExpiresAt(access)
  if (!exp) return true // opaque / non-JWT — let server decide
  const now = Math.floor(Date.now() / 1000)
  if (exp - now <= 90) return tryRefresh()
  return true
}

/** Public: refresh access token if missing/expiring (used on boot). */
export async function ensureSessionFresh(): Promise<boolean> {
  return ensureFreshAccess()
}

/**
 * Force a refresh-token rotate (used when WS/API got 401/403 despite a non-expired JWT).
 * Returns true only when a new access token was stored.
 */
export async function forceRefreshSession(): Promise<boolean> {
  if (sessionDead) return false
  // Refresh cookie may exist even when memory refresh token is empty
  return tryRefresh()
}

/** True when an access token is present (does not validate server-side). */
export function hasAccessToken(): boolean {
  return !!accessToken()
}

/** In-memory access JWT for WebSocket auth (not persisted). */
export function getAccessToken(): string {
  return accessToken()
}

/** Set after a permanent 401 so callers stop firing protected requests. */
let sessionDead = false

export function isSessionDead(): boolean {
  return sessionDead
}

export function markSessionAlive() {
  sessionDead = false
}

export function markSessionDead() {
  if (sessionDead) return
  sessionDead = true
  clearSession()
  try {
    window.dispatchEvent(new CustomEvent('sc:auth-failed'))
  } catch {
    /* ignore */
  }
}

export function setSession(access: string, refresh: string, user: ApiUser) {
  sessionDead = false
  memoryAccess = access || ''
  // Access: memory only. Refresh: memory + kv so prod works when third-party
  // cookies (API on another host) are blocked. Server also sets HttpOnly cookie.
  kvRemove('sc_access')
  kvRemove('sc_token')
  if (refresh) {
    memoryRefresh = refresh
    kvSet('sc_refresh', refresh)
  } else {
    memoryRefresh = ''
  }
  if (user) kvSet('sc_user', JSON.stringify(user))
  startProactiveRefresh()
}

export function saveStoredUser(user: ApiUser) {
  kvSet('sc_user', JSON.stringify(user))
}

export function clearSession() {
  stopProactiveRefresh()
  memoryAccess = ''
  memoryRefresh = ''
  kvRemove('sc_access')
  kvRemove('sc_refresh')
  kvRemove('sc_token')
  kvRemove('sc_user')
}

function isPublicAuthPath(path: string) {
  return (
    path.includes('/auth/login') ||
    path.includes('/auth/register') ||
    path.includes('/auth/refresh') ||
    path.includes('/auth/phone/') ||
    path.includes('/auth/username/')
  )
}

export function getStoredUser(): ApiUser | null {
  try {
    const raw = kvGet('sc_user')
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

function mapUser(u: any): ApiUser {
  const id = String(u.id || u._id || '')
  return {
    id,
    phone: u.phone_number || u.phone || '',
    phoneMatch: !!u.phone_match,
    countryCode: u.countryCode,
    username: u.username || '',
    name: u.display_name || u.name || u.username || '',
    bio: u.bio || '',
    photo: u.profile_photo ?? u.photo ?? null,
    online: !!u.online,
    lastSeen: u.last_seen || u.lastSeen || null,
    hue: hueFor(id || u.username || 'x'),
    createdAt: u.created_at || u.createdAt,
    email: u.email || '',
    account_role: u.account_role,
    subscriptionPlan: (u.subscription_plan || u.subscriptionPlan || 'pro').replace('free', 'pro'),
    accountStatus: u.account_status || u.accountStatus || 'active',
    verifiedBadge: !!(u.verified_badge ?? u.premium_settings?.verified_badge),
    premiumSettings: u.premium_settings || u.premiumSettings || {},
    premiumExpiresAt: u.premium_expires_at || u.premiumExpiresAt || null,
    deactivatedAt: u.deactivated_at || null,
    scheduledDeletionAt: u.scheduled_deletion_at || null,
    // Appearance (optional on type — used immediately on login)
    theme: u.theme || u.settings?.theme || undefined,
    chatAccent: u.chat_accent || u.chatAccent || u.settings?.chat_accent || undefined,
    colorMode: u.color_mode || u.colorMode || u.settings?.color_mode || undefined,
    liquidGlass:
      u.liquid_glass != null
        ? !!u.liquid_glass
        : u.liquidGlass != null
          ? !!u.liquidGlass
          : u.settings?.liquid_glass != null
            ? !!u.settings.liquid_glass
            : undefined,
  } as ApiUser
}

function mapContact(c: any): ApiContact {
  const peerId = String(c.contact_user_id || c.peerId || c.id || '')
  const ps = c.premium_settings || c.premiumSettings || {}
  return {
    id: peerId,
    entryId: String(c.id || peerId),
    peerId,
    phone: c.phone_number || c.phone || c.contact_phone || c.peer_phone || '',
    username: c.username || '',
    name: c.nickname || c.saved_name || c.savedName || c.display_name || c.name || c.username || peerId || 'User',
    savedName: c.nickname || c.saved_name || c.savedName || '',
    publicName: c.display_name || c.name || c.username || '',
    bio: c.bio || '',
    note: c.note || '',
    photo: c.profile_photo ?? c.photo ?? null,
    online: !!c.online,
    lastSeen: c.last_seen || c.lastSeen || null,
    hue: hueFor(peerId || c.username || 'x'),
    createdAt: c.created_at,
    subscriptionPlan: (c.subscription_plan || c.subscriptionPlan || 'pro').replace('free', 'pro'),
    verifiedBadge: !!(c.verified_badge ?? c.verifiedBadge ?? ps.verified_badge),
    premium:
      (c.subscription_plan || c.subscriptionPlan) === 'premium' &&
      (c.verified_badge ?? c.verifiedBadge ?? ps.verified_badge) !== false,
    premiumSettings: ps,
    busy: !!(c.busy ?? (c.preferences || {}).busy_enabled),
    busyMessage: c.busy_message || c.busyMessage || (c.preferences || {}).busy_message || '',
    busyUntil: c.busy_until || c.busyUntil || (c.preferences || {}).busy_until || null,
  } as ApiContact
}

function mapMessage(m: any, meId?: string): ApiMsg {
  let created = String(m.created_at || m.time || '')
  // Treat naive backend timestamps as UTC
  if (created && /^\d{4}-\d{2}-\d{2}T/.test(created) && !/[zZ]|[+-]\d{2}:?\d{2}$/.test(created)) {
    created = created + 'Z'
  }
  let timeLabel = ''
  try {
    const d = new Date(created)
    if (!isNaN(d.getTime())) {
      timeLabel = d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', hour12: (typeof window !== 'undefined' && (() => { try { const s = JSON.parse(kvGet('sc_settings') || '{}'); return s?.timeFormat === '12h' } catch { return false } })()) })
    }
  } catch { /* */ }
  const from = String(m.sender_id || m.from || '')
  const media = m.media_attachments || m.media || []
  const firstMedia = Array.isArray(media) && media.length ? media[0] : null
  const image =
    (firstMedia && (firstMedia.url || firstMedia.data || firstMedia.src)) ||
    m.image ||
    null
  let state: ApiMsg['state'] = (m.delivery_status as any) || 'sent'
  if (state !== 'sent' && state !== 'delivered' && state !== 'read') state = 'sent'
  let text = String(m.content ?? m.text ?? '')
  let statusReply: ApiMsg['statusReply'] = null
  const parsed = parseStatusReply(text)
  if (parsed.statusReply) {
    statusReply = parsed.statusReply
    text = parsed.text
  }
  const clientKey = m.client_key || m.clientKey || m.idempotency_key || undefined
  return {
    id: String(m.id || m._id),
    clientKey: clientKey ? String(clientKey) : undefined,
    from,
    to: String(m.to || ''),
    text,
    image,
    time: created,
    timeLabel,
    state,
    mine: meId ? from === meId : !!m.mine,
    conversationId: m.conversation_id,
    messageType: m.message_type,
    deleted: !!(m.deleted || m.deleted_at),
    edited: !!(m.edited || m.is_edited || m.edited_at),
    forwarded: !!(m.forwarded_from || m.forwarded),
    reactions: m.reactions || [],
    replyToId: m.reply_to_message_id || m.replyToId || null,
    replyToText: m.reply_to_text || m.replyToText || null,
    statusReply: statusReply || m.status_reply || null,
  }
}

function formatChatPreviewLast(raw: string): string {
  if (!raw) return ''
  return statusReplyPreviewLabel(raw)
}

function mapConversation(c: any, meId?: string): ChatPreview {
  const participants = c.participants || []
  const other =
    participants.find((p: any) => String(p.id) !== meId) ||
    participants[0] ||
    {}
  const last = c.last_message
  const lastText = last?.content || last?.text || ''
  let time = ''
  const iso = c.last_message_at || last?.created_at
  if (iso) {
    try {
      time = formatLocalTime(iso)
    } catch { /* */ }
  }
  const contactId = String(other.id || (c.participant_ids || []).find((id: string) => id !== meId) || c.id)
  return {
    contactId,
    conversationId: String(c.id),
    // Public name from server — UI prefers local savedName via contacts overlay
    name: other.nickname || other.saved_name || other.display_name || other.username || contactId,
    publicName: other.display_name || other.username || contactId,
    username: other.username || '',
    photo: other.profile_photo ?? null,
    hue: hueFor(contactId),
    last: formatChatPreviewLast(lastText),
    time,
    unread: c.unread_count || 0,
    mine: last ? String(last.sender_id) === meId : false,
    state: ((last?.delivery_status as ApiMsg['state']) || 'sent') as ChatPreview['state'],
    iso: iso || undefined,
  }
}

function mapGroup(g: any): any {
  return {
    id: String(g.id),
    name: g.group_name || g.name,
    desc: g.group_description || g.desc || '',
    photo: g.group_photo || null,
    creatorId: g.creator_id,
    adminIds: g.admin_ids || [],
    memberIds: g.member_ids || [],
    conversationId: g.conversation_id,
    createdAt: g.created_at,
    hue: hueFor(String(g.id)),
  }
}

export function mapStatusFromWs(s: any): any {
  return mapStatus(s)
}

function mapStatus(s: any): any {
  const userId = String(s.owner_user_id || s.userId || '')
  const owner = s.owner || s.user || {}
  const name =
    owner.display_name ||
    owner.name ||
    s.owner_display_name ||
    s.owner_username ||
    owner.username ||
    'Contact'
  const createdAt = s.created_at || s.createdAt || null
  // Clock time in the user's preferred 12h/24h format (from settings via formatLocalTime)
  let ago = ''
  try {
    // lazy import avoided - format via dynamic requires would cycle; set empty and let UI format
    ago = createdAt ? String(createdAt) : ''
  } catch {
    ago = ''
  }
  return {
    id: String(s.id || s._id),
    userId,
    text: String(s.content || s.text || '').replace(/^\u2063repost\u2063/, ''),
    image: (s.media_attachments && s.media_attachments.find((m: any) => m.type === 'image')?.url) || s.image || null,
    video: (s.media_attachments && s.media_attachments.find((m: any) => m.type === 'video')?.url) || s.video || null,
    background: s.background || 'theme_purple_grad',
    createdAt,
    expiresAt: s.expires_at || s.expiresAt,
    type: s.status_type || s.type || 'text',
    views: Array.isArray(s.viewer_ids) ? s.viewer_ids : Array.isArray(s.views) ? s.views : [],
    viewCount: s.view_count ?? s.viewCount ?? (Array.isArray(s.viewer_ids) ? s.viewer_ids.length : Array.isArray(s.views) ? s.views.length : 0),
    isAd: !!(s.is_ad || s.isAd),
    adReach: s.ad_reach || s.adReach || null,
    isRepost: !!(
      s.is_repost ||
      s.isRepost ||
      s.repost_of_status_id ||
      s.repostOfStatusId ||
      s.repost_of ||
      (typeof s.content === 'string' && s.content.startsWith('\u2063repost\u2063'))
    ),
    // Prefer ISO; UI formats with formatLocalTime so 12h/24h settings apply
    ago,
    user: {
      id: userId,
      name,
      username: owner.username || s.owner_username || '',
      photo: owner.profile_photo ?? owner.photo ?? s.owner_profile_photo ?? null,
      hue: hueFor(userId || name),
      online: false,
    },
  }
}

type BackendEnvelope = {
  success?: boolean
  message?: string
  data?: any
  error_code?: string
}

/** Single-flight refresh — concurrent 401s must share one rotate, or the second kills the session. */
let refreshInflight: Promise<boolean> | null = null
let consecutiveRefreshFails = 0

async function tryRefresh(): Promise<boolean> {
  if (refreshInflight) return refreshInflight
  refreshInflight = (async () => {
    const rt = refreshToken()
    /* cookie may carry refresh even when rt empty */
    try {
      const res = await fetch(`${BASE}/api/v1/auth/refresh`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: rt || undefined }),
      })
      const body: BackendEnvelope = await res.json().catch(() => ({}))
      if (!res.ok || body.success === false) {
        consecutiveRefreshFails += 1
        return false
      }
      const data = body.data || body
      if ((data as any).access_token) {
        memoryAccess = (data as any).access_token
        kvRemove('sc_access')
        kvRemove('sc_token')
        const nextRt = (data as any).refresh_token
        if (nextRt) {
          memoryRefresh = String(nextRt)
          kvSet('sc_refresh', memoryRefresh)
        }
        sessionDead = false
        consecutiveRefreshFails = 0
        // Keep the existing WS if it is healthy — reconnecting on every refresh
        // broadcasts offline/online to contacts and makes the green dot flicker.
        try {
          void import('./realtime').then((m) => {
            if (typeof m.isRealtimeOpen === 'function' && m.isRealtimeOpen()) return
            m.forceReconnectRealtime?.()
          })
        } catch { /* */ }
        return true
      }
      consecutiveRefreshFails += 1
      return false
    } catch {
      consecutiveRefreshFails += 1
      return false
    } finally {
      refreshInflight = null
    }
  })()
  return refreshInflight
}

/**
 * Proactive session watch:
 * - refresh before access JWT expires
 * - if access is already expired and refresh fails, log out immediately
 *   (do not wait for the next API call to surface "session expired")
 */
let refreshTimer: ReturnType<typeof setInterval> | null = null
export function startProactiveRefresh() {
  if (refreshTimer) return
  const tick = async () => {
    if (sessionDead) return
    const access = accessToken()
    const exp = tokenExpiresAt(access)
    const now = Math.floor(Date.now() / 1000)
    // No access token in memory: try refresh; hard logout if that fails
    if (!access) {
      const ok = await tryRefresh()
      if (!ok) markSessionDead()
      return
    }
    if (!exp) return
    // Already past expiry: refresh or logout now
    if (exp <= now) {
      const ok = await tryRefresh()
      if (!ok) markSessionDead()
      return
    }
    // Expiring within 2 minutes: refresh quietly
    if (exp - now <= 120) {
      const ok = await tryRefresh()
      if (!ok && exp - now <= 15) markSessionDead()
    }
  }
  void tick()
  refreshTimer = setInterval(() => {
    void tick()
  }, 20 * 1000) // every 20s so expiry is caught without waiting on API errors
}
export function stopProactiveRefresh() {
  if (refreshTimer) {
    clearInterval(refreshTimer)
    refreshTimer = null
  }
}

/** True for background/read polls — never force logout on these alone. */
function isSoftReadPath(path: string, method: string) {
  const m = (method || 'GET').toUpperCase()
  if (m !== 'GET' && m !== 'HEAD') return false
  // Soft reads that fire often while scrolling / idling
  return (
    path.includes('/conversations') ||
    path.includes('/messages') ||
    path.includes('/statuses') ||
    path.includes('/contacts') ||
    path.includes('/groups') ||
    path.includes('/calls') ||
    path.includes('/users/search') ||
    path.includes('/users/me') ||
    path.includes('/contact-requests') ||
    path.includes('/contacts/requests') ||
    path.includes('/notifications') ||
    path.includes('/auth/me')
  )
}

async function req<T = any>(path: string, opts: RequestInit = {}, retried = false): Promise<T> {
  const publicPath = isPublicAuthPath(path)
  const method = (opts.method || 'GET').toUpperCase()

  // Hard stop only when session was proven dead (failed write/auth after refresh)
  if (!publicPath) {
    if (sessionDead) {
      const err = new Error('Session expired - log in again')
      ;(err as any).status = 401
      throw err
    }
    if (!accessToken() && !refreshToken()) {
      // Still try — HttpOnly cookie may refresh; only fail if that fails later
    }
    // Refresh early so soft polls rarely hit a raw 401 in the network log
    if (!retried) {
      await ensureFreshAccess()
    }
  }

  const headers: Record<string, string> = {
    ...(opts.headers as Record<string, string>),
  }
  if (!(opts.body instanceof FormData)) {
    headers['Content-Type'] = headers['Content-Type'] || 'application/json'
  }
  const tkn = accessToken()
  if (tkn) headers.Authorization = `Bearer ${tkn}`

  if (!BASE && import.meta.env.PROD) {
    const err = new Error('SafeChat server could not be reached. API URL is not configured.')
    ;(err as any).status = 0
    ;(err as any).network = true
    throw err
  }

  let res: Response
  try {
    res = await fetch(`${BASE}${path}`, {
      ...opts,
      credentials: 'include',
      headers,
    })
  } catch (e: any) {
    const msg = networkReachabilityMessage(e)
    const err = new Error(msg)
    ;(err as any).status = 0
    ;(err as any).network = true
    throw err
  }
  const body: BackendEnvelope = await res.json().catch(() => ({} as BackendEnvelope))

  if (res.status === 401 && !publicPath) {
    if (!retried) {
      const ok = await tryRefresh()
      if (ok) return req(path, opts, true)
    }
    // Soft reads: do not deauth — just fail this request (UI keeps cached data)
    const soft = isSoftReadPath(path, method)
    // Require several consecutive refresh failures before killing the session.
    // Transient network blips must not force a full re-login.
    if (!soft && consecutiveRefreshFails >= 5) {
      markSessionDead()
    }
    const err = new Error(
      soft
        ? 'Temporarily unavailable'
        : friendlyError(body.message || 'Session expired - log in again', 401, path),
    )
    ;(err as any).status = 401
    ;(err as any).soft = soft
    throw err
  }

  if (!res.ok || body.success === false) {
    const raw = body.message || (body as any).error || res.statusText || 'Request failed'
    const err = new Error(friendlyError(raw, res.status, path))
    ;(err as any).status = res.status
    throw err
  }
  return (body.data !== undefined ? body.data : body) as T
}


/** Offline vs SafeChat server unreachable — never show raw "Failed to fetch". */
function networkReachabilityMessage(_raw?: unknown): string {
  try {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return "You're offline. Check your internet connection and try again."
    }
  } catch {
    /* */
  }
  return 'SafeChat server could not be reached. Please try again in a moment.'
}

/** Map technical API errors to short, user-friendly copy. */
function friendlyError(raw: string, status?: number, path?: string): string {
  const t = (raw || '').toLowerCase()
  const isAuthForm =
    path?.includes('/auth/login') ||
    path?.includes('/auth/register') ||
    path?.includes('/auth/verify')
  if (
    t.includes('invalid username') ||
    t.includes('invalid password') ||
    t.includes('incorrect password') ||
    t.includes('invalid credentials') ||
    t.includes('wrong password') ||
    (isAuthForm && (status === 401 || status === 400 || t.includes('unauthorized')))
  ) {
    return 'Wrong username or password'
  }
  if (t.includes('invalid token') || t.includes('not authenticated') || t.includes('token expired')) {
    return 'Session expired - log in again'
  }
  if (!isAuthForm && (status === 401 || t.includes('unauthorized'))) {
    return 'Session expired - log in again'
  }
  if (status === 403 || t.includes('forbidden')) return 'You don’t have permission for that'
  if (status === 404 || t.includes('not found')) {
    if (isAuthForm) return 'Cannot reach server - start the backend on port 8000, then try again'
    return 'Not found'
  }
  if (status === 409 || t.includes('conflict') || t.includes('already')) return raw.length < 80 ? raw : 'That action isn’t available right now'
  if (status === 429 || t.includes('rate limit') || t.includes('too many')) return 'Slow down a moment and try again'
  if (status && status >= 500) return 'Something went wrong - try again'
  if (
    t.includes('network') ||
    t.includes('failed to fetch') ||
    t.includes('econnrefused') ||
    t.includes('proxy') ||
    t.includes('load failed') ||
    t.includes('networkerror')
  ) {
    return networkReachabilityMessage(raw)
  }
  if (t.includes('incorrect password') || t.includes('wrong password')) return 'Incorrect password'
  // Keep short human messages; trim long technical dumps
  if (raw && raw.length <= 90 && !t.includes('exception') && !t.includes('traceback')) return raw
  return 'Something went wrong - try again'
}

function meId(): string {
  return getStoredUser()?.id || ''
}

export const api = {
  supportTickets: async (page = 1, pageSize = 25) => {
    const data = await req<{ items: SupportTicketData[]; total: number; page: number; page_size: number }>(
      `/api/v1/support/tickets?page=${page}&page_size=${pageSize}`,
    )
    return {
      ...data,
      items: data.items.map(mapSupportTicket),
    }
  },
  createSupportTicket: async (subject: string, body: string) => {
    const data = await req<SupportTicketData>('/api/v1/support/tickets', {
      method: 'POST',
      body: JSON.stringify({ subject, body }),
    })
    return mapSupportTicket(data)
  },
  replySupportTicket: async (ticketId: string, body: string) => {
    const data = await req<SupportTicketData>(`/api/v1/support/tickets/${encodeURIComponent(ticketId)}/replies`, {
      method: 'POST',
      body: JSON.stringify({ body }),
    })
    return mapSupportTicket(data)
  },
  tictactoeInvite: async (peer_user_id: string) => {
    const data = await req<any>('/api/v1/games/tictactoe/invite', {
      method: 'POST',
      body: JSON.stringify({ peer_user_id, game: 'tictactoe' }),
    })
    return data
  },
  tictactoeAccept: async (gameId: string) =>
    req<any>(`/api/v1/games/tictactoe/${gameId}/accept`, { method: 'POST', body: '{}' }),
  tictactoeDecline: async (gameId: string) =>
    req<any>(`/api/v1/games/tictactoe/${gameId}/decline`, { method: 'POST', body: '{}' }),
  tictactoeGet: async (gameId: string) =>
    req<any>(`/api/v1/games/tictactoe/${gameId}`),
  tictactoeMove: async (gameId: string, cell: number) =>
    req<any>(`/api/v1/games/tictactoe/${gameId}/move`, {
      method: 'POST',
      body: JSON.stringify({ cell }),
    }),
  tictactoeLeave: async (gameId: string) =>
    req<any>(`/api/v1/games/tictactoe/${gameId}/leave`, { method: 'POST', body: '{}' }),


  health: () =>
    fetch(`${BASE}/health`)
      .then((r) => r.json())
      .then((j) => ({ ok: j.status === 'ok' || j.status === 'alive' })),

  checkUsername: async (username: string) => {
    if (!BASE && import.meta.env.PROD) {
      throw new Error('SafeChat server could not be reached. API URL is not configured.')
    }
    const data = await req<any>(`/api/v1/auth/username/check?username=${encodeURIComponent(username)}`)
    const available = data?.available ?? data?.data?.available
    if (typeof available !== 'boolean') {
      throw new Error('SafeChat server could not be reached. Please try again in a moment.')
    }
    return { available }
  },

  checkPhone: async (phone: string) => {
    if (!BASE && import.meta.env.PROD) {
      throw new Error('SafeChat server could not be reached. API URL is not configured.')
    }
    const data = await req<any>(`/api/v1/auth/phone/check?phone=${encodeURIComponent(phone)}`)
    const available = data?.available ?? data?.data?.available
    if (typeof available !== 'boolean') {
      throw new Error('SafeChat server could not be reached. Please try again in a moment.')
    }
    return { available }
  },

  sendPhoneCode: (phone_number: string) => req<any>('/api/v1/auth/phone/send-code', {
    method: 'POST', body: JSON.stringify({ phone_number }),
  }),

  verifyPhoneCode: (phone_number: string, code: string) => req<any>('/api/v1/auth/phone/verify-code', {
    method: 'POST', body: JSON.stringify({ phone_number, code }),
  }),

  register: async (body: {
    username: string
    display_name: string
    password: string
    phone_number: string
    registration_token?: string
    email?: string
    profile_photo?: string | null
    bio?: string
  }) => {
    const payload: Record<string, unknown> = {
      username: body.username,
      display_name: body.display_name,
      password: body.password,
      phone_number: body.phone_number,
    }
    if (body.email) payload.email = body.email
    if (body.bio) payload.bio = body.bio
    if (body.profile_photo) payload.profile_photo = body.profile_photo
    return req<any>('/api/v1/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    })
  },

  login: async (body: {
    phone_number?: string
    username?: string
    password: string
    device_name?: string
  }) => {
    const payload: Record<string, unknown> = {
      password: body.password,
      device_name: body.device_name || 'Web',
    }
    if (body.username) payload.username = body.username
    if (body.phone_number) payload.phone_number = body.phone_number
    const data = await req<any>('/api/v1/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    })
    const user = mapUser(data.user || data)
    if (data.password_reset_required) {
      return {
        password_reset_required: true as const,
        password_reset_token: String(data.password_reset_token || ''),
        user,
      }
    }
    return {
      access_token: data.access_token as string,
      refresh_token: data.refresh_token as string,
      user,
    }
  },

  requestPasswordReset: async (email: string) =>
    req<any>('/api/v1/auth/password-reset/request', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),

  completePasswordReset: async (resetLoginToken: string, newPassword: string) =>
    req<any>('/api/v1/auth/password-reset/complete', {
      method: 'POST',
      body: JSON.stringify({
        reset_login_token: resetLoginToken,
        new_password: newPassword,
      }),
    }),

  changePassword: async (currentPassword: string, newPassword: string) =>
    req<any>('/api/v1/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({
        current_password: currentPassword,
        new_password: newPassword,
      }),
    }),

  logout: async () => {
    const rt = refreshToken()
    if (rt) {
      try {
        await req('/api/v1/auth/logout', {
          method: 'POST',
          body: JSON.stringify({ refresh_token: rt || undefined }),
        })
      } catch { /* */ }
    }
    return { ok: true }
  },

  me: async () => {
    const data = await req<any>('/api/v1/auth/me')
    const theme = (data && data.theme) || 'purple'
    const prefs = (data && data.preferences) || {}
    const map: Record<string, string> = {
      chat_accent: 'chatAccent',
      font_size: 'fontSize',
      status_privacy: 'statusPrivacy',
      status_selected_contacts: 'statusSelectedContacts',
      status_excluded_contacts: 'statusExcludedContacts',
      status_validity: 'statusValidity',
      msg_notif: 'msgNotif',
      group_notif: 'groupNotif',
      call_notif: 'callNotif',
      enter_is_send: 'enterIsSend',
      typing_indicator: 'typingIndicator',
      auto_download: 'autoDownload',
      sound: 'sound',
      read_receipts: 'readReceipts',
      status_like_notif: 'statusLikeNotif',
      color_mode: 'colorMode',
      liquid_glass: 'liquidGlass',
      hide_live_typing: 'hideLiveTyping',
      show_fab: 'showFab',
      time_format: 'timeFormat',
      previews: 'previews',
      vibrate: 'vibrate',
      low_data_calls: 'lowDataCalls',
      disappearing: 'disappearing',
      last_seen: 'lastSeen',
      profile_photo: 'profilePhoto',
      about_privacy: 'about',
      groups_add: 'groupsAdd',
      force_read_receipts: 'forceReadReceipts',
      live_typing: 'liveTyping',
      status_ads_enabled: 'statusAdsEnabled',
      verified_badge: 'verifiedBadge',
      wallpaper: 'wallpaper',
      language: 'language',
    }
    const mapped: Record<string, unknown> = {
      theme: prefs.theme || theme,
      email: data?.email || '',
      phone: data?.phone_number || data?.phone || '',
      subscriptionPlan: (data?.subscription_plan || 'pro').replace('free', 'pro'),
      premiumExpiresAt: data?.premium_expires_at || null,
      // flatten server settings for client store
      ...(data?.settings
        ? {
            theme: data.settings.theme,
            chatAccent: data.settings.chat_accent,
            wallpaper: data.settings.wallpaper,
            colorMode: data.settings.color_mode,
            liquidGlass: data.settings.liquid_glass,
            statusValidity: data.settings.status_validity,
            statusPrivacy: data.settings.status_privacy,
            verifiedBadge: data.settings.verified_badge !== false,
            forceReadReceipts: !!data.settings.force_read_receipts,
            // Defaults: live typing ON, status ads ON unless user turned them off
            liveTyping: data.settings.live_typing !== false,
            statusAdsEnabled: data.settings.status_ads_enabled !== false,
          }
        : {}),
      accountStatus: data?.account_status || 'active',
      verifiedBadge: data?.subscription_plan === 'premium' && !!(data?.premium_settings?.verified_badge ?? true),
      premiumSettings: data?.premium_settings || {
        verified_badge: true,
        force_read_receipts: false,
        live_typing: true,
        status_ads_enabled: true,
      },
      deactivatedAt: data?.deactivated_at || null,
      scheduledDeletionAt: data?.scheduled_deletion_at || null,
    }
    for (const [k, v] of Object.entries(prefs)) {
      const fe = map[k] || k
      if (v !== undefined && v !== null) mapped[fe] = v
    }
    return {
      user: mapUser(data),
      settings: mapped,
    }
  },

  updatePreferences: async (prefs: Record<string, unknown>) => {
    return req<any>('/api/v1/users/me/preferences', {
      method: 'PATCH',
      body: JSON.stringify(prefs),
    })
  },

  updateMe: async (body: Record<string, unknown>) => {
    const payload: Record<string, unknown> = {}
    if (body.name !== undefined) payload.display_name = body.name
    if (body.display_name !== undefined) payload.display_name = body.display_name
    if (body.username !== undefined) payload.username = body.username
    if (body.bio !== undefined) payload.bio = body.bio
    if (body.photo !== undefined) payload.profile_photo = body.photo
    if (body.profile_photo !== undefined) payload.profile_photo = body.profile_photo
    if (body.theme !== undefined) payload.theme = body.theme
    if (Object.keys(payload).length === 0) return
    return req<any>('/api/v1/users/me', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    })
  },

  mpesaStkPush: async (body: { phone: string; plan: string; gift_username?: string }) => {
    return req<{ checkoutRequestId: string; merchantRequestId?: string; amount?: number; plan?: string }>(
      '/api/v1/payments/mpesa/stk',
      {
        method: 'POST',
        body: JSON.stringify(body),
      },
    )
  },
  mpesaVerify: async (checkoutRequestId: string) => {
    return req<{ paid: boolean; plan?: string; subscription_plan?: string }>(
      '/api/v1/payments/mpesa/verify',
      { method: 'POST', body: JSON.stringify({ checkoutRequestId }) },
    )
  },
  mpesaStatus: async (checkoutRequestId: string) => {
    return req<{ paid: boolean; plan?: string }>(`/api/v1/payments/mpesa/status/${encodeURIComponent(checkoutRequestId)}`)
  },
  upgradePremium: () =>
    req<any>('/api/v1/users/me/upgrade-premium', { method: 'POST' }),
  reactivateAccount: () =>
    req<any>('/api/v1/users/me/reactivate', { method: 'POST' }),
  deletePermanently: (password: string) =>
    req<any>('/api/v1/users/me/delete-permanently', {
      method: 'POST',
      body: JSON.stringify({ password }),
    }),
  updatePremiumSettings: (body: Record<string, unknown>) =>
    req<any>('/api/v1/users/me/premium-settings', {
      method: 'PATCH',
      body: JSON.stringify(body),
    }),

  deactivateAccount: async (password: string) => {
    return req<any>('/api/v1/users/me/deactivate', {
      method: 'POST',
      body: JSON.stringify({ password }),
    })
  },

  contacts: async () => {
    const data = await req<any>('/api/v1/contacts')
    const list = Array.isArray(data)
      ? data
      : Array.isArray(data?.contacts)
        ? data.contacts
        : Array.isArray(data?.items)
          ? data.items
          : []
    return { contacts: list.map(mapContact) }
  },

  blockedContacts: async () => {
    const list = await req<any[]>('/api/v1/contacts/blocked')
    return {
      blocked: (list || []).map((contact) => ({
        ...mapContact(contact),
        isContact: !!contact.is_contact,
      })),
    }
  },

  searchUsers: async (q: string) => {
    const list = await req<any[]>(`/api/v1/users/search/${encodeURIComponent(q)}`)
    return { users: (list || []).map(mapUser) }
  },

  addContact: async (body: {
    username?: string
    peerId?: string
    savedName?: string
    message?: string
    sharePhone?: boolean
    nickname?: string
    phone?: string
  }) => {
    if (!body.username) throw new Error('Username required to add contact')
    const data = await req<any>('/api/v1/contacts/requests', {
      method: 'POST',
      body: JSON.stringify({
        to_username: body.username.replace(/^@/, '').toLowerCase(),
        message: body.message || undefined,
        share_phone: !!body.sharePhone,
        from_nickname: body.savedName || body.nickname || undefined,
      }),
    })
    // Fast path: trust response — only fetch contacts if already mutual/accepted
    const status = String(data?.status || data?.request_status || '').toLowerCase()
    const accepted = status === 'accepted' || data?.contact_created === true
    if (!accepted) {
      return { request: data, contact: null, pending: true }
    }
    try {
      const r = await api.contacts()
      const uname = body.username.replace(/^@/, '').toLowerCase()
      return {
        request: data,
        contact: r.contacts.find((c) => c.username === uname) || null,
        pending: false,
      }
    } catch {
      return { request: data, contact: null, pending: false }
    }
  },

  incomingContactRequests: async () => {
    const list = await req<any[]>('/api/v1/contacts/requests/incoming')
    return {
      requests: (list || []).map((r) => ({
        id: String(r.id || r._id),
        fromUserId: String(r.from_user_id || ''),
        toUserId: String(r.to_user_id || ''),
        username: r.from_username || '',
        name: r.from_display_name || r.from_username || 'Unknown',
        photo: r.from_profile_photo ?? null,
        message: r.message || null,
        status: r.status || 'pending',
        createdAt: r.created_at || '',
        hue: hueFor(String(r.from_user_id || r.from_username || 'x')),
      })),
    }
  },

  outgoingContactRequests: async () => {
    const list = await req<any[]>('/api/v1/contacts/requests/outgoing')
    return {
      requests: (list || []).map((r) => ({
        id: String(r.id || r._id),
        fromUserId: String(r.from_user_id || ''),
        toUserId: String(r.to_user_id || ''),
        username: r.to_username || '',
        name: r.to_display_name || r.to_username || 'Unknown',
        photo: r.to_profile_photo ?? r.profile_photo ?? null,
        message: r.message || null,
        status: r.status || 'pending',
        createdAt: r.created_at || '',
        hue: hueFor(String(r.to_user_id || r.to_username || 'x')),
      })),
    }
  },

  blockUser: async (userId: string) => {
    await req(`/api/v1/contacts/block/${userId}`, { method: 'POST' })
    return { ok: true }
  },
  unblockUser: async (userId: string) => {
    await req(`/api/v1/contacts/block/${userId}`, { method: 'DELETE' })
    return { ok: true }
  },

  acceptContactRequest: async (requestId: string) => {
    const data = await req<any>(`/api/v1/contacts/requests/${requestId}/accept`, {
      method: 'POST',
    })
    const contact = data?.contact ? mapContact(data.contact) : null
    const peerContact = data?.peer_contact ? mapContact(data.peer_contact) : null
    return {
      ok: true,
      mutual: data?.mutual !== false,
      contact,
      peerContact,
      data,
    }
  },

    cancelContactRequest: async (requestId: string) => {
    return req<any>(`/api/v1/contacts/requests/${requestId}/cancel`, {
      method: 'POST',
      body: '{}',
    })
  },

  deleteContactRequest: async (requestId: string) => {
    return req<any>(`/api/v1/contacts/requests/${requestId}`, {
      method: 'DELETE',
    })
  },

rejectContactRequest: async (requestId: string) => {
    const data = await req<any>(`/api/v1/contacts/requests/${requestId}/reject`, {
      method: 'POST',
    })
    return { ok: true, data }
  },

  updateContact: async (contactUserId: string, body: Record<string, unknown>) => {
    // Backend paths use contact_user_id (peer), not the contact document _id
    if (body.savedName !== undefined || body.nickname !== undefined) {
      await req(`/api/v1/contacts/${contactUserId}/nickname`, {
        method: 'PATCH',
        body: JSON.stringify({ nickname: body.savedName ?? body.nickname }),
      })
    }
    const r = await api.contacts()
    return {
      contact: r.contacts.find(
        (c) => c.peerId === contactUserId || c.id === contactUserId || c.entryId === contactUserId,
      )!,
    }
  },

  deleteContact: async (contactUserId: string) => {
    await req(`/api/v1/contacts/${contactUserId}`, { method: 'DELETE' })
    return { ok: true }
  },

  chats: async (opts?: { lean?: boolean; limit?: number }) => {
    const q = new URLSearchParams()
    if (opts?.lean) q.set('lean', 'true')
    if (opts?.limit) q.set('limit', String(opts.limit))
    const qs = q.toString()
    const data = await req<any>(`/api/v1/conversations${qs ? `?${qs}` : ''}`)
    const list = data.conversations || data || []
    const mid = meId()
    const mapped = list.map((c: any) => mapConversation(c, mid))
    // One list row per peer — keep the conversation with newest activity
    const byPeer = new Map<string, (typeof mapped)[0]>()
    for (const ch of mapped) {
      const key = ch.contactId
      const prev = byPeer.get(key)
      if (!prev) {
        byPeer.set(key, ch)
        continue
      }
      const prevT = prev.iso ? Date.parse(prev.iso) : 0
      const nextT = ch.iso ? Date.parse(ch.iso) : 0
      if (nextT >= prevT) byPeer.set(key, ch)
    }
    return { chats: Array.from(byPeer.values()) }
  },

  deleteConversation: async (conversationId: string) => {
    if (!conversationId) throw new Error('Conversation id required')
    await req(`/api/v1/conversations/${conversationId}`, { method: 'DELETE' })
    return { ok: true }
  },

  /** Cross-device notes / checklists / reminders */
  listNotes: async (kind?: string) => {
    const q = kind ? `?kind=${encodeURIComponent(kind)}` : ''
    const data = await req<{ notes: any[] }>(`/api/v1/notes${q}`)
    return (data?.notes || []).map(mapNote)
  },
  createNote: async (note: Record<string, unknown>) => {
    const data = await req<any>('/api/v1/notes', {
      method: 'POST',
      body: JSON.stringify(note),
    })
    return mapNote(data)
  },
  updateNote: async (id: string, patch: Record<string, unknown>) => {
    const data = await req<any>(`/api/v1/notes/${encodeURIComponent(id)}`, {
      method: 'PUT',
      body: JSON.stringify(patch),
    })
    return mapNote(data)
  },
  deleteNote: async (id: string) => {
    await req(`/api/v1/notes/${encodeURIComponent(id)}`, { method: 'DELETE' })
    return { ok: true }
  },
  syncNotes: async (localNotes: Record<string, unknown>[]) => {
    const data = await req<{ notes: any[] }>('/api/v1/notes/sync', {
      method: 'POST',
      body: JSON.stringify({ notes: localNotes }),
    })
    return (data?.notes || []).map(mapNote)
  },

  openPrivateChat: async (
    target: string | { username?: string; userId?: string },
  ) => {
    let username =
      typeof target === 'string'
        ? target
        : (target.username || '').replace(/^@/, '').trim()
    // Self-notes: resolve current user's username when targeting own id
    if (!username && typeof target !== 'string' && target.userId) {
      const me = meId()
      if (target.userId === me) {
        try {
          const u = getStoredUser()
          username = (u?.username || '').replace(/^@/, '')
        } catch { /* */ }
      }
    }
    if (!username) throw new Error('Username required to open chat')
    const conv = await req<any>('/api/v1/conversations/private', {
      method: 'POST',
      body: JSON.stringify({ participant_username: username }),
    })
    return mapConversation(conv, meId())
  },

  getConversation: async (conversationId: string) => {
    const conv = await req<any>(`/api/v1/conversations/${conversationId}`)
    return mapConversation(conv, meId())
  },

  messages: async (conversationId: string, opts?: { limit?: number; beforeId?: string }) => {
    const q = new URLSearchParams()
    q.set('limit', String(opts?.limit ?? 50))
    if (opts?.beforeId) q.set('before_id', opts.beforeId)
    const data = await req<any>(
      `/api/v1/messages/conversations/${conversationId}?${q.toString()}`,
    )
    const list = data.messages || data || []
    const mid = meId()
    return {
      messages: list.map((m: any) => mapMessage(m, mid)),
      nextCursor: data.next_cursor || null,
    }
  },

  send: async (
    conversationId: string,
    text: string,
    image?: string | null,
    opts?: {
      clientKey?: string
      replyToId?: string
      statusReply?: { preview: string; time?: string; statusId?: string }
    },
  ) => {
    let content = text || (image ? '' : '')
    if (opts?.statusReply) {
      // ASCII-safe envelope so peers always parse the quoted status card
      content = encodeStatusReply(content, {
        preview: opts.statusReply.preview || '',
        time: opts.statusReply.time,
        statusId: opts.statusReply.statusId,
      })
    }
    const payload: Record<string, unknown> = {
      content,
      message_type: image ? 'image' : 'text',
    }
    if (opts?.clientKey) {
      payload.idempotency_key = opts.clientKey
    }
    if (image) {
      payload.media_attachments = [{ type: 'image', url: image }]
    }
    if (opts?.replyToId) {
      payload.reply_to_message_id = opts.replyToId
    }
    const msg = await req<any>(`/api/v1/messages/conversations/${conversationId}`, {
      method: 'POST',
      body: JSON.stringify(payload),
    })
    return { message: mapMessage(msg, meId()) }
  },

  markRead: async (conversationId: string) => {
    await req(`/api/v1/messages/conversations/${conversationId}/read`, { method: 'POST' })
    return { ok: true }
  },

  /** Fire-and-forget friendly: peer had the payload ready to paint */
  markDelivered: async (messageId: string) => {
    await req(`/api/v1/messages/${messageId}/delivered`, { method: 'POST' })
    return { ok: true }
  },

  groupInvites: async () => {
    const list = await req<any[]>('/api/v1/groups/invites/mine')
    return { invites: list || [] }
  },
  acceptGroupInvite: async (id: string) => {
    return req<any>(`/api/v1/groups/invites/${id}/accept`, { method: 'POST' })
  },
  rejectGroupInvite: async (id: string) => {
    return req<any>(`/api/v1/groups/invites/${id}/reject`, { method: 'POST' })
  },

  groups: async () => {
    const list = await req<any[]>('/api/v1/groups')
    return { groups: (list || []).map(mapGroup) }
  },

  group: async (id: string) => {
    const g = await req<any>(`/api/v1/groups/${id}`)
    return { group: mapGroup(g) }
  },

  createGroup: async (body: {
    name: string
    desc?: string
    memberIds?: string[]
    memberUsernames?: string[]
  }) => {
    const g = await req<any>('/api/v1/groups', {
      method: 'POST',
      body: JSON.stringify({
        group_name: body.name,
        group_description: body.desc,
        member_usernames: body.memberUsernames || [],
      }),
    })
    return { group: mapGroup(g) }
  },

  sendGroup: async (groupId: string, text: string) => {
    const data = await req<any>('/api/v1/conversations')
    const list = data.conversations || data || []
    const conv = list.find((c: any) => c.group_id === groupId)
    if (!conv) throw new Error('Group conversation not found')
    return api.send(String(conv.id), text)
  },

  patchGroup: async (id: string, body: Record<string, unknown>) => {
    const payload: Record<string, unknown> = {}
    if (body.name) payload.group_name = body.name
    if (body.desc !== undefined) payload.group_description = body.desc
    const g = await req<any>(`/api/v1/groups/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    })
    return { group: mapGroup(g) }
  },

  joinGroup: async (_code: string) => {
    throw new Error('Group invite codes not yet available on backend')
  },

  deleteGroup: async (id: string) => {
    await req(`/api/v1/groups/${id}`, { method: 'DELETE' })
    return { ok: true }
  },

  status: async () => {
    const list = await req<any[]>('/api/v1/statuses/feed')
    const now = Date.now()
    const mapped = (list || [])
      .map(mapStatus)
      .filter((s: any) => {
        if (!s.expiresAt) return true
        const t = Date.parse(s.expiresAt)
        return Number.isNaN(t) || t > now
      })
      .sort((a: any, b: any) => {
        const ta = a.createdAt ? Date.parse(a.createdAt) : 0
        const tb = b.createdAt ? Date.parse(b.createdAt) : 0
        return ta - tb // oldest first
      })
    return { status: mapped }
  },

  postStatus: async (
    text: string,
    image?: string | null,
    background?: string | null,
    opts?: {
      expiresInHours?: number
      visibility?: string
      selectedViewerIds?: string[]
      excludedViewerIds?: string[]
      video?: string
      isRepost?: boolean
      repostOfStatusId?: string
    },
  ) => {
    let content = text || ''
    if (opts?.isRepost && !content.startsWith('\u2063repost\u2063')) {
      content = `\u2063repost\u2063${content}`
    }
    const payload: Record<string, unknown> = {
      content,
      status_type: opts?.video ? 'video' : image ? 'image' : 'text',
      visibility: opts?.visibility || 'contacts',
      selected_viewer_ids: opts?.selectedViewerIds || [],
      excluded_viewer_ids: opts?.excludedViewerIds || [],
      expires_in_hours: opts?.expiresInHours ?? 24,
      background: background || 'theme_purple_grad',
      ...(opts?.isRepost ? { is_repost: true } : {}),
      ...(opts?.repostOfStatusId ? { repost_of_status_id: opts.repostOfStatusId } : {}),
    }
    const media: any[] = []
    if (image) media.push({ type: 'image', url: image })
    if (opts?.video) media.push({ type: 'video', url: opts.video })
    if (media.length) payload.media_attachments = media
    const s = await req<any>('/api/v1/statuses', {
      method: 'POST',
      body: JSON.stringify(payload),
    })
    return { status: mapStatus(s) }
  },

  viewStatus: async (id: string) => {
    await req(`/api/v1/statuses/${id}`)
    return { ok: true }
  },

  deleteStatus: async (id: string) => {
    await req(`/api/v1/statuses/${id}`, { method: 'DELETE' })
    return { ok: true }
  },

  statusViewers: async (id: string) => {
    const list = await req<any[]>(`/api/v1/statuses/${id}/viewers`)
    return {
      viewers: (list || []).map((v) => ({
        id: String(v.viewer_id || v.id),
        username: v.username || '',
        name: v.display_name || v.username || 'User',
        photo: v.profile_photo ?? null,
        viewedAt: v.viewed_at || null,
        liked: !!v.liked,
        reposted: !!(v.reposted || v.is_repost || v.reposted_status),
      })),
    }
  },

  sendContactRequest: async (opts: {
    username?: string
    peerId?: string
    savedName?: string
    message?: string
    sharePhone?: boolean
    nickname?: string
    phone?: string
  }) => {
    return req<any>('/api/v1/contacts/requests', {
      method: 'POST',
      body: JSON.stringify({
        username: opts.username,
        contact_user_id: opts.peerId,
        nickname: opts.nickname || opts.savedName,
        message: opts.message,
        share_phone: opts.sharePhone,
        phone_number: opts.phone,
      }),
    })
  },

  likeStatus: async (id: string) => {
    const res = await req<any>(`/api/v1/statuses/${encodeURIComponent(id)}/like`, { method: 'POST' })
    // Backend may wrap as { data: { liked } } or return payload directly
    return res?.data ?? res
  },

  notifUnreadCount: async () => {
    try {
      const data = await req<any>('/api/v1/notifications/unread-count')
      return { count: Number(data?.count ?? data ?? 0) }
    } catch {
      return { count: 0 }
    }
  },
  listNotifications: async () => {
    const list = await req<any[]>('/api/v1/notifications')
    return { notifications: list || [] }
  },
  markNotificationRead: async (id: string) => {
    await req(`/api/v1/notifications/${encodeURIComponent(id)}/read`, { method: 'POST' })
    return { ok: true }
  },
  markAllNotificationsRead: async () => {
    await req('/api/v1/notifications/read-all', { method: 'POST' })
    return { ok: true }
  },

  iceServers: async () => {
    try {
      const data = await req<any>('/api/v1/calls/ice-servers')
      const list = data?.iceServers || data?.data?.iceServers || data || []
      return Array.isArray(list) ? list : []
    } catch {
      return [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
      ]
    }
  },

  calls: async () => {
    const data = await req<any>('/api/v1/calls')
    const list = data?.calls || data || []
    return {
      calls: (Array.isArray(list) ? list : []).map((c: any) => ({
        id: String(c.id || c._id),
        contactId: String(c.contactId || c.peer_id || ''),
        name: c.name || c.username || 'Unknown',
        username: c.username || '',
        phone: c.show_phone || c.phone ? (c.phone || '') : '',
        showPhone: !!(c.show_phone || c.phone),
        photo: c.photo || null,
        kind: c.kind === 'video' ? 'video' : 'audio',
        direction: c.direction || 'out',
        status: c.status || 'completed',
        duration: c.duration_seconds
          ? `${Math.floor(c.duration_seconds / 60)}:${String(c.duration_seconds % 60).padStart(2, '0')}`
          : '0:00',
        duration_seconds: c.duration_seconds || 0,
        time: (() => {
          const iso = c.created_at || c.time
          if (!iso) return ''
          let s = String(iso)
          if (/^\d{4}-\d{2}-\d{2}T/.test(s) && !/[zZ]|[+-]\d{2}:?\d{2}$/.test(s)) s += 'Z'
          const d = new Date(s)
          if (Number.isNaN(d.getTime())) return ''
          const now = new Date()
          const sameDay = d.toDateString() === now.toDateString()
          if (sameDay) return formatLocalTime(d)
          return d.toLocaleDateString([], { month: 'short', day: 'numeric' })
        })(),
        ago: c.created_at || c.time,
      })),
    }
  },
  logCall: async (body: {
    peer_id: string
    kind: 'audio' | 'video' | string
    direction?: string
    status?: string
    duration_seconds?: number
    call_id?: string
  }) => {
    return req<any>('/api/v1/calls', {
      method: 'POST',
      body: JSON.stringify({
        peer_id: body.peer_id,
        kind: body.kind === 'video' ? 'video' : 'audio',
        direction: body.direction || 'out',
        status: body.status || 'completed',
        duration_seconds: body.duration_seconds || 0,
        call_id: body.call_id,
      }),
    })
  },
  setTyping: async (contactId: string) => {
    try {
      const { wsTyping } = await import('./realtime')
      wsTyping(contactId, true)
    } catch { /* */ }
    return {}
  },
  getTyping: async (_contactId: string) => ({ typing: false }),
  /** Lightweight presence for a user id (includes busy message) */
  presence: async (userId: string) => {
    try {
      const data = await req<any>(`/api/v1/users/presence/${encodeURIComponent(userId)}`)
      return {
        online: !!data?.online,
        lastSeen: data?.last_seen || data?.lastSeen || null,
        busy: !!data?.busy,
        busyMessage: data?.busy_message || data?.busyMessage || '',
        busyUntil: data?.busy_until || data?.busyUntil || null,
      }
    } catch {
      return { online: false, lastSeen: null, busy: false, busyMessage: '', busyUntil: null }
    }
  },
  editMessage: async (messageId: string, content: string) => {
    const data = await req<any>(`/api/v1/messages/${messageId}`, {
      method: 'PATCH',
      body: JSON.stringify({ content }),
    })
    return mapMessage(data, undefined)
  },
  deleteMessage: async (messageId: string) => {
    await req(`/api/v1/messages/${messageId}`, { method: 'DELETE' })
  },
  reactMessage: async (messageId: string, emoji: string) => {
    await req(`/api/v1/messages/${messageId}/reactions`, {
      method: 'POST',
      body: JSON.stringify({ emoji }),
    })
  },
  removeReaction: async (messageId: string, emoji: string) => {
    await req(`/api/v1/messages/${encodeURIComponent(messageId)}/reactions/${encodeURIComponent(emoji)}`, {
      method: 'DELETE',
    })
  },
  forwardMessage: async (messageId: string, conversationId: string) => {
    const data = await req<any>(`/api/v1/messages/${messageId}/forward`, {
      method: 'POST',
      body: JSON.stringify({ conversation_id: conversationId }),
    })
    return mapMessage(data, undefined)
  },
  ring: async (_to: string, _kind: 'audio' | 'video') => ({ ring: null }),
  incomingRings: async () => ({ incoming: [] as any[] }),
  answerRing: async (_id: string, _status: 'accepted' | 'declined') => ({}),
  ringStatus: async (_id: string) => ({ ring: null }),
}
