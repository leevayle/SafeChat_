import { useEffect, type ReactNode } from 'react'
import { AnimatePresence, motion, useMotionValue, useTransform } from 'framer-motion'
import { ArrowLeft, Check } from 'lucide-react'

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)} className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${on ? 'bg-brand-purple' : 'bg-gray-300'}`}>
      <motion.span layout transition={{ type: 'spring', stiffness: 500, damping: 32 }} className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow ${on ? 'right-0.5' : 'left-0.5'}`} />
    </button>
  )
}

export function Sheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title?: string; children: ReactNode }) {
  const y = useMotionValue(0)
  const backdropOpacity = useTransform(y, [0, 220], [1, 0.25])

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-[100] bg-ink/45"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            style={{ opacity: backdropOpacity }}
            onClick={onClose}
          />
          <motion.div
            className="fixed inset-x-0 bottom-0 z-[110] max-h-[55%] overflow-y-auto rounded-t-[2rem] bg-white p-6 pb-8 shadow-[0_-16px_48px_rgba(0,0,0,0.28)] dark:bg-[#121821] dark:text-white md:inset-x-auto md:left-1/2 md:bottom-[10%] md:max-h-[50vh] md:w-full md:max-w-md md:-translate-x-1/2 md:rounded-[1.75rem]"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 36 }}
            style={{ y }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 320 }}
            dragElastic={0.12}
            onDrag={(_, info) => {
              if (info.offset.y < 0) y.set(0)
            }}
            onDragEnd={(_, info) => {
              // Dismiss if dragged down enough or flung
              if (info.offset.y > 56 || info.velocity.y > 400) {
                onClose()
              } else {
                y.set(0)
              }
            }}
          >
            <div className="mx-auto mb-4 flex touch-none justify-center pb-1 pt-0.5">
              <div className="h-1.5 w-12 rounded-full bg-gray-200" />
            </div>
            {title && <h3 className="mb-3 text-xl font-black">{title}</h3>}
            {children}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

export function OptionList({ options, value, onPick }: { options: string[]; value: string; onPick: (v: string) => void }) {
  return (
    <ul className="space-y-1">
      {options.map((o) => (
        <li key={o}>
          <button onClick={() => onPick(o)} className={`flex w-full items-center justify-between rounded-2xl px-4 py-3.5 text-left font-bold transition-colors hover:bg-gray-100 ${o === value ? 'bg-brand-purple/10 text-brand-purple' : ''}`}>
            {o}{o === value && <Check size={20} />}
          </button>
        </li>
      ))}
    </ul>
  )
}

export function Toast({ msg, clear }: { msg: string | null; clear: () => void }) {
  useEffect(() => {
    if (!msg) return
    const t = setTimeout(() => clear(), 2800)
    return () => clearTimeout(t)
  }, [msg, clear])
  return (
    <AnimatePresence mode="wait">
      {msg && (
        <motion.div
          className="pointer-events-none absolute inset-x-0 bottom-24 z-[80] flex justify-center px-4"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 8 }}
        >
          <div className="rounded-full bg-ink/90 px-4 py-2 text-sm font-bold text-white shadow-lg">{msg}</div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export function ScreenHeader({ title, onBack, right }: { title: string; onBack?: () => void; right?: ReactNode }) {
  return (
    <header className="sticky top-0 z-10 flex min-h-16 shrink-0 items-center gap-2 border-b border-gray-200 bg-white/95 px-3 pb-3 pt-[max(12px,env(safe-area-inset-top))] backdrop-blur dark:border-white/10 dark:bg-[#121821]/95">
      {onBack ? (
        <button type="button" onClick={onBack} className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-gray-100" aria-label="Back">
          <ArrowLeft size={22} />
        </button>
      ) : (
        <span className="w-2" />
      )}
      <h1 className="min-w-0 flex-1 truncate text-lg font-black">{title}</h1>
      {right}
    </header>
  )
}

export function PrimaryButton({
  children,
  onClick,
  disabled,
  danger,
  className = '',
}: {
  children: ReactNode
  onClick?: () => void
  disabled?: boolean
  danger?: boolean
  className?: string
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={`w-full rounded-full py-3.5 text-sm font-extrabold text-white shadow-md disabled:opacity-40 ${
        danger ? 'bg-brand-red' : 'bg-brand-purple'
      } ${className}`}
    >
      {children}
    </button>
  )
}
